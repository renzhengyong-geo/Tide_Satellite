function processed_data = process_single_cdf_file_MSS(file_info, curr_folder, ~, data_step)
% process_single_cdf_file_MSS
% 针对 MSS-1 (澳科一号) Level 2 LR VFM 数据处理函数
% 适配 v13_SingleFolder_AC_Diff 主程序
%
% 输入:
%   file_info  - 文件结构体 (包含 .name, .sat_id 等)
%   curr_folder- 当前文件所在路径
%   ~          - (预留参数, 原ref_time)
%   data_step  - 降采样窗口 (秒), 推荐 15
%
% 输出:
%   processed_data - [Lat, Lon, Rad(km), B_N, B_E, B_C, Time(dn), F, Std_F]
%
% 参考: Table 2-1 Level 2 LR VFM Data Set (MSS Data Handbook)

processed_data = [];
% 跳过显然无效的文件名
if contains(file_info.name, 'empty', 'IgnoreCase', true), return; end

full_path = fullfile(curr_folder, file_info.name);
orig_warn_state = warning; 

try
    % =========================================================================
    % 1. 读取原始数据 (基于 MSS Table 2-1)
    % =========================================================================
    % 注意：CDF变量名区分大小写，需严格对应手册
    target_vars = {'Timestamp', 'Latitude', 'Longitude', 'Radius', ...
                   'F', 'B_NEC', 'flag_B', 'flag_q'};
    
    warning('off', 'all');
    try
        % 读取 CDF
        cdf_data = cdfread(full_path, 'Variables', target_vars, ...
            'CombineRecords', true, 'ConvertEpochToDatenum', true);
    catch
        warning(orig_warn_state); return;
    end
    
    if isempty(cdf_data), warning(orig_warn_state); return; end
    
    % 提取变量 (根据 target_vars 顺序)
    raw_t     = double(cdf_data{1});
    raw_lat   = double(cdf_data{2});
    raw_lon   = double(cdf_data{3});
    raw_r     = double(cdf_data{4}); % Unit: meter (Table 2-1)
    raw_F     = double(cdf_data{5}); % Unit: nT
    raw_B     = double(cdf_data{6}); % Unit: nT (NEC frame)
    raw_flg_B = double(cdf_data{7}); % 0:Nominal, 1:Interp, 2:Outlier, 4:PosFault
    raw_flg_q = double(cdf_data{8}); % Error of combined quaternions
    
    % 维度修正 (确保 N x 3)
    if size(raw_B, 2) ~= 3, raw_B = raw_B'; end
    
    % 单位转换: Meter -> Kilometer
    % MSS 轨道高度约 450km，地心半径约 6800km -> 6,800,000m
    if mean(raw_r, 'omitnan') > 1000000 
        raw_r = raw_r / 1000; 
    end
    
    % 标量F缺失时的临时填充 (用于后续逻辑，最后输出仍会用筛选后的F)
    B_mag = sqrt(sum(raw_B.^2, 2)); 
    is_missing_F = isnan(raw_F) | (raw_F < 1.0) | (raw_F > 70000);
    raw_F(is_missing_F) = B_mag(is_missing_F);

    % =========================================================================
    % 2. 质量控制 (Quality Control) - 适配 MSS Flag 定义
    % =========================================================================
    
    % [flag_B] 磁场标志位
    % 0: nominal (保留)
    % 1: derived through interpolation (严格潮汐反演建议剔除，或可视情况保留)
    % 2: outliers (F_ASM vs B_VFM > 1nT) -> 必须剔除
    % 4: position fault / latitude > 41 -> 必须剔除
    mask_B_good = (raw_flg_B <= 1); 
    
    % [flag_q] 姿态误差筛选 (核心修改)
    % 依据公式 6.4-260，flag_q 单位为 arc-seconds (角秒)。
    % 1 arcsec 姿态误差在 50,000nT 背景场下约产生 0.25nT 投影误差。
    % 
    % 阈值选择策略 (用于微弱潮汐信号提取):
    % - < 10 arcsec: 高精度 (Strict)，丢失数据较多
    % - < 20 arcsec: 均衡 (Recommended)，最大误差约 5nT (随机噪声会被Binning平均掉)
    % - < 60 arcsec: 宽松 (Loose)，仅剔除严重姿态丢失
    
    ATTITUDE_THRESHOLD_ARCSEC = 20; 
    
    mask_q_good = ~isnan(raw_flg_q) & (raw_flg_q < ATTITUDE_THRESHOLD_ARCSEC);
    
    % [Geometry] 地理范围
    % MSS 轨道高度 ~450km (R ~ 6828km)。
    % 范围设为 [6400, 7500] km 可有效覆盖正常轨道并剔除异常零值。
    mask_geo_valid = (raw_r > 6400) & (raw_r < 7500) & (abs(raw_lat) <= 90);

    % 综合掩膜
    valid_mask = mask_B_good & mask_q_good & mask_geo_valid & ...
                 ~isnan(raw_lat) & ~isnan(raw_lon) & ~isnan(raw_t) & ~isnan(raw_F);
    
    % 数据量过少则跳过
    if sum(valid_mask) < 10, warning(orig_warn_state); return; end
             
    t_clean   = raw_t(valid_mask);
    lat_clean = raw_lat(valid_mask);
    lon_clean = raw_lon(valid_mask);
    r_clean   = raw_r(valid_mask);
    F_clean   = raw_F(valid_mask);
    B_clean   = raw_B(valid_mask, :);

    % =========================================================================
    % 3. 分箱平均与统计 (Bin Averaging) - 保持不变
    % =========================================================================
    % 下采样逻辑是通用的，不依赖于卫星型号
    
    dt_grid_days = data_step / 86400; 
    t_start = floor(min(t_clean) * 86400 / data_step) * data_step / 86400;
    t_end   = ceil(max(t_clean) * 86400 / data_step) * data_step / 86400;
    edges = t_start : dt_grid_days : t_end;
    
    if length(edges) < 2, warning(orig_warn_state); return; end
    
    [Y, ~] = discretize(t_clean, edges);
    bin_valid = ~isnan(Y);
    Y = Y(bin_valid);
    
    % 统计每个箱内的点数
    counts = accumarray(Y, 1);
    has_enough_data = (counts >= 10); % 至少10个点才认为该15s有效
    
    % 匿名函数：计算均值
    calc_mean = @(data) accumarray(Y, data) ./ max(1, counts);
    
    % A. 基础变量
    val_lat = calc_mean(lat_clean(bin_valid));
    val_r   = calc_mean(r_clean(bin_valid));
    val_F   = calc_mean(F_clean(bin_valid));
    val_B   = [calc_mean(B_clean(bin_valid, 1)), ...
               calc_mean(B_clean(bin_valid, 2)), ...
               calc_mean(B_clean(bin_valid, 3))];
    
    % B. 经度特殊处理 (去跳变)
    lon_rad = deg2rad(lon_clean(bin_valid));
    val_lon = rad2deg(atan2(accumarray(Y, sin(lon_rad)), ...
                            accumarray(Y, cos(lon_rad))));
    
    % C. 标准差 (Weighting用)
    val_std_F = accumarray(Y, F_clean(bin_valid), [], @std);
    
    % D. 时间中心
    val_t_num = (edges(1:end-1) + edges(2:end))' / 2;
    
    % =========================================================================
    % 4. 结果输出
    % =========================================================================
    final_mask = false(size(counts));
    final_mask(1:length(has_enough_data)) = has_enough_data;
    
    if any(final_mask)
        % 格式必须匹配主程序读取顺序: 
        % raw(:,1:3) -> Lat, Lon, Rad
        % raw(:,4:6) -> B_NEC
        % raw(:,7)   -> Time
        % raw(:,8)   -> F
        % raw(:,9)   -> Std (可选, 用于后续加权)
        processed_data = [val_lat(final_mask), ...
                          val_lon(final_mask), ...
                          val_r(final_mask), ...
                          val_B(final_mask, :), ...
                          val_t_num(final_mask), ...
                          val_F(final_mask), ...
                          val_std_F(final_mask)];
    end
    
    warning(orig_warn_state);
catch ME
    fprintf('Error processing file %s: %s\n', file_info.name, ME.message);
    warning(orig_warn_state);
    processed_data = [];
end
end