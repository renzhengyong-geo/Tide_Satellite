# Satellite — 多卫星磁测数据 M2 潮汐信号提取与球谐反演

> 本目录完整覆盖 **数据下载 → 单星预处理（降采样/质量筛选/CHAOS 扣除/环境筛选/沿轨梯度计算）→ 多星联合反演 → 论文级可视化** 全流程。
> 涉及卫星：CHAMP、Swarm A/B/C（Alpha/Bravo/Charlie）、GRACE-FO GF1/GF2、CryoSat-2、MSS-1（澳科一号）、Ørsted、SAC-C。

---

## 目录

1. [架构概览](#1-架构概览)  
2. [数据下载（Python）](#2-数据下载python)  
3. [单文件降采样引擎（MATLAB）](#3-单文件降采样引擎matlab)  
4. [单星预处理主程序（MATLAB）](#4-单星预处理主程序matlab)  
5. [多星联合反演（MATLAB）](#5-多星联合反演matlab)  
6. [核心计算工具（MATLAB）](#6-核心计算工具matlab)  
7. [可视化工具（MATLAB）](#7-可视化工具matlab)  
8. [绘图综合分析（论文级出图）](#8-绘图综合分析论文级出图)  
9. [附录](#9-附录)  

---

## 1. 架构概览

```
┌─ 数据下载层 (Python) ───────────────────────────────────────────┐
│  APIgetSwarm_raw_Data/    ← Swarm A/B/C MAGx_LR (ESA swarm-diss) │
│  APIgetGraceFO_raw_Data/  ← GRACE-FO GF1/GF2 (ISDC GFZ)           │
│  APIgetCryosat_raw_Data/  ← CryoSat-2 (ESA swarm-diss)             │
│  APIgetKp/                ← Kp / Hp30 地磁指数 (GFZ Potsdam API)   │
│  calculate_em.py          ← OMNI 太阳风参数 (Em / Bz / By)         │
└──────────────────────────────────────────────────────────────────-┘
    │
    ▼
┌─ 单文件降采样引擎 (process_single_cdf_file_*.m) ──────────────┐
│  每颗卫星专用 CDF 读取器 + 质量控制 + 15s 分箱平均               │
│  * CHAMP / Swarm / CryoSat / MSS / gracefo / orsted / SAC_C      │
└──────────────────────────────────────────────────────────────────-┘
    │
    ▼
┌─ 单星预处理主程序 (sTep1_PreProcess_*.m) ──────────────────────┐
│  批量扫描 CDF → 调用降采样引擎 → QD 纬度 → CHAOS 扣除             │
│  → RC/Hp30/Em 筛选 → 夜间筛选 → 沿轨梯度 → MAT 输出              │
│  * Swarm / CHAMP / CS2 / MSS / SAC_C / Orsted / GraceFO(v6)     │
└───────────────────────────────────────────────────────────────────┘
    │
    ▼
┌─ 多星联合反演 (sTep2_ALL_Satellite_inversion_v2.m) ──────────┐
│  IRLS (Huber 加权) + 卫星特异性参数 + 分块并行 + 正则化           │
│  输出: 球谐系数 (SH Coefficients)  →  SH_coefficients_*.txt     │
└───────────────────────────────────────────────────────────────────┘
    │
    ▼
┌─ 核心工具 (MATLAB) ───────────────────────────────────────────┐
│  build_K_matrix_paper.m  ← 球谐设计矩阵                           │
│  calculate_QD_Lat.m      ← 准偶极子纬度                           │
│  sunGEI.m                ← 太阳 GEI 坐标 & 格林尼治恒星时         │
└───────────────────────────────────────────────────────────────────┘
    │
    ▼
┌─ 可视化 (MATLAB) ─────────────────────────────────────────────┐
│  MSS_oribit.m              ← Swarm/MSS 轨道分布图                │
│  绘图综合分析/ (25 脚本)      ← 论文级别综合出图                  │
└───────────────────────────────────────────────────────────────────┘
```

---

## 2. 数据下载（Python）

### 2.1 Swarm A/B/C — `APIgetSwarm_raw_Data/swarm_data_downloader.py`

从 ESA swarm-diss 数据中心下载 Swarm Level 1b MAGx_LR（CDF ZIP 格式）。

| 项目 | 内容 |
|------|------|
| 数据源 | `https://swarm-diss.eo.esa.int/swarm/Level1b/Entire_mission_data/MAGx_LR/Sat_{A,B,C}/` |
| 输出目录 | `Satellite_Data/Swarm/2025latest/{A,B,C}/` |
| 文件命名 | `SW_OPER_MAG{A,B,C}_LR_1B_YYYYMMDDT*_YYYYMMDDT*_0701.CDF.ZIP` |
| 版本回退 | 优先 0701，失败则尝试 0702 |
| 并行下载 | `ThreadPoolExecutor(max_workers=5)` |
| 参数 | `--start-date`（默认 `2025-03-01`）、`--end-date`（默认当天） |

### 2.2 GRACE-FO GF1/GF2 — `APIgetGraceFO_raw_data/gracefo_data_downloader.py`

从 ISDC GFZ 服务器下载 GRACE-FO 磁力仪数据（FGM ACAL CORR 校正数据）。

| 项目 | 内容 |
|------|------|
| 数据源 | `https://isdc-data.gfz.de/grace-fo/MAGNETIC_FIELD/0201/GF{1,2}/ACAL_CORR/` |
| 输出目录 | `Satellite_Data/GRACEFO/GF1/`、`GF2/` |
| 文件格式 | `GF{1,2}_OPER_FGM_ACAL_CORR_*.cdf` |
| 参数 | `--start-date`（默认 `2025-05-01`）、`--end-date`（默认当天） |

### 2.3 CryoSat-2 — `APIgetCryosat_raw_data/cryosat_data_downloader.py`

混合模式下载器：先 FTP 列出文件清单，再 HTTPS 下载（防火墙友好）。

| 项目 | 内容 |
|------|------|
| 数据源 | FTP/HTTPS → `swarm-diss.eo.esa.int/Multimission/CryoSat-2/{year}/` |
| 输出目录 | `Satellite_Data/CryoSat/` |
| 文件格式 | `CS_OPER_MAG_*.cdf` |
| 认证 | 需要 ESA 用户名/密码（脚本内硬编码，使用前需更新） |
| 参数 | `START_DATE`、`END_DATE`、`SAVE_DIR`（脚本内直接修改） |

### 2.4 地磁指数 — `APIgetKp/`

| 脚本 | 获取内容 | 数据源 | 输出文件 |
|------|---------|--------|---------|
| `getKpindex.py` | 通用 GFZ API 客户端（支持 Kp/ap/Ap/Cp/C9/Hp30/Hp60 等） | `kp.gfz-potsdam.de` | —（被调用库） |
| `fetch_kp.py` | Kp 指数（2018–2025） | 同上 | `kp_data_for_gracefo.csv` |
| `fetch_hp30.py` | Hp30 指数（1964–2025） | 同上 | `hp30_data_*.csv` |

### 2.5 CDF 完整性检查 — `check_cdf_integrity.py`

| 文件 | 检查目标 |
|------|---------|
| `APIgetCryosat_raw_data/check_cdf_integrity.py` | CryoSat-2 CDF 完整性 |
| `APIgetGraceFO_raw_data/check_cdf_integrity.py` | GRACE-FO CDF 完整性 |

使用 `spacepy.pycdf` 打开每个 CDF 并读取前 10 个数据点，损坏信息写入 `corrupt_files.txt`。

### 2.6 OMNI 太阳风参数 — `calculate_em.py`

读取 OMNI 高分辨率（1-min/5-min）太阳风数据文件，计算 Newell 耦合参数 Em 并输出 2 小时滑动平均值。

| 项目 | 内容 |
|------|------|
| 输入 | `Omni_raw_Data_HR/*.dat` / `*.txt` |
| 输出 | `omni_min_em_bz_2h_avg.csv` |
| Em 公式 | `Em = 0.33 × V^(4/3) × Bt^(2/3) × sin⁸/³(|θ|/2) × 10⁻³` |
| 滑动窗口 | 120 分钟（双指针实现） |
| 输出列 | `datetime, em, by_gsm, bz_gsm, avg_em_2h, avg_by_2h, avg_bz_2h` |

---

## 3. 单文件降采样引擎（MATLAB）

**共 7 个专用函数**，每颗卫星（或同类卫星组）对应一个。均实现以下共性逻辑：

1. **CDF 读取**：基于 `cdfread` 或 `cdfinfo`，按卫星手册指定变量名读取  
2. **质量控制**：硬件标志位（FGM/ASM/姿态）筛选，仅保留高质量数据  
3. **分箱平均**：15 秒时间窗内的数据取平均（bin averaging），避免低通滤波引起的 Gibbs 震荡  
4. **经度修复**：使用 `atan2(sin, cos)` 三角函数平均解决 ±180° 经度跳变  
5. **标准差输出**：输出箱内磁场标准差（STD），用于反演时的加权最小二乘  

统一输出格式（9 列矩阵）：

```
[Lat(°), Lon(°), Rad(km), B_N(nT), B_E(nT), B_C(nT), Time(datenum), F(nT), F_Std(nT)]
```

> **注意**: 纯标量卫星（Ørsted、SAC-C）的 `B_N/E/C` 三列为 NaN，仅输出标量 F。

### 3.1 `process_single_cdf_file_CHAMP.m`

| 项目 | 内容 |
|------|------|
| 变量名 | `EPOCH`, `GEO_LAT`, `GEO_LON`, `GEO_ALT`, `GEO_STAT`, `FGM_SCAL`, `NEC_VEC`, `FGM_FLAGS`, `ASC_STAT` |
| 质量控制 | (1) `GEO_STAT == [0,20,0]` (2) FGM_FLAGS bit2-3=0, bit4=0 (3) ASC_STAT 万位=7 |
| 分箱 | 15s 窗口，箱内 ≥10 点 |
| 半径 | `alt + 6371.2` (km) |

### 3.2 `process_single_cdf_file_Swarm.m`

| 项目 | 内容 |
|------|------|
| 变量名 | `Timestamp`, `Latitude`, `Longitude`, `Radius`, `F`, `B_NEC`, `Flags_F`, `Flags_B`, `Flags_q`, `Flags_Platform` |
| 质量控制 | (A/B) `Flags_B ≤ 1, Flags_F ≤ 1, Flags_q < 30`；(C) `Flags_B ≤ 30`（放宽 C 星 ASM-VFM 差异） |
| 分箱 | 60s 窗口，箱内 ≥10 点 |
| 标量缺失填充 | 用 `|B_NEC|` 回填缺失的 F |

### 3.3 `process_single_cdf_file_CryoSat.m`

智能适配多版本 CDF 格式的鲁棒版。

| 项目 | 内容 |
|------|------|
| 变量 | 自动检测 `B_NEC` / `B_NEC1` / `M1_B_NEC`；`F` 缺失时手动计算 |
| 质量控制 | `q_error < 40″`，`6500 < r < 7500` km，`10000 < F < 75000` nT |
| 分箱 | 60s 窗口，箱内 ≥1 点 |
| 特点 | 动态变量名检测，兼容不同数据版本 |

### 3.4 `process_single_cdf_file_MSS.m`

专为 MSS-1（澳科一号）Level 2 LR VFM 数据设计。

| 项目 | 内容 |
|------|------|
| 变量 | `Timestamp`, `Latitude`, `Longitude`, `Radius`, `F`, `B_NEC`, `flag_B`, `flag_q` |
| 质量控制 | `flag_B ≤ 1`（剔除 Outlier/PosFault）；`flag_q < 20″`（姿态误差阈值，参考 MSS 手册 §6.4-260） |
| 分箱 | 15s 窗口，箱内 ≥10 点 |
| 备注 | 姿态阈值选择：<10″（严格）、**<20″（推荐）**、<60″（宽松） |

### 3.5 `process_single_cdf_file_gracefo.m` & `process_single_cdf_file_orsted.m`

两个文件共享同一个函数体（分支逻辑），适配 GRACE-FO 和 Ørsted 两种格式。

**GRACE-FO 分支**：

| 项目 | 内容 |
|------|------|
| 变量 | `Timestamp`, `Latitude`, `Longitude`, `Radius`, `B_NEC`, `B_FGM`, `B_FLAG` |
| 降采样 | **直接抽取**（非分箱平均），步长 `data_step`（推荐 15s） |
| 质量控制 | `B_FLAG == 0`，标量 > 1000 nT |
| 半径 | 自动判断 m→km 转换 |

**Ørsted 分支**：

| 项目 | 内容 |
|------|------|
| 变量 | `Theta`, `Phi`, `R`, `B`, `T`, `F`, `Day`, `Qf`, `Qb` |
| 降采样 | 同上，直接抽取 |
| 坐标 | Theta 余纬 → 纬度；Time = 2000-01-01 + Day + sec/86400 |
| 质量控制 | `Qf+Qb == 0`（质量标记无异常） |

### 3.6 `process_single_cdf_file_SAC_C.m`

| 项目 | 内容 |
|------|------|
| 变量 | `theta`, `phi`, `r`, `t`, `F`（纯标量，无矢量 B） |
| 降采样 | 15s 分箱平均，输出 `B_NEC` 三列全为 NaN |
| 时间 | MJD2000 → datenum |
| 质量控制 | `F > 1000` nT，NaN 剔除 |

---

## 4. 单星预处理主程序（MATLAB）

**共 7 个主程序**，每个对应一颗卫星（或一类卫星），执行完整的预处理流水线。所有脚本遵循统一架构：

```
Step 0: 初始化并行池 (parpool, max_workers=6)
Step 1: 设定参数（数据路径、分箱窗口、采样控制）
Step 2: 加载辅助数据（OMNI Em/Bz/By, Hp30, RC Index）
Step 3: 扫描/读取 → 调用 process_single_cdf_file_* → 15s 降采样
Step 4: 环境筛选（Night、Hp30、OMNI、RC）
Step 5: 扣除 CHAOS-8.4 核心场模型
Step 6: 计算沿轨梯度（15s 前向差分 → dF/dt）
Step 7: 保存 MAT 文件 + 诊断图
```

### 4.1 `sTep1_PreProcess_Swarm.m` — Swarm A/B/C 预处理（v13）

**核心功能**：单一路径递归扫描 → MAGA/MAGB/MAGC 自动分类 → A/C 卫星差分配对。

| 项目 | 内容 |
|------|------|
| 数据路径 | `Satellite_Data/Swarm/` |
| 分箱窗口 | 60s（读取时降采样） |
| 辅助数据 | OMNI (Em/Bz/By) + Hp30 + RC Index |
| 核心场 | CHAOS-8.4（`CHALLENGE_MF_0409.mat`） |
| 梯度计算 | 15s 前向差分 → `dF/dt` + Swarm A/C 星间梯度 |
| 筛选条件 | Night (天顶角>100°) + Quiet (Hp30≤2.0, |Bz|>2, |By|<5) + RC 导数剔除 |
| 输出 | `Swarm_Input_Weighted.mat` / `Swarm_Gradient_Weighted.mat` |
| 诊断图 | 残差分布、筛选前后数据量对比 |

**A/C 差分配对算法**：
- 在 15s 降采样基础上，对 Swarm A 和 C 各取 50s 滑动窗口
- 在窗口内寻找最小纬度差的配对点
- 输出星间差分磁场（消除非潮汐共模噪声）

### 4.2 `sTep1_PreProcess_CHAMP.m` — CHAMP 预处理（v2.1）

| 项目 | 内容 |
|------|------|
| 数据路径 | `Satellite_Data/CHAMP/` |
| 分箱窗口 | 15s |
| 质量控制 | 硬件 Flag 三重筛选（GEO_STAT + FGM_FLAGS + ASC_STAT，见 §3.1） |
| 抽样控制 | 支持按天随机抽样（`ENABLE_RANDOM_SAMPLING` + `RANDOM_SAMPLE_RATIO`） |
| 输出 | `CHAMP_Input_Vector.mat` / `CHAMP_Scalar.mat` + 沿轨梯度 |

### 4.3 `sTep1_PreProcess_CS2.m` — CryoSat-2 预处理

| 项目 | 内容 |
|------|------|
| 数据路径 | `Satellite_Data/CryoSat/` |
| 分箱窗口 | 60s |
| 输出类型 | 仅单星沿轨梯度（标量+矢量） |
| 卫星 ID | `SAT_ID_CRYOSAT = 90` |

### 4.4 `sTep1_PreProcess_MSS.m` — MSS-1（澳科一号）预处理

| 项目 | 内容 |
|------|------|
| 数据路径 | `Satellite_Data/MSS_v07xx/` |
| 分箱窗口 | 15s |
| 特点 | 低倾角（~41°）优化，姿态阈值 `flag_q < 20″` |
| 输出 | `MSS_Input_Vector.mat` / `MSS_Scalar.mat` + 沿轨梯度 |

### 4.5 `sTep1_PreProcess_SAC_C.m` — SAC-C 预处理

| 项目 | 内容 |
|------|------|
| 数据路径 | `Satellite_Data/SAC-C/` |
| 特点 | **仅标量**（Ørsted/SAC-C 共享降采样引擎 `process_single_cdf_file`），1Hz→15s |
| 输出类型 | 标量残差 dF + 沿轨标量梯度 dF_grad |
| 纬度覆盖 | 全纬度（无 QD Lat 截断） |

### 4.6 `sTep1_Orsted_PreProcess.m` — Ørsted 预处理

| 项目 | 内容 |
|------|------|
| 数据路径 | `Satellite_Data/Oersted/` |
| 特点 | **仅标量**（输出 dF + dF_grad），Theta/Phi/R 坐标格式 |
| 筛选条件 | Night + RC + Hp30 + OMNI(By/Bz) |

### 4.7 `sTep1_Combined_GraceFO_PreProcess_v6.m` — GRACE-FO 预处理（v6 星间梯度版）

**最复杂的预处理脚本**，处理 GRACE-FO 双星（GF1/GF2）同步追及构型。

| 项目 | 内容 |
|------|------|
| 数据路径 | `Satellite_Data/GRACEFO/GF1/` + `GF2/` |
| 分箱窗口 | 15s（单星降采样）→ **30s 二次降采样**（星间梯度匹配） |
| 核心算法 | 日期同步 → GF1/GF2 联合配对 → 30s 双星星间梯度 |
| 辅助数据 | Em/Bz/By、Hp30、RC Index |
| 输出 | `GraceFO_Gradient_Weighted.mat` / `GraceFO_Scalar.mat` |

---

## 5. 多星联合反演（MATLAB）

### `sTep2_ALL_Satellite_inversion_v2.m` — 统一反演框架

将所有卫星的预处理 MAT 文件合并，执行 IRLS（迭代重加权最小二乘）球谐反演。

| 项目 | 内容 |
|------|------|
| **模型参数** | `N_max = 32`（最大球谐阶数），`period_tidal = 12.42060122 h` |
| **反演方法** | IRLS + Huber 加权（每颗卫星独立 Huber 常数） |
| **卫星配置策略** | 见下表 §5.1 |
| **分块计算** | `BLOCK_SIZE = 15000`，`parfor` 并行（30 workers） |
| **正则化** | 阶依赖 Tikhonov：`λ · diag([n(n+1)]²)`，n=1 重罚 110000 |
| **夜间筛选** | `sunGEI` 天顶角 > 100° |
| **QD 纬度筛选** | `|QD_Lat| > 6°`（排除赤道电离带） |
| **输出格式** | 球谐系数 TXT：`SH_coefficients_*.txt`（n, m, Real, Imag, Error） |

#### 5.1 卫星权重配置

| 卫星 | `SigAbs` (nT) | `SigGrad` (nT) | `Scale` | `HuberK` | 备注 |
|------|:---:|:---:|:---:|:---:|------|
| **Swarm A/B/C** | 2.2 | 0.4 | 1.0 | 1.5 | 黄金标准，最高权重 |
| **CHAMP** | 2.5 | 0.4 | 1.0 | 1.5 | 早期磁场关键约束 |
| **MSS-1** | 2.2 | 0.4 | 1.0 | 0.5 | 低倾角补充 |
| **Ørsted** | 2.5 | 0.4 | **0.1** | 1.345 | 纯标量，低权重 |
| **SAC-C** | 2.5 | 0.4 | **0.1** | 1.345 | 纯标量，低权重 |
| **CryoSat-2** | 6.0 | 3.0 | **0.1** | 1.5 | 高噪声，空间补充 |
| **GRACE-FO** | 10.0 | 4.0 | **0.01** | 0.6 | 星间梯度，极端低权 |

#### 5.2 反演流程

```
1. 扫描 *_Weighted.mat / *_Scalar.mat / *_Input_*.mat
2. 按文件名识别卫星 → 匹配 SAT_DB 配置
3. 调用 standardize_data_fixed 粗差剔除 (Abs>5nT, Grad>2nT)
4. 分块 (BLOCK_SIZE=15000)
5. 构建 K 矩阵 (get_K_block)
6. IRLS 迭代 (MAX_ITER=80):
   a. 计算残差
   b. compute_table3_sigma (物理 Sigma + 几何权)
   c. Huber 加权 (satellite-specific k)
   d. 更新法方程 → 共轭梯度求解
7. 输出球谐系数
```

---

## 6. 核心计算工具（MATLAB）

### 6.1 `build_K_matrix_paper.m` — 球谐设计矩阵

将球谐系数映射到磁场三分量（径向 Br、极向 Bθ、方位向 Bφ）。对应论文公式 2-15 至 2-17。

```
输入: Pos [r(km), θ(°), φ(°)]  (n_pts × 3)
      cos_t, sin_t              潮汐时间余弦/正弦列向量
      N_max                     最大球谐阶数
      a                         地球参考半径 (km)
输出: K_r, K_t, K_p             设计矩阵 (n_pts × N_params)
```

**技术细节**：
- Legendre 导数 `dP/dθ`：有限差分（`Δ = 1e-4°`，二阶中心差分）
- 极点保护：`sinθ < 1e-10` 时设为 1e-10
- 每对 `(n, m)` 产生 2 列（实部 cos + 虚部 sin）+ `m>0` 时 2 列 `h_nm`
- 总列数 `N_params = N_max × (N_max + 2) × 2`

### 6.2 `calculate_QD_Lat.m` — 准偶极子纬度

根据地磁场向量和卫星位置计算本地偶极子纬度（QD 纬度），用于赤道电离带筛选。

| 输入 | `B_vec (N×3)`, `r_sat` (km), `Re=6371.2` km |
|输出| `QD_Lat` (°)，从磁倾角 I 反推 |
| 特点 | 已修复旧版本中 L-shell 映射导致赤道带数据空缺的 bug |

### 6.3 `sunGEI.m` — 太阳位置与格林尼治恒星时

| 输入 | `md2000` — MJD2000 时间（标量或向量） |
|输出| `S` — 3 维太阳方向单位向量；`GST` — 格林尼治恒星时 (rad) |
| 有效期 | 1901–2099 年 |
| 用途 | 夜间筛选（天顶角）、坐标变换 |

---

## 7. 可视化工具（MATLAB）

### 7.1 `MSS_oribit.m` — 卫星原始轨道分布图

读取少量 Swarm-A 和 MSS-1 原始 CDF 数据，在 Robinson 投影下绘制连续轨道分布。

| 输入 | 本地 CDF 数据（路径硬编码，需按实际修改） |
|输出| `Raw_Orbit_Distribution.png`（600 dpi） |

---

## 8. 绘图综合分析（论文级出图）

`ComprehensivePlots/` 目录包含 **25 个脚本**，用于多卫星综合诊断与论文级别出版。按功能分为以下组：

### 8.1 论文最终版图件

| 脚本 | 功能 | 说明 |
|------|------|------|
| `Thesis_Plot_Final_v11_A4_Standard.m` | 7 星 × 4 分量空间分布（A4 版心） | 论文主图 |
| `Thesis_Plot_Final_v12_A4_Standard.m` | v11 升级版（参数微调） | |
| `Thesis_Plot_Final_v8_LayoutOptimized.m` | 版式优化版（早期布局） | |
| `Thesis_Plot_PPT_16x9.m` | 16:9 答辩/汇报版（幻灯片配色） | |

### 8.2 功率谱与相关性分析

| 脚本 | 功能 |
|------|------|
| `Analysis_Power_Spectrum_Layers.m` | 多层功率谱分析（新增） |
| `Plot_Power_Spectrum_Layout_Adjusted.m` | 8 星/模型功率谱对比 + 局部放大 |
| `Plot_Spectrum_and_Correlation_Comparison.m` | 功率谱 + 分阶相关系数（Ours vs 外部模型） |
| `Plot_Spectrum_and_Correlation_Comparison_N2.m` | 同上，N2 潮汐分量 |
| `Plot_Spectrum_and_Correlation_Comparison_N2_mat.m` | N2 分量对比（MAT 文件格式版） |
| `Plot_Spectrum_and_Correlation_Comparison_O1.m` | 同上，O1 潮汐分量 |

### 8.3 多卫星联合诊断

| 脚本 | 功能 |
|------|------|
| `Plot_All_Satellites_Full_Diagnostics.m` | 7 星残差诊断汇总面板 |
| `plot_mission_dashboard_V13_SplitHist.m` | 多卫星综合仪表盘 + 分栏直方图 |
| `plot_orbit_geometry_v8.m` | 卫星轨道几何 3D 可视化 |
| `Plot_Datanum_Circle.m` | 数据量分布圆图（新增，展示各卫星数据量贡献） |

### 8.4 球谐系数对比

| 脚本 | 功能 |
|------|------|
| `Plot_SH_From_CSV.m` | 从 CSV 加载球谐系数并绘制 |
| `Plot_Normalized_Coefficient_Differences_v0312.m` | 归一化系数差异三角图 |
| `Plot_N2_Coefficient_Differences_Thesis.m` | N2 分量系数差异 |
| `Plot_Correlation_Dual_Panels.m` | 双面板相关系数热力图 |
| `Plot_Correlation_Dual_Panels_Thesis_N2.m` | N2 双面板 |
| `Plot_Correlation_M2_Thesis_Final.m` | M2 相关性论文最终版（新增） |

### 8.5 多卫星 vs 正演模型

| 脚本 | 功能 |
|------|------|
| `Plot_Multisat_vs_Forward_Thesis.m` | 多卫星联合反演 vs 正演模型对比 |
| `Plot_Multisat_vs_Forward_Thesis_N2.m` | N2 分量 vs 正演 |
| `Plot_MSS_Forward_Comparison_Individual.m` | MSS-1 逐分量 vs 正演 |

### 8.6 工具与辅助

| 脚本 | 功能 |
|------|------|
| `convert_sh_csv_to_txt.m` | 球谐系数 CSV → 规则网格 TXT + 绘图验证 |
| `build_K_matrix_paper.m` | 与根目录同名文件，独立副本 |
| `calculate_QD_Lat.m` | 同上，独立副本 |
| `sunGEI.m` | 同上，独立副本 |
| `inspect_mat_files.m` | MAT 文件结构检查 |
| `load_spa_constants.m` | 加载 SPA 天文常数 |
| `spa1.m` / `spa_const.m` | NREL SPA 太阳位置算法（用于精确天顶角） |

### 8.7 参考模型数据目录

| 目录 | 内容 |
|------|------|
| `Grayver_result/` | Grayver (2024) 潮汐模型（HRM2, LRM2, HRN2, HRO1） |
| `CM6/` | CM6 潮汐模型（M2, N2, O1） |
| `Kalman_result/` | Kalman 滤波结果 |
| `GO19/` | GO19 潮汐模型（N2, O1） |
| `正演模拟结果/` | 数值正演模拟（`KUV_RES_0001.h5`） |
| `潮汐磁场结果/` | 各卫星反演的潮汐磁场 CSV |
| `卫星残差数据/` | 各卫星预处理后的残差 MAT 文件 |

---

## 9. 附录

### 9.1 完整运行流程

```
步骤 0 — 数据下载（一次运行即可，后续按需增量更新）
  │
  ├─ APIgetSwarm_raw_Data/swarm_data_downloader.py
  ├─ APIgetGraceFO_raw_data/gracefo_data_downloader.py
  ├─ APIgetCryosat_raw_data/cryosat_data_downloader.py
  ├─ APIgetKp/fetch_kp.py + fetch_hp30.py
  └─ calculate_em.py

步骤 1 — 辅助数据（非必需，已有预存文件可跳过）
  └─ omni_min_em_bz_2h_avg.csv, hp30_data_*.csv, RC_*.dat

步骤 2 — 单星预处理（可并行执行，相互独立）
  │
  ├─ sTep1_PreProcess_CHAMP.m        → CHAMP input mat
  ├─ sTep1_PreProcess_Swarm.m        → Swarm input mat (+ A/C Diff)
  ├─ sTep1_Combined_GraceFO_PreProcess_v6.m  → GraceFO mat (+ 星间梯度)
  ├─ sTep1_PreProcess_CS2.m          → CryoSat mat
  ├─ sTep1_PreProcess_MSS.m          → MSS mat
  ├─ sTep1_Orsted_PreProcess.m       → Ørsted mat
  └─ sTep1_PreProcess_SAC_C.m        → SAC-C mat

步骤 3 — 多星联合反演
  └─ sTep2_ALL_Satellite_inversion_v2.m  → SH_coefficients_*.txt

步骤 4 — 可视化（依赖步骤 2-3 输出）
  ├─ MSS_oribit.m                    → 轨道分布检查
  └─ 绘图综合分析/*.m                 → 论文级综合图件
```

### 9.2 辅助数据文件清单

| 文件 | 用途 | 来源 |
|------|------|------|
| `omni_min_em_bz_2h_avg.csv` | OMNI 太阳风参数（Em/Bz/By） | `calculate_em.py` 生成 |
| `hp30_data_*.csv` | Hp30 地磁指数 | `fetch_hp30.py` 生成 |
| `kp_data_for_gracefo.csv` | Kp 指数 | `fetch_kp.py` 生成 |
| `RC_*.dat` | RC 环流指数 | 外部数据（GFZ） |
| `CHALLENGE_MF_0409.mat` / `CHAOS-8.4.mat` | CHAOS-8.4 核心场模型 | 外部数据（DTU Space） |
| `CHALLENGE_CHAOS_shc.txt` | CHAOS 球谐系数文本 | 外部数据 |

> **路径约定**: 上述辅助数据文件统一放置在 `sTep1_*.m` 中 `AUX_DATA_PATH` 指定的目录（通常为 `../`，即项目根目录）。各预处理脚本启动时会检查文件存在性，缺失则报错。

### 9.3 依赖工具箱

- **MATLAB R2020b+** — 基础计算平台
- **Parallel Computing Toolbox** — `parpool` / `parfor`（所有 sTep1 和 sTep2 均使用）
- **Statistics and Machine Learning Toolbox** — `robustfit`（反演 Huber 加权）
- **M_Map 工具箱**（第三方）— `m_proj`, `m_pcolor`, `m_coast`（全球投影图）
- **CDF/PAC 工具箱**或 MATLAB `cdfread` — CDF 文件读取

### 9.4 各卫星关键参数汇总

| 卫星 | 时段 | 倾角 | 数据类型 | N_max | 分箱间隔 | 独特处理 |
|------|------|------|---------|:-----:|:--------:|---------|
| **CHAMP** | 2000–2010 | 87.3° | 矢量+标量 | 15 | 15s | 硬件三重 Flag + ASC |
| **Swarm A/B/C** | 2013–至今 | 87.4° | 矢量+标量 | 15 | 60s | A/C 星间差分 |
| **GRACE-FO** | 2018–至今 | 89.0° | 矢量+标量 | 28 | 15s→30s | GF1–GF2 星间梯度 |
| **MSS-1** | 2023–至今 | 41.0° | 矢量+标量 | 15 | 15s | 低倾角 + 亚角秒姿态 |
| **CryoSat-2** | 2010–至今 | 92.0° | 矢量+标量 | 15 | 60s | 变量名自动检测 |
| **Ørsted** | 1999–2013 | 96.5° | **仅标量** | 10 | 15s | Qf/Qpos Flag 融合 |
| **SAC-C** | 2000–2007 | 98.0° | **仅标量** | 8 | 15s | MJD2000 时间，Theta/Phi |

### 9.5 输出产物汇总

| 产物 | 格式 | 说明 |
|------|------|------|
| `{Satellite}_Input_Vector.mat` | MAT | 矢量数据（含 B_NEC、残差、沿轨梯度） |
| `{Satellite}_Scalar.mat` | MAT | 标量数据（含 F、残差、标量梯度） |
| `{Satellite}_Gradient_Weighted.mat` | MAT | 星间梯度（Swarm A/C、GRACE-FO） |
| `{Satellite}_Input_Weighted.mat` | MAT | 加权输入（含标准差列用于反演加权） |
| `SH_coefficients_M2_*.txt` | TXT | 球谐系数（n, m, Real_cos, Imag_sin, Error） |
| `*.pdf / *.png` | 图件 | 诊断图 + 论文图（绘图综合分析目录） |

### 9.6 常见问题

**Q: CDF 读取报错 "Variable not found"**
A: 不同数据版本的变量名有差异。CryoSat 脚本已内置自动检测（`B_NEC`/`B_NEC1`/`M1_B_NEC`），其他卫星请检查 `cdfinfo` 输出后更新 `target_vars`。

**Q: 预处理脚本提示 "文件缺失: omni_min_em_bz_2h_avg.csv"**
A: 请先运行 `calculate_em.py` 生成该文件，或更新脚本中的 `AUX_DATA_PATH` 指向正确的辅助数据路径。

**Q: sTep2 反演结果不收敛**
A: 检查 `lambda_base` 参数（默认 `2e-3`），若解抖动可增大至 `2.0`；若过度正则可减小至 `1e-4`。

**Q: Swarm A/C 差分配对失败**
A: 确保 GF1/GF2 文件夹中有相同日期的文件。sTep1_GraceFO 脚本含日期同步逻辑，Swarm 脚本依赖文件名 `MAGA`/`MAGB`/`MAGC` 标识。

---

> **文档版本**: 2026 · **覆盖范围**: 卫星部分所有实际文件（含新增的预处理与反演全流程脚本）
