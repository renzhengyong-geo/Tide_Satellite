% =========================================================================
% GraceFO 潮汐提取预处理程序 (v11_Unified_30s: 30s星间梯度版)
% 核心改进:
% 1. [统一流] 全程基于15秒降采样数据处理，消除均值化冲突
% 2. [星间梯度] 在15秒基础上二次降采样至30秒，匹配双星追及距离
% 3. [修复] Hp30/Em 时区匹配与并行计算优化
% =========================================================================
clc; clear; close all;
tic;

% 初始化并行池
max_workers = min(6, feature('numcores'));
p = gcp('nocreate');
if isempty(p), parpool('local', max_workers); end

%% ------------------- 1. 参数设定 -------------------
disp('1. 设定参数...');

data_folders = {
    'E:\A_graduate\code_and_program\Satellite_data_processing\Satellite_Data\GraceFO1\', ...
    'E:\A_graduate\code_and_program\Satellite_data_processing\Satellite_Data\GraceFO2\'
    };

% [功能] 随机读取控制
ENABLE_RANDOM_SAMPLING = false;   
RANDOM_SAMPLE_RATIO    = 0.4; % 采样比例

% [策略]
% 基础采样间隔设定为15秒 (用于读取和单星处理)
BINNING_WINDOW_SEC  = 15;  
ref_dn_2000 = datenum(2000, 1, 1, 0, 0, 0);

%% ------------------- 2. 加载辅助数据 -------------------
disp('2. 加载环境参数 (Em, Hp30, RC)...');

AUX_DATA_PATH = ''; 

% --- 2.1 加载 Em/Bz/By (分钟级) ---
file_em = fullfile(AUX_DATA_PATH, 'omni_min_em_bz_2h_avg.csv');
if ~isfile(file_em), error('文件缺失: %s', file_em); end
em_table = readtable(file_em);
% 构造 datetime 并显式指定时区为 UTC
em_table.datetime = datetime(em_table.year, 1, 1, 0, 0, 0) + ...
    days(em_table.day - 1) + hours(em_table.hour) + minutes(em_table.minute);
em_table.datetime.TimeZone = 'UTC'; 

% --- 2.2 加载 Hp30 (修复时区冲突) ---
file_hp30 = fullfile(AUX_DATA_PATH, 'hp30_data_19970101_20250930.csv');
if ~isfile(file_hp30), error('文件缺失: %s', file_hp30); end
hp30_table = readtable(file_hp30);

% [修复] 健壮的时间转换逻辑
if isdatetime(hp30_table.Timestamp_UTC)
    if isempty(hp30_table.Timestamp_UTC.TimeZone)
        hp30_table.Timestamp_UTC.TimeZone = 'UTC';
    end
else
    hp30_table.Timestamp_UTC = datetime(hp30_table.Timestamp_UTC, 'TimeZone', 'UTC');
end

t_ref_2000_dt = datetime(2000, 1, 1, 0, 0, 0, 'TimeZone', 'UTC');
hp30_vals = [days(hp30_table.Timestamp_UTC - t_ref_2000_dt), hp30_table.Hp30_Value];

% --- 2.3 加载 RC Index ---
file_rc = fullfile(AUX_DATA_PATH, 'RC_1997-2025_Sept25_v3_allLT.dat');
if ~isfile(file_rc), error('文件缺失: %s', file_rc); end
rc_data = readmatrix(file_rc, 'FileType', 'text', 'NumHeaderLines', 7);
[t_rc_sort, idx] = sort(rc_data(:,1));
drc_dt = gradient(rc_data(idx,2), t_rc_sort * 24.0);
rc_deriv = [t_rc_sort, drc_dt];

fprintf('   辅助数据加载完成。\n');

%% ------------------- 3. 统一流读取 (15s降采样) -------------------
disp('3. 数据读取：双星同步 -> 15s降采样 (不再计算均值)...');

global_data_container = {}; 

% --- 步骤 A: 扫描文件并提取日期 ---
fprintf('   正在扫描文件夹以建立同步列表...\n');
files_struct1 = dir(fullfile(data_folders{1}, '*.cdf'));
files_struct2 = dir(fullfile(data_folders{2}, '*.cdf'));

names1 = {files_struct1.name}; names2 = {files_struct2.name};
extract_date_func = @(x) regexp(x, '_(\d{8})T', 'tokens', 'once');

dates1 = cell(size(names1));
for i = 1:length(names1), tok = extract_date_func(names1{i}); if ~isempty(tok), dates1{i}=tok{1}; else, dates1{i}=''; end; end
dates2 = cell(size(names2));
for i = 1:length(names2), tok = extract_date_func(names2{i}); if ~isempty(tok), dates2{i}=tok{1}; else, dates2{i}=''; end; end

common_dates = intersect(dates1, dates2);
common_dates = common_dates(~cellfun('isempty', common_dates));

if isempty(common_dates), error('未找到共有日期的文件！'); end

% --- 步骤 B: 采样控制 ---
if ENABLE_RANDOM_SAMPLING
    rng(42); 
    n_samp = max(1, round(length(common_dates) * RANDOM_SAMPLE_RATIO));
    target_dates = common_dates(sort(randperm(length(common_dates), n_samp)));
    fprintf('   [随机模式] 选中 %d 天\n', n_samp);
else
    target_dates = common_dates;
    fprintf('   [全量模式] 选中 %d 天\n', length(common_dates));
end
target_date_set = string(target_dates); 

% --- 步骤 C: 读取并直接降采样 ---
for yr_idx = 1:length(data_folders)
    curr_folder = data_folders{yr_idx};
    if contains(curr_folder, 'GraceFO1') || contains(curr_folder, 'GF1'), sat_id = 1; else, sat_id = 2; end
    
    if sat_id == 1, curr_files = files_struct1; c_dates = string(dates1);
    else,           curr_files = files_struct2; c_dates = string(dates2); end
    
    [is_target, ~] = ismember(c_dates, target_date_set);
    files_to_process = curr_files(is_target);
    [~, sort_idx] = sort({files_to_process.name});
    files_to_process = files_to_process(sort_idx);
    
    num_files = length(files_to_process);
    if num_files == 0, continue; end
    
    fprintf('   -> 读取卫星 %d (%d 文件)...\n', sat_id, num_files);
    
    sat_data_cell = cell(num_files, 1);
    
    q = parallel.pool.DataQueue;
    afterEach(q, @(~) fprintf('.')); 
    fprintf('      进度: ');

    parfor k = 1:num_files
        % 读取并按 BINNING_WINDOW_SEC (15s) 抽稀
        raw = process_single_cdf_file(files_to_process(k), curr_folder, ref_dn_2000, BINNING_WINDOW_SEC);
        if isempty(raw), continue; end
        
        % 数据结构: [Lat, Lon, Rad, B_NEC(3), t_dn, F, SatID]
        data_chunk = [raw(:,1:3), raw(:,4:6), raw(:,7), raw(:,8), ones(size(raw,1),1)*sat_id];
        sat_data_cell{k} = data_chunk;
        send(q, k);
    end
    fprintf('\n');
    global_data_container = [global_data_container; sat_data_cell(~cellfun('isempty', sat_data_cell))];
end

% --------------------- 数据合并 ---------------------
disp('   正在合并所有降采样数据...');
all_data = vertcat(global_data_container{:});
[~, sort_t_idx] = sort(all_data(:,7)); 
all_data = all_data(sort_t_idx, :);
clear global_data_container;

% 变量标准化
lat_obs = all_data(:,1); lon_obs = all_data(:,2); r_obs = all_data(:,3);
bnec_obs= all_data(:,4:6); t_dn = all_data(:,7); F_obs = all_data(:,8);
sat_id_obs = all_data(:,9);

t_mjd = t_dn - ref_dn_2000;
t_utc = datetime(t_dn, 'ConvertFrom', 'datenum', 'TimeZone', 'UTC');

total_points = length(lat_obs);
fprintf('   15s降采样数据准备完毕。总点数: %d\n', total_points);

%% ------------------- 4. 前置筛选 (基于降采样数据) -------------------
disp('4. 执行前置筛选 (Night, RC, Hp30, Em/Bz)...');

% --- 4.1 夜间筛选 ---
[sun_vec_GEI, GST] = sunGEI(t_mjd);
theta_rad = deg2rad(90 - lat_obs); phi_rad = deg2rad(lon_obs);      
sat_x = sin(theta_rad) .* cos(phi_rad); sat_y = sin(theta_rad) .* sin(phi_rad); sat_z = cos(theta_rad);

cos_gst = cos(GST); sin_gst = sin(GST);
sat_vec_GEI_x = sat_x .* cos_gst - sat_y .* sin_gst;
sat_vec_GEI_y = sat_x .* sin_gst + sat_y .* cos_gst;
sat_vec_GEI_z = sat_z;

cos_theta = sun_vec_GEI(:,1) .* sat_vec_GEI_x + sun_vec_GEI(:,2) .* sat_vec_GEI_y + sun_vec_GEI(:,3) .* sat_vec_GEI_z;
mask_night = rad2deg(acos(max(min(cos_theta, 1), -1))) > 100;

% --- 4.2 RC/Hp30/DF/OMNI 筛选 ---
drc_val = interp1(rc_deriv(:,1), rc_deriv(:,2), t_mjd, 'linear', 'extrap');
mask_rc = abs(drc_val) <= 2;

hp_val = interp1(hp30_vals(:,1), hp30_vals(:,2), t_mjd, 'nearest', 'extrap');
mask_hp = hp_val <= 2;

mask_df = abs(F_obs - vecnorm(bnec_obs,2,2)) <= 100;

sat_min = dateshift(t_utc, 'start', 'minute');
[~, loc] = ismember(sat_min, em_table.datetime);
valid_omni = loc > 0;

mask_em = false(size(mask_night)); mask_bz = false(size(mask_night));
if any(valid_omni)
    matched_idx = loc(valid_omni);
    mask_em(valid_omni) = em_table.avg_em_2h(matched_idx) <= 0.8;
    mask_bz(valid_omni) = em_table.avg_bz_2h(matched_idx) > 0;
end

mask_pre_calc = mask_night & mask_rc & mask_hp & mask_df & mask_em & mask_bz;
fprintf('   前置筛选通过: %d / %d (%.1f%%)\n', sum(mask_pre_calc), total_points, sum(mask_pre_calc)/total_points*100);

%% ------------------- 5. CHAOS 计算 (仅针对有效点) -------------------
disp('5. 计算 CHAOS 背景场 (仅计算筛选通过点)...');

idx_calc = find(mask_pre_calc);
if isempty(idx_calc), error('前置筛选后无数据！'); end

% 提取子集
t_sub = t_mjd(idx_calc); r_sub = r_obs(idx_calc);
lat_sub = lat_obs(idx_calc); lon_sub = lon_obs(idx_calc);

addpath('CHAOS-8.4_FWD\'); 
try load('CHAOS-8.4.mat'); catch, error('CHAOS mat missing'); end

% 配置 CHAOS
N_core=20; pp_core=pp; pp_core.dim=N_core*(N_core+2); 
coefs_tmp=reshape(pp.coefs,[],pp.pieces,pp.order);
pp_core.coefs=reshape(coefs_tmp(1:N_core*(N_core+2),:,:),[],pp.order);
g_crust=g(1:(110*(110+2))); mod_ext=model_ext; dip=[-29442.0, -1501.0, 4797.1];
RC_interp = interp1(rc_data(:,1), rc_data(:,3:4), t_sub, 'linear');

% 并行计算
n_sub = length(t_sub);
chunk_size = 50000;
num_chunks = ceil(n_sub / chunk_size);
out_B = cell(num_chunks, 1);

parfor i = 1:num_chunks
    c_idx = (i-1)*chunk_size+1 : min(i*chunk_size, n_sub);
    th_d = 90 - lat_sub(c_idx);
    B_c = synth_values(r_sub(c_idx), th_d, lon_sub(c_idx), pp_core, t_sub(c_idx));
    B_k = synth_values(r_sub(c_idx), th_d, lon_sub(c_idx), g_crust);
    B_e = synth_values_CHAOS_ext(t_sub(c_idx), r_sub(c_idx), th_d, lon_sub(c_idx), ...
        RC_interp(c_idx,:), mod_ext, dip, 'GSM_SM_SHA_3D_IGRF12_2015.mat');
    out_B{i} = B_c + B_k + B_e;
end
B_model_sub = vertcat(out_B{:});
clear pp_core g g_crust out_B;

% 计算残差
bnec_sub = bnec_obs(idx_calc, :);
B_obs_vec_sub = [-bnec_sub(:,3), -bnec_sub(:,1), bnec_sub(:,2)]; 
B_res_sub = B_obs_vec_sub - B_model_sub;
F_mod_sub = vecnorm(B_model_sub, 2, 2);
dF_res_sub = F_obs(idx_calc) - F_mod_sub;

fprintf('   计算 QD 纬度...\n');
QD_lat_sub = calculate_QD_Lat(B_model_sub, r_sub);
Dir_sub = B_model_sub ./ F_mod_sub;

%% ------------------- 6. 后置筛选 (By, 粗差) -------------------
disp('6. 执行后置筛选...');

loc_sub = loc(idx_calc);
valid_omni_sub = loc_sub > 0;
mask_by_sub = false(size(QD_lat_sub));
if any(valid_omni_sub)
    by_vals = em_table.avg_by_2h(loc_sub(valid_omni_sub));
    qd_check = QD_lat_sub(valid_omni_sub);
    is_north = qd_check > 0;
    tmp_pass = false(size(qd_check));
    tmp_pass(is_north) = by_vals(is_north) < 3;
    tmp_pass(~is_north) = by_vals(~is_north) > -3;
    mask_by_sub(valid_omni_sub) = tmp_pass;
end

mask_gross_sub = false(size(QD_lat_sub));
mask_low = abs(QD_lat_sub) < 55;
mask_gross_sub(mask_low) = (vecnorm(B_res_sub(mask_low,:),2,2) < 40) & (abs(dF_res_sub(mask_low)) < 40);
mask_gross_sub(~mask_low) = abs(dF_res_sub(~mask_low)) < 40;

mask_final_sub = mask_by_sub & mask_gross_sub;
idx_final_rel = find(mask_final_sub);

% 提取最终变量
t_fin = t_sub(idx_final_rel);
r_fin = r_sub(idx_final_rel); lat_fin = lat_sub(idx_final_rel); lon_fin = lon_sub(idx_final_rel);
qd_fin = QD_lat_sub(idx_final_rel);
sat_fin = sat_id_obs(idx_calc(idx_final_rel));
B_res_fin = B_res_sub(idx_final_rel, :);
dF_res_fin = dF_res_sub(idx_final_rel);
Dir_fin = Dir_sub(idx_final_rel, :);

fprintf('   最终保留数据点: %d\n', length(t_fin));

%% ------------------- 7. 保存绝对数据 -------------------
disp('7. 保存绝对数据 (Weighted)...');

mask_vec = abs(qd_fin) < 55;
mask_sca = abs(qd_fin) >= 55;

Data_Vector_Orig = struct('Time', t_fin(mask_vec), ...
    'Pos', [r_fin(mask_vec), 90-lat_fin(mask_vec), lon_fin(mask_vec)], ...
    'B_res', B_res_fin(mask_vec,:), 'QD_Lat', qd_fin(mask_vec), ...
    'SatID', sat_fin(mask_vec), 'Weight', ones(sum(mask_vec),1));

Data_Scalar_Orig = struct('Time', t_fin(mask_sca), ...
    'Pos', [r_fin(mask_sca), 90-lat_fin(mask_sca), lon_fin(mask_sca)], ...
    'dF', dF_res_fin(mask_sca), 'Dir', Dir_fin(mask_sca,:), ...
    'QD_Lat', qd_fin(mask_sca), 'SatID', sat_fin(mask_sca), ...
    'Weight', ones(sum(mask_sca),1));

save('GraceFO_ACC_Input_Original_Weighted.mat', 'Data_Vector_Orig', 'Data_Scalar_Orig');

%% ------------------- 8. 单星梯度计算 (15s间隔) -------------------
disp('8. 计算单星梯度 (15s间隔)...');

vec_grad_structs = []; sca_grad_structs = [];
sat_list = unique(sat_fin);

for s_idx = 1:length(sat_list)
    curr_sat = sat_list(s_idx);
    idx_sat = find(sat_fin == curr_sat);
    if length(idx_sat) < 2, continue; end
    
    % 提取单星数据
    t_c = t_fin(idx_sat);
    r_c = r_fin(idx_sat); lat_c = lat_fin(idx_sat); lon_c = lon_fin(idx_sat);
    B_c = B_res_fin(idx_sat, :); dF_c = dF_res_fin(idx_sat);
    Dir_c = Dir_fin(idx_sat, :); qd_c = qd_fin(idx_sat);
    
    % 寻找15s间隔点对
    dt_sec = diff(t_c) * 86400;
    valid_pairs = find(abs(dt_sec - 15) <= 0.1);
    
    if isempty(valid_pairs), continue; end
    i1 = valid_pairs; i2 = valid_pairs + 1;
    
    g_v = B_c(i2,:) - B_c(i1,:);
    g_s = dF_c(i2) - dF_c(i1);
    
    % 筛选
    mask_gv = (abs(qd_c(i1)) < 55) & (vecnorm(g_v, 2, 2) < 15);
    mask_gs = (abs(g_s) < 15);
    
    if sum(mask_gv) > 0
        idx1 = i1(mask_gv); idx2 = i2(mask_gv);
        S_vec = struct('Time1', t_c(idx1), 'Time2', t_c(idx2), ...
            'Pos1', [r_c(idx1), 90-lat_c(idx1), lon_c(idx1)], ...
            'Pos2', [r_c(idx2), 90-lat_c(idx2), lon_c(idx2)], ...
            'd_grad', g_v(mask_gv,:), 'QD_Lat', qd_c(idx1), ...
            'SatID', curr_sat*ones(length(idx1),1), 'Weight', ones(length(idx1),1));
        vec_grad_structs = [vec_grad_structs; S_vec]; %#ok<AGROW>
    end
    
    if sum(mask_gs) > 0
        idx1 = i1(mask_gs); idx2 = i2(mask_gs);
        S_sca = struct('Time1', t_c(idx1), 'Time2', t_c(idx2), ...
            'Pos1', [r_c(idx1), 90-lat_c(idx1), lon_c(idx1)], ...
            'Pos2', [r_c(idx2), 90-lat_c(idx2), lon_c(idx2)], ...
            'd_grad', g_s(mask_gs), 'Dir', Dir_c(idx1,:), ...
            'QD_Lat', qd_c(idx1), ...
            'SatID', curr_sat*ones(length(idx1),1), 'Weight', ones(length(idx1),1));
        sca_grad_structs = [sca_grad_structs; S_sca]; %#ok<AGROW>
    end
end

if isempty(vec_grad_structs), Data_Vector_Grad=[]; else, fns=fieldnames(vec_grad_structs); for f=1:length(fns), Data_Vector_Grad.(fns{f})=vertcat(vec_grad_structs.(fns{f})); end; end
if isempty(sca_grad_structs), Data_Scalar_Grad=[]; else, fns=fieldnames(sca_grad_structs); for f=1:length(fns), Data_Scalar_Grad.(fns{f})=vertcat(sca_grad_structs.(fns{f})); end; end

save('GraceFO_ACC_Input_Gradient_Weighted.mat', 'Data_Vector_Grad', 'Data_Scalar_Grad');
fprintf('   单星梯度计算完成。\n');

%% ------------------- 9. 星间梯度计算 (时间同步瞬时空间梯度 + 距离验证) -------------------
disp('9. 计算星间梯度 (基于时间同步的瞬时空间梯度 + 距离验证)...');

% 检查两颗卫星数据是否都存在
has_GF1 = any(sat_fin == 1);  % 对应您的sat_fin变量
has_GF2 = any(sat_fin == 2);

if has_GF1 && has_GF2
    fprintf('   检测到双星数据: GF1=%d个点, GF2=%d个点\n', ...
        sum(sat_fin == 1), sum(sat_fin == 2));
    
    % 1. 分离两颗卫星的数据
    idx_GF1 = find(sat_fin == 1);
    idx_GF2 = find(sat_fin == 2);
    
    % 提取卫星1(GF1)的基础数据
    t_GF1 = t_fin(idx_GF1);  % 时间 (MJD2000)
    r_GF1 = r_fin(idx_GF1);  % 地心距离 (m)
    lat_GF1 = lat_fin(idx_GF1);  % 纬度 (deg)
    lon_GF1 = lon_fin(idx_GF1);  % 经度 (deg)
    colat_GF1 = 90 - lat_GF1;    % 余纬度 (deg)
    
    B_res_GF1 = B_res_fin(idx_GF1, :);  % 矢量残差
    dF_res_GF1 = dF_res_fin(idx_GF1);   % 标量残差
    qd_GF1 = qd_fin(idx_GF1);           % QD纬度
    Dir_GF1 = Dir_fin(idx_GF1, :);      % 方向向量
    
    % 提取卫星2(GF2)的基础数据（用于插值）
    t_GF2 = t_fin(idx_GF2);
    r_GF2 = r_fin(idx_GF2);
    lat_GF2 = lat_fin(idx_GF2);
    lon_GF2 = lon_fin(idx_GF2);
    colat_GF2 = 90 - lat_GF2;
    
    B_res_GF2 = B_res_fin(idx_GF2, :);
    dF_res_GF2 = dF_res_fin(idx_GF2);
    Dir_GF2 = Dir_fin(idx_GF2, :);
    
    fprintf('   原始时间范围: GF1 [%.4f, %.4f] days, GF2 [%.4f, %.4f] days\n', ...
        min(t_GF1), max(t_GF1), min(t_GF2), max(t_GF2));
    
    % 2. 时间同步：将GF2数据插值到GF1的时间点
    % 限制插值范围，避免外推
    t_min = max(min(t_GF1), min(t_GF2));
    t_max = min(max(t_GF1), max(t_GF2));
    
    if t_max <= t_min
        error('双星时间范围不重叠，无法进行时间同步！');
    end
    
    % 筛选GF1中在重叠时间范围内的点
    valid_GF1_mask = (t_GF1 >= t_min) & (t_GF1 <= t_max);
    t_target = t_GF1(valid_GF1_mask);  % GF1的时间点作为目标
    
    % 记录原始的GF1索引（用于最终数据保存）
    final_GF1_idx = idx_GF1(valid_GF1_mask);
    
    fprintf('   时间重叠范围: %.4f ~ %.4f days\n', t_min, t_max);
    fprintf('   将插值 %d 个GF1时间点\n', length(t_target));
    
    % 3. 执行GF2数据的线性插值
    fprintf('   正在进行GF2数据插值...\n');
    
    % 位置参数插值
    r_GF2_int = interp1(t_GF2, r_GF2, t_target, 'linear', 'extrap');
    colat_GF2_int = interp1(t_GF2, colat_GF2, t_target, 'linear', 'extrap');
    
    % 经度处理：防止360/0度跳变
    lon_GF2_unwrapped = unwrap(deg2rad(lon_GF2));
    lon_GF2_int_rad = interp1(t_GF2, lon_GF2_unwrapped, t_target, 'linear', 'extrap');
    lon_GF2_int_deg = rad2deg(mod(lon_GF2_int_rad, 2*pi));
    
    % 磁场数据插值
    B_res_GF2_int = interp1(t_GF2, B_res_GF2, t_target, 'linear', 'extrap');
    dF_res_GF2_int = interp1(t_GF2, dF_res_GF2, t_target, 'linear', 'extrap');
    
    % 方向向量插值
    Dir_GF2_int = zeros(length(t_target), 3);
    Dir_GF2_int(:,1) = interp1(t_GF2, Dir_GF2(:,1), t_target, 'linear', 'extrap');
    Dir_GF2_int(:,2) = interp1(t_GF2, Dir_GF2(:,2), t_target, 'linear', 'extrap');
    Dir_GF2_int(:,3) = interp1(t_GF2, Dir_GF2(:,3), t_target, 'linear', 'extrap');
    % 归一化方向向量
    Dir_GF2_int_norm = Dir_GF2_int ./ sqrt(sum(Dir_GF2_int.^2, 2));
    
    % 4. 计算瞬时空间梯度 (GF2_interp - GF1)
    % 此时：t1 = t2（同一时刻），但位置不同
    B_res_GF1_subset = B_res_GF1(valid_GF1_mask, :);
    dF_res_GF1_subset = dF_res_GF1(valid_GF1_mask);
    Dir_GF1_subset = Dir_GF1(valid_GF1_mask, :);
    
    % 计算梯度
    grad_vec_raw = B_res_GF2_int - B_res_GF1_subset;      % 矢量梯度
    grad_sca_raw = dF_res_GF2_int - dF_res_GF1_subset;   % 标量梯度
    
    % 5. 计算两颗卫星之间的距离
    % 准备位置数据结构
    % 5. 计算两颗卫星之间的距离 - 向量化版本
    
    % 提取位置数据
    lat1_deg = lat_GF1(valid_GF1_mask);    % 纬度 (度)
    lon1_deg = lon_GF1(valid_GF1_mask);    % 经度 (度)
    
    % GF2插值数据：注意colatitude转回latitude
    lat2_deg = 90 - colat_GF2_int;         % 纬度
    lon2_deg = lon_GF2_int_deg;            % 经度
    
    % 地心距离转换为千米
    r1_km = r_GF1(valid_GF1_mask);   % GF1地心距离 (km)
    r2_km = r_GF2_int;               % GF2地心距离 (km)
    
    % 归一化经度到[-180, 180]
    lon1_deg = mod(lon1_deg + 180, 360) - 180;
    lon2_deg = mod(lon2_deg + 180, 360) - 180;
    
    % 限制纬度范围
    lat1_deg = max(min(lat1_deg, 90), -90);
    lat2_deg = max(min(lat2_deg, 90), -90);
    
    % 计算每点对应的平均球面半径
    point_radii_km = (r1_km + r2_km) / 2;
    
    % 使用修改后的Haversine函数（批量处理）
    distances_km = calculate_distance_km_batch(lat1_deg, lon1_deg, lat2_deg, lon2_deg, point_radii_km);
    
    % 检查是否存在异常小距离（可能位置完全相同）
    identical_mask = (abs(lat1_deg - lat2_deg) < 1e-6) & (abs(lon1_deg - lon2_deg) < 1e-6);
    if any(identical_mask)
        fprintf('   警告：发现%d个点的位置几乎完全相同！\n', sum(identical_mask));
        % 对于这些点，距离设置为高度差
        distances_km(identical_mask) = abs(r1_km(identical_mask) - r2_km(identical_mask));
    end

    
    % 距离统计
    fprintf('   星间距离统计: 平均=%.1fkm, 最小值=%.1fkm, 最大值=%.1fkm\n', ...
        mean(distances_km), min(distances_km), max(distances_km));
    
    % 6. 距离筛选（基于GraceFO设计参数）
    MAX_DISTANCE_KM = 220;  % GraceFO最大设计间距
    MIN_DISTANCE_KM = 180;  % GraceFO最小设计间距
    
    dist_mask = (distances_km >= MIN_DISTANCE_KM) & (distances_km <= MAX_DISTANCE_KM);
    fprintf('   距离筛选: %d/%d 个点 (%.1f%%) 在合理范围 [%d, %d]km\n', ...
        sum(dist_mask), length(distances_km), sum(dist_mask)/length(distances_km)*100, ...
        MIN_DISTANCE_KM, MAX_DISTANCE_KM);
    
    if sum(dist_mask) == 0
        warning('距离筛选后无有效数据，请检查卫星轨道参数！');
        return;
    end
    
    % 应用距离筛选
    t_target_filtered = t_target(dist_mask);
    final_GF1_idx_filtered = final_GF1_idx(dist_mask);
    distances_filtered = distances_km(dist_mask);
    
    % 梯度数据筛选
    grad_vec_filtered = grad_vec_raw(dist_mask, :);
    grad_sca_filtered = grad_sca_raw(dist_mask);
    
    % GF1数据筛选（插值后的观测值）
    qd_GF1_filtered = qd_GF1(valid_GF1_mask);
    qd_GF1_filtered = qd_GF1_filtered(dist_mask);
    Dir_GF1_filtered = Dir_GF1_subset(dist_mask, :);
    
    % --- [修复开始] 构建位置矩阵并筛选 ---
    
    % 1. 构建 GF1 在时间重叠区域的完整位置矩阵 [r, colat, lon]
    %    注意：这里需要将 Latitude 转为 Colatitude (90-lat) 以符合后续球谐函数输入要求
    pos_GF1_valid = [r_GF1(valid_GF1_mask), 90 - lat_GF1(valid_GF1_mask), lon_GF1(valid_GF1_mask)];
    
    % 2. 构建 GF2 插值后的完整位置矩阵 [r, colat, lon]
    %    注意：colat_GF2_int 已经是余纬了，不需要用 90 减
    pos_GF2_int_mat = [r_GF2_int, colat_GF2_int, lon_GF2_int_deg];
    
    % 3. 应用距离掩膜 (dist_mask) 进行筛选
    pos_GF1_filtered = pos_GF1_valid(dist_mask, :);
    pos_GF2_filtered = pos_GF2_int_mat(dist_mask, :);
    
    % --- [修复结束] ---
    
    % 7. 梯度筛选（与您之前的筛选条件保持一致）
    grad_vec_mag = vecnorm(grad_vec_filtered, 2, 2);
    grad_sca_mag = abs(grad_sca_filtered);
    
    TOTAL_POINTS = length(qd_GF1_filtered);
    
    % 矢量梯度筛选（仅中低纬度）
    % 使用您的原始阈值
    GRADIENT_THRESHOLD_VEC = 20;  % 对应您原来的<20阈值
    GRADIENT_THRESHOLD_SCA = 15;
    
    mask_vec_lat = abs(qd_GF1_filtered) < 55;  % 中低纬度
    mask_vec_mag = grad_vec_mag < GRADIENT_THRESHOLD_VEC;
    mask_vec = mask_vec_lat & mask_vec_mag;
    
    % 标量梯度筛选（全纬度）
    mask_sca_mag = grad_sca_mag < GRADIENT_THRESHOLD_SCA;
    mask_sca = mask_sca_mag;
    
    fprintf('   梯度筛选结果:\n');
    fprintf('     矢量梯度: %d/%d 通过(%.1f%%), 其中中低纬度: %d\n', ...
        sum(mask_vec), TOTAL_POINTS, sum(mask_vec)/TOTAL_POINTS*100, sum(mask_vec_lat));
    fprintf('     标量梯度: %d/%d 通过(%.1f%%)\n', ...
        sum(mask_sca), TOTAL_POINTS, sum(mask_sca)/TOTAL_POINTS*100);
    
    % 8. 构建输出数据结构
    % 矢量星间梯度（中低纬度）
    if any(mask_vec)
        vec_idx = find(mask_vec);
        Data_Vector_Cross = struct(...
            'Time', t_target_filtered(vec_idx), ...
            'Pos1', pos_GF1_filtered(vec_idx, :), ...  % GF1位置 [r_km, colat_deg, lon_deg]
            'Pos2', pos_GF2_filtered(vec_idx, :), ...  % GF2插值位置
            'd_grad', grad_vec_filtered(vec_idx, :), ...  % 矢量梯度
            'QD_Lat', qd_GF1_filtered(vec_idx), ...      % QD纬度（基于GF1）
            'Weight', ones(length(vec_idx), 1), ...      % 权重
            'Distance_km', distances_filtered(vec_idx) ... % 星间距离
        );
    else
        Data_Vector_Cross = [];
        warning('矢量星间梯度无有效数据！');
    end
    
    % 标量星间梯度（全纬度）
    if any(mask_sca)
        sca_idx = find(mask_sca);
        Data_Scalar_Cross = struct(...
            'Time', t_target_filtered(sca_idx), ...
            'Pos1', pos_GF1_filtered(sca_idx, :), ...  % GF1位置
            'Pos2', pos_GF2_filtered(sca_idx, :), ...  % GF2插值位置
            'd_grad', grad_sca_filtered(sca_idx), ...   % 标量梯度
            'Dir', Dir_GF1_filtered(sca_idx, :), ...    % 方向向量（GF1）
            'QD_Lat', qd_GF1_filtered(sca_idx), ...     % QD纬度
            'Weight', ones(length(sca_idx), 1), ...     % 权重
            'Distance_km', distances_filtered(sca_idx) ... % 星间距离
        );
    else
        Data_Scalar_Cross = [];
        warning('标量星间梯度无有效数据！');
    end
    
    % 9. 可视化验证（可选）
    try
        figure('Position', [100 100 1200 800], 'Name', '星间梯度验证');
        
        % 子图1：距离分布
        subplot(2,3,1);
        histogram(distances_filtered, 30, 'FaceColor', [0.2 0.6 0.8]);
        xlabel('双星距离 (km)');
        ylabel('频次');
        title(sprintf('星间距离分布 (n=%d)', length(distances_filtered)));
        grid on;
        hold on;
        xline(200, 'r--', 'LineWidth', 2, 'DisplayName', '标称200km');
        legend('Location', 'best');
        
        % 子图2：距离vs时间
        subplot(2,3,2);
        scatter(t_target_filtered, distances_filtered, 10, 'filled', 'MarkerFaceAlpha', 0.5);
        xlabel('时间 (MJD2000 days)');
        ylabel('距离 (km)');
        title('距离随时间变化');
        grid on;
        ylim([0 400]);
        
        % 子图3：梯度幅度分布
        subplot(2,3,3);
        if ~isempty(Data_Vector_Cross)
            histogram(vecnorm(Data_Vector_Cross.d_grad, 2, 2), 30, ...
                'FaceColor', 'b', 'FaceAlpha', 0.6);
            hold on;
        end
        if ~isempty(Data_Scalar_Cross)
            histogram(abs(Data_Scalar_Cross.d_grad), 30, ...
                'FaceColor', 'r', 'FaceAlpha', 0.6);
        end
        xlabel('梯度幅度 (nT)');
        ylabel('频次');
        title('梯度幅度分布');
        legend('矢量', '标量');
        grid on;
        
        % 子图4：纬度分布
        subplot(2,3,4);
        histogram(qd_GF1_filtered, 30, 'FaceColor', [0.8 0.4 0.1]);
        xlabel('QD纬度 (°)');
        ylabel('频次');
        title('QD纬度分布');
        grid on;
        
        % 子图5：距离vsQD纬度
        subplot(2,3,5);
        scatter(qd_GF1_filtered, distances_filtered, 10, 'filled', ...
            'MarkerFaceAlpha', 0.5);
        xlabel('QD纬度 (°)');
        ylabel('距离 (km)');
        title('距离vs纬度');
        grid on;
        ylim([0 400]);
        
        % 子图6：梯度vs距离
        subplot(2,3,6);
        if ~isempty(Data_Vector_Cross)
            scatter(distances_filtered(mask_vec), ...
                vecnorm(Data_Vector_Cross.d_grad, 2, 2), 10, 'b', 'filled', ...
                'MarkerFaceAlpha', 0.5);
            hold on;
        end
        if ~isempty(Data_Scalar_Cross)
            scatter(distances_filtered(mask_sca), ...
                abs(Data_Scalar_Cross.d_grad), 10, 'r', 'filled', ...
                'MarkerFaceAlpha', 0.5);
        end
        xlabel('距离 (km)');
        legend('矢量', '标量');
        grid on;
        scatter(distances_filtered, vecnorm(grad_vec_filtered, 2, 2), 10, ...
            'b', 'filled', 'MarkerFaceAlpha', 0.3);
        hold on;
        scatter(distances_filtered, abs(grad_sca_filtered), 10, ...
            'r', 'filled', 'MarkerFaceAlpha', 0.3);
        xlabel('星间距离 (km)');
        ylabel('梯度幅度 (nT)');
        title('梯度幅度vs距离');
        legend('矢量', '标量');
        grid on;
        
        % 保存图像
        saveas(gcf, 'cross_satellite_validation.png');
        close(gcf);
        fprintf('   验证图已保存为 cross_satellite_validation.png\n');
    catch ME
        fprintf('   绘图失败: %s\n', ME.message);
    end
    
    % 10. 保存数据
    save('GraceFO_CrossSat_Gradient_Weighted.mat', 'Data_Vector_Cross', 'Data_Scalar_Cross');
    fprintf('   星间梯度计算完成并保存！\n');
    fprintf('   - 矢量梯度: %d 个点\n', length(Data_Vector_Cross.Time));
    fprintf('   - 标量梯度: %d 个点\n', length(Data_Scalar_Cross.Time));
    if ~isempty(Data_Vector_Cross)
        fprintf('   - 星间距离: %.1f ± %.1f km\n', ...
            mean(Data_Vector_Cross.Distance_km), std(Data_Vector_Cross.Distance_km));
    end
    
else
    fprintf('   警告：数据中缺少双星数据，跳过星间梯度计算\n');
    Data_Vector_Cross = [];
    Data_Scalar_Cross = [];
end


plot_weight_verification_final();
disp('全部流程执行完毕。');
toc;


function dist_km = calculate_distance_km_batch(lat1_deg, lon1_deg, lat2_deg, lon2_deg, r_km)
    % 批量计算球面距离
    % 所有输入都是向量，长度相同
    
    % 转换为弧度
    lat1 = deg2rad(lat1_deg(:));
    lon1 = deg2rad(lon1_deg(:));
    lat2 = deg2rad(lat2_deg(:));
    lon2 = deg2rad(lon2_deg(:));
    r = r_km(:);
    
    % Haversine公式计算中心角
    dlat = lat2 - lat1;
    dlon = lon2 - lon1;
    a = sin(dlat/2).^2 + cos(lat1) .* cos(lat2) .* sin(dlon/2).^2;
    c = 2 * atan2(sqrt(a), sqrt(1-a));
    
    % 计算弧长距离
    dist_km = r .* c;
end



