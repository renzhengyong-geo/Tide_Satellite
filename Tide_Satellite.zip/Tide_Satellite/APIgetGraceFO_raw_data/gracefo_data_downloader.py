import requests
import os
import re
import argparse
from datetime import datetime, timedelta
import logging
import shutil
from tqdm import tqdm

# 配置日志记录
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('gracefo_download.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('GraceFODownloader')

class GraceFODownloader:
    def __init__(self):
        self.base_url = "https://isdc-data.gfz.de/grace-fo/MAGNETIC_FIELD/0201/"
        self.gf1_save_path = "E:\\A_graduate\\code_and_program\\Satellite_data_processing\\Satellite_Data\\TEST_GRACEFO\\GraceFO1"
        self.gf2_save_path = "E:\\A_graduate\\code_and_program\\Satellite_data_processing\\Satellite_Data\\TEST_GRACEFO\\GraceFO2"
        
        # 确保保存路径存在
        os.makedirs(self.gf1_save_path, exist_ok=True)
        os.makedirs(self.gf2_save_path, exist_ok=True)
        
        # 数据文件正则表达式
        self.file_pattern = re.compile(r"(GF1|GF2)_OPER_FGM_ACAL_CORR_(\d{8}T\d{6})_(\d{8}T\d{6})_0201\.cdf")
    
    def get_file_list(self, satellite):
        """
        获取指定卫星的文件列表
        """
        url = f"{self.base_url}{satellite}/ACAL_CORR/"
        try:
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            return response.text
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to get file list for {satellite}: {e}")
            return ""
    
    def parse_file_list(self, html_content):
        """
        解析HTML内容，提取文件名和日期
        """
        files = []
        for match in self.file_pattern.finditer(html_content):
            satellite = match.group(1)
            start_time = datetime.strptime(match.group(2), "%Y%m%dT%H%M%S")
            end_time = datetime.strptime(match.group(3), "%Y%m%dT%H%M%S")
            filename = match.group(0)
            files.append((satellite, filename, start_time, end_time))
        return files
    
    def download_file(self, url, save_path):
        """
        下载文件，支持断点续传和进度显示
        """
        try:
            response = requests.get(url, stream=True, timeout=60)
            response.raise_for_status()
            
            file_size = int(response.headers.get('content-length', 0))
            
            # 检查文件是否已存在且大小相同
            if os.path.exists(save_path):
                existing_size = os.path.getsize(save_path)
                if existing_size == file_size:
                    logger.info(f"File already exists and is complete: {save_path}")
                    return True
                else:
                    logger.info(f"Resuming download for: {save_path}")
                    headers = {'Range': f'bytes={existing_size}-'}
                    response = requests.get(url, headers=headers, stream=True, timeout=60)
            
            with open(save_path, 'ab') as f, tqdm(
                desc=os.path.basename(save_path),
                total=file_size,
                unit='B',
                unit_scale=True,
                unit_divisor=1024,
            ) as bar:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        bar.update(len(chunk))
            
            logger.info(f"Successfully downloaded: {save_path}")
            return True
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to download {url}: {e}")
            return False
        except Exception as e:
            logger.error(f"Error during file download: {e}")
            return False
    
    def download_data(self, start_date, end_date):
        """
        下载指定时间范围内的数据
        """
        logger.info(f"Starting download for period: {start_date} to {end_date}")
        
        # 转换为datetime对象
        if isinstance(start_date, str):
            start_date = datetime.strptime(start_date, "%Y-%m-%d")
        if isinstance(end_date, str):
            end_date = datetime.strptime(end_date, "%Y-%m-%d")
        
        # 获取两个卫星的文件列表
        satellites = ["GF1", "GF2"]
        all_files = []
        
        for satellite in satellites:
            html_content = self.get_file_list(satellite)
            if html_content:
                files = self.parse_file_list(html_content)
                all_files.extend(files)
        
        # 过滤出指定时间范围内的文件
        filtered_files = []
        for satellite, filename, start_time, end_time in all_files:
            # 检查文件日期是否在指定范围内
            file_date = start_time.date()
            if start_date.date() <= file_date <= end_date.date():
                filtered_files.append((satellite, filename))
        
        logger.info(f"Found {len(filtered_files)} files to download")
        
        # 开始下载
        success_count = 0
        fail_count = 0
        
        for satellite, filename in filtered_files:
            # 构建下载URL和保存路径
            url = f"{self.base_url}{satellite}/ACAL_CORR/{filename}"
            if satellite == "GF1":
                save_path = os.path.join(self.gf1_save_path, filename)
            else:
                save_path = os.path.join(self.gf2_save_path, filename)
            
            # 下载文件
            if self.download_file(url, save_path):
                success_count += 1
            else:
                fail_count += 1
        
        logger.info(f"Download completed. Success: {success_count}, Failed: {fail_count}")
        return success_count, fail_count

def main():
    """
    主函数
    """
    parser = argparse.ArgumentParser(description='GraceFO Satellite Magnetic Field Data Downloader')
    parser.add_argument('--start-date', type=str, default='2025-05-01', 
                        help='Start date for data download (YYYY-MM-DD), default: 2025-05-01')
    parser.add_argument('--end-date', type=str, default=datetime.now().strftime('%Y-%m-%d'),
                        help='End date for data download (YYYY-MM-DD), default: today')
    args = parser.parse_args()
    
    downloader = GraceFODownloader()
    
    print("GraceFO Satellite Magnetic Field Data Downloader")
    print("=" * 50)
    print(f"Download period: {args.start_date} to {args.end_date}")
    print("=" * 50)
    
    try:
        # 验证日期格式
        start_date = datetime.strptime(args.start_date, "%Y-%m-%d")
        end_date = datetime.strptime(args.end_date, "%Y-%m-%d")
        
        if start_date > end_date:
            print("Error: Start date must be earlier than end date")
            return
        
        # 开始下载
        downloader.download_data(start_date, end_date)
        
    except ValueError as e:
        print(f"Error: Invalid date format. Please use YYYY-MM-DD. {e}")
        logger.error(f"Invalid date input: {e}")
    except KeyboardInterrupt:
        print("\nDownload interrupted by user")
        logger.info("Download interrupted by user")
    except Exception as e:
        print(f"Unexpected error: {e}")
        logger.error(f"Unexpected error: {e}")

if __name__ == "__main__":
    main()