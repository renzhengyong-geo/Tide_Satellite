import os
import sys
from spacepy import pycdf
import logging
import re

# 配置日志记录
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('cdf_integrity_check.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('CDFIntegrityChecker')

# CDF文件正则表达式，用于提取日期信息
cdf_pattern = re.compile(r"(GF1|GF2)_OPER_FGM_ACAL_CORR_(\d{8}T\d{6})_(\d{8}T\d{6})_0201\.cdf")

def check_cdf_integrity(file_path):
    """
    检查单个CDF文件的完整性
    """
    try:
        with pycdf.CDF(file_path) as cdf_file:
            # 尝试读取一些基本信息来验证文件完整性
            keys = list(cdf_file.keys())
            if keys:
                # 尝试读取第一个变量的一些数据
                first_var = keys[0]
                data = cdf_file[first_var][:10]  # 只读取前10个数据点
        logger.info(f"File {os.path.basename(file_path)} is valid")
        return True
    except Exception as e:
        logger.error(f"File {os.path.basename(file_path)} is corrupt: {e}")
        return False

def check_all_cdfs(folder_paths):
    """
    检查多个文件夹中所有CDF文件的完整性
    """
    corrupt_files = []
    
    for folder_path in folder_paths:
        logger.info(f"Checking CDF files in {folder_path}")
        
        # 遍历文件夹中的所有文件
        for filename in os.listdir(folder_path):
            if filename.endswith('.cdf'):
                file_path = os.path.join(folder_path, filename)
                if not check_cdf_integrity(file_path):
                    # 提取卫星类型和日期信息
                    match = cdf_pattern.match(filename)
                    if match:
                        satellite = match.group(1)
                        start_time_str = match.group(2)
                        end_time_str = match.group(3)
                        corrupt_files.append((satellite, filename, file_path, start_time_str, end_time_str))
                    else:
                        logger.error(f"Filename {filename} doesn't match expected pattern")
    
    return corrupt_files

def main():
    # 要检查的文件夹路径
    folder_paths = [
        "E:\A_graduate\code_and_program\Satellite_data_processing\Satellite_Data\GraceFO1",
        "E:\A_graduate\code_and_program\Satellite_data_processing\Satellite_Data\GraceFO2"
    ]
    
    # 检查所有CDF文件
    corrupt_files = check_all_cdfs(folder_paths)
    
    # 输出结果
    if corrupt_files:
        logger.warning(f"Found {len(corrupt_files)} corrupt CDF files:")
        for satellite, filename, file_path, start_time, end_time in corrupt_files:
            logger.warning(f"  - {filename} in {os.path.dirname(file_path)}")
        
        # 将损坏文件信息保存到文件，供下载脚本使用
        with open('corrupt_files.txt', 'w') as f:
            for satellite, filename, file_path, start_time, end_time in corrupt_files:
                f.write(f"{satellite},{filename},{start_time},{end_time}\n")
        
        logger.info("Corrupt files information saved to corrupt_files.txt")
        return 1  # 返回非零值表示找到损坏文件
    else:
        logger.info("All CDF files are valid")
        return 0

if __name__ == "__main__":
    sys.exit(main())