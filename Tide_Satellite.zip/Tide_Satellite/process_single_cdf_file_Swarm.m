function processed_data = process_single_cdf_file_Swarm(file_info, curr_folder, ~, data_step)
% process_single_cdf_file_Swarm (v23_Tidal_Modeling_Standard)
% 针对潮汐磁场反演(Weak Signal Detection)优化的专业版本
% 
% 核心逻辑：
% 1. 分箱平均 (Bin Averaging)：避免滤波器带来的 Gibbs 震荡污染弱信号。
% 2. 经度修复：使用 atan2(sin, cos) 解决 +/-180 度跳变。
% 3. 硬约束：箱内有效点数必须 >= 10 (保证统计显著性)。
% 4. 权重支持：额外输出箱内磁场标准差 (STD)，用于反演时的加权最小二乘法。

processed_data = [];
if contains(file_info.name, 'empty', 'IgnoreCase', true), return; end

full_path = fullfile(curr_folder, file_info.name);
orig_warn_state = warning; 

try
    % =========================================================================
    % 1. 读取原始数据
    % =========================================================================
    target_vars = {'Timestamp', 'Latitude', 'Longitude', 'Radius', 'F', 'B_NEC', ...
                   'Flags_F', 'Flags_B', 'Flags_q', 'Flags_Platform'};
    
    warning('off', 'all');
    try
        cdf_data = cdfread(full_path, 'Variables', target_vars, ...
            'CombineRecords', true, 'ConvertEpochToDatenum', true);
    catch
        warning(orig_warn_state); return;
    end
    if isempty(cdf_data), warning(orig_warn_state); return; end
    
    raw_t        = double(cdf_data{1});
    raw_lat      = double(cdf_data{2});
    raw_lon      = double(cdf_data{3});
    raw_r        = double(cdf_data{4});
    raw_F        = double(cdf_data{5});
    raw_B        = double(cdf_data{6}); 
    raw_flg_F    = double(cdf_data{7});
    raw_flg_B    = double(cdf_data{8});
    raw_flg_q    = double(cdf_data{9});
    
    if size(raw_B, 2) ~= 3, raw_B = raw_B'; end
    if mean(raw_r, 'omitnan') > 1000000, raw_r = raw_r / 1000; end
    
    % 标量缺失处理
    B_mag = sqrt(sum(raw_B.^2, 2)); 
    is_missing_F = isnan(raw_F) | (raw_F < 1.0) | (raw_F > 70000);
    raw_F(is_missing_F) = B_mag(is_missing_F);

    % =========================================================================
    % 2. 严格质量控制 (Quality Control)
    % =========================================================================
    if file_info.sat_id == 3
        mask_B_good = (raw_flg_B <= 30); % Swarm C 特例：放宽 ASM-VFM 差异
    else
        mask_B_good = (raw_flg_B <= 1);  % Swarm A/B：只接受 Nominal 或 ASM off
    end
    
    mask_F_good    = (file_info.sat_id == 3) | (raw_flg_F <= 1);
    mask_q_good    = (raw_flg_q < 30);  % 剔除姿态严重丢失
    mask_geo_valid = (raw_r > 6400) & (raw_r < 7500); % 地理范围检查

    valid_mask = mask_B_good & mask_F_good & mask_q_good & mask_geo_valid & ...
                 ~isnan(raw_lat) & ~isnan(raw_t) & ~isnan(raw_F);
    
    if sum(valid_mask) < 10, warning(orig_warn_state); return; end
             
    t_clean   = raw_t(valid_mask);
    lat_clean = raw_lat(valid_mask);
    lon_clean = raw_lon(valid_mask);
    r_clean   = raw_r(valid_mask);
    F_clean   = raw_F(valid_mask);
    B_clean   = raw_B(valid_mask, :);

    % =========================================================================
    % 3. 分箱平均与统计 (Bin Averaging & Statistics)
    % =========================================================================
    dt_grid_days = data_step / 86400; 
    t_start = floor(min(t_clean) * 86400 / data_step) * data_step / 86400;
    t_end   = ceil(max(t_clean) * 86400 / data_step) * data_step / 86400;
    edges = t_start : dt_grid_days : t_end;
    
    if length(edges) < 2, warning(orig_warn_state); return; end
    
    [Y, ~] = discretize(t_clean, edges);
    bin_valid = ~isnan(Y);
    Y = Y(bin_valid);
    
    % 计算分箱统计量
    counts = accumarray(Y, 1);
    has_enough_data = (counts >= 10); % 潮汐反演硬约束：箱内至少10个点
    
    % 定义均值计算
    calc_mean = @(data) accumarray(Y, data) ./ max(1, counts);
    
    % A. 常规变量平均
    val_lat = calc_mean(lat_clean(bin_valid));
    val_r   = calc_mean(r_clean(bin_valid));
    val_F   = calc_mean(F_clean(bin_valid));
    val_B   = [calc_mean(B_clean(bin_valid, 1)), ...
               calc_mean(B_clean(bin_valid, 2)), ...
               calc_mean(B_clean(bin_valid, 3))];
    
    % B. 经度：三角函数平均 (解决跨越 +/-180度问题)
    lon_rad = deg2rad(lon_clean(bin_valid));
    val_lon = rad2deg(atan2(accumarray(Y, sin(lon_rad)), ...
                            accumarray(Y, cos(lon_rad))));
    
    % C. 计算箱内标准差 (STD)：用于后续反演的加权 (Weighting)
    % 潮汐研究极其依赖数据质量，STD 反映了该窗口内电离层波动的强度
    val_std_F = accumarray(Y, F_clean(bin_valid), [], @std);
    
    % D. 时间点取中值
    val_t_num = (edges(1:end-1) + edges(2:end))' / 2;
    
    % =========================================================================
    % 4. 结果整合
    % =========================================================================
    final_mask = false(size(counts));
    final_mask(1:length(has_enough_data)) = has_enough_data;
    
    if any(final_mask)
        % 最终输出矩阵格式: 
        % [纬度, 经度, 半径, B_N, B_E, B_C, 时间戳, 标量F, 标量STD]
        processed_data = [val_lat(final_mask), ...
                          val_lon(final_mask), ...
                          val_r(final_mask), ...
                          val_B(final_mask, :), ...
                          val_t_num(final_mask), ...
                          val_F(final_mask), ...
                          val_std_F(final_mask)];
    end
    
    warning(orig_warn_state);
catch ME
    fprintf('Error processing file %s: %s\n', file_info.name, ME.message);
    warning(orig_warn_state);
    processed_data = [];
end
end