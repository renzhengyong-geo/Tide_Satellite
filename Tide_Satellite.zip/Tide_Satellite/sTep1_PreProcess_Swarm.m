% =========================================================================
% Swarm 潮汐提取预处理程序 (v13_SingleFolder_AC_Diff)
% 核心改进:
% 1. [单一路径] 统一从 Swarm 文件夹读取所有文件
% 2. [文件解析] 基于文件名 (MAGA/MAGB/MAGC) 自动分类卫星 ID
% 3. [A/C差分] 保持50s窗口内最小纬度差配对算法
% =========================================================================
clc; clear; close all;
tic;

% 初始化并行池
max_workers = min(6, feature('numcores'));
p = gcp('nocreate');
if isempty(p), parpool('local', max_workers); end

%% ------------------- 1. 参数设定 -------------------
disp('1. 设定参数...');

% [修改] 统一数据文件夹路径
single_data_folder = 'E:\A_graduate\code_and_program\Satellite_data_processing\Satellite_Data\Swarm\';

% [功能] 随机读取控制
ENABLE_RANDOM_SAMPLING = false;   
RANDOM_SAMPLE_RATIO    = 0.1; % 采样比例

% [策略]
% 基础采样间隔设定为15秒 (用于读取和单星处理)
BINNING_WINDOW_SEC  = 60;  
ref_dn_2000 = datenum(2000, 1, 1, 0, 0, 0);

%% ------------------- 2. 加载辅助数据 -------------------
disp('2. 加载环境参数 (Em, Hp30, RC)...');

AUX_DATA_PATH = '../'; % 请根据实际情况填写辅助数据路径

% --- 2.1 加载 Em/Bz/By (分钟级) ---
file_em = fullfile(AUX_DATA_PATH, 'omni_min_em_bz_2h_avg.csv');
if ~isfile(file_em), error('文件缺失: %s', file_em); end
em_table = readtable(file_em);
em_table.datetime = datetime(em_table.year, 1, 1, 0, 0, 0) + ...
    days(em_table.day - 1) + hours(em_table.hour) + minutes(em_table.minute);
em_table.datetime.TimeZone = 'UTC'; 

% --- 2.2 加载 Hp30 (修复时区冲突) ---
file_hp30 = fullfile(AUX_DATA_PATH, 'hp30_data_19970101_20250930.csv');
if ~isfile(file_hp30), error('文件缺失: %s', file_hp30); end
hp30_table = readtable(file_hp30);

if isdatetime(hp30_table.Timestamp_UTC)
    if isempty(hp30_table.Timestamp_UTC.TimeZone)
        hp30_table.Timestamp_UTC.TimeZone = 'UTC';
    end
else
    hp30_table.Timestamp_UTC = datetime(hp30_table.Timestamp_UTC, 'TimeZone', 'UTC');
end
t_ref_2000_dt = datetime(2000, 1, 1, 0, 0, 0, 'TimeZone', 'UTC');
hp30_vals = [days(hp30_table.Timestamp_UTC - t_ref_2000_dt), hp30_table.Hp30_Value];

% --- 2.3 加载 RC Index ---
file_rc = fullfile(AUX_DATA_PATH, 'RC_1997-2025_Sept25_v3_allLT.dat');
if ~isfile(file_rc), error('文件缺失: %s', file_rc); end
rc_data = readmatrix(file_rc, 'FileType', 'text', 'NumHeaderLines', 7);
[t_rc_sort, idx] = sort(rc_data(:,1));
drc_dt = gradient(rc_data(idx,2), t_rc_sort * 24.0);
rc_deriv = [t_rc_sort, drc_dt];

fprintf('   辅助数据加载完成。\n');

%% ------------------- 3. 统一流读取 (递归扫描 & 15s降采样) -------------------
disp('3. 数据读取：递归扫描子文件夹 -> 分类 -> 15s降采样...');

global_data_container = {}; 

% --- 步骤 A: 递归扫描所有子文件夹 ---
if ~isfolder(single_data_folder)
    error('文件夹不存在: %s', single_data_folder);
end

% [修改点] 使用 '**/*.cdf' 模式进行递归搜索
fprintf('   正在递归扫描目录: %s\n', single_data_folder);
raw_files = dir(fullfile(single_data_folder, '**', '*.cdf'));

% 确保只处理文件，排除目录（虽然 *.cdf 通常不可能是目录，但为了健壮性）
raw_files = raw_files(~[raw_files.isdir]);

if isempty(raw_files)
    error('在路径及其子文件夹中未找到任何CDF文件: %s', single_data_folder);
end
fprintf('   共扫描到 %d 个CDF文件，正在进行卫星ID分类...\n', length(raw_files));

% --- 步骤 B: 基于文件名解析卫星ID ---
% 规则: MAGA -> SatID 1, MAGB -> SatID 2, MAGC -> SatID 3
files_to_process = struct('name', {}, 'folder', {}, 'sat_id', {});
valid_count = 0;

for k = 1:length(raw_files)
    fname = raw_files(k).name;
    s_id = 0;
    
    % 使用 contains 进行文件名匹配
    if contains(fname, 'MAGA', 'IgnoreCase', true)
        s_id = 1; % Swarm A
    elseif contains(fname, 'MAGB', 'IgnoreCase', true)
        s_id = 2; % Swarm B
    elseif contains(fname, 'MAGC', 'IgnoreCase', true)
        s_id = 3; % Swarm C
    end
    
    if s_id > 0
        valid_count = valid_count + 1;
        files_to_process(valid_count).name = fname;
        files_to_process(valid_count).folder = raw_files(k).folder; % 这里会自动记录子文件夹路径
        files_to_process(valid_count).sat_id = s_id;
    end
end

if valid_count == 0
    error('所有文件均未包含 MAGA/MAGB/MAGC 标识，无法识别卫星！');
end
fprintf('   有效 Swarm 文件: %d 个 (其中 A:%d, B:%d, C:%d)\n', ...
    valid_count, ...
    sum([files_to_process.sat_id]==1), ...
    sum([files_to_process.sat_id]==2), ...
    sum([files_to_process.sat_id]==3));

% --- 步骤 C: 采样控制 (修改版：按"天"成组采样，确保AC对齐) ---
if ENABLE_RANDOM_SAMPLING
    fprintf('   [随机模式] 正在按日期分组采样，以确保 A/C 同步...\n');
    
    % 1. 构建 日期 -> 文件索引 的映射
    % Swarm文件名典型格式: ..._20230101T000000_...
    date_map = containers.Map('KeyType', 'char', 'ValueType', 'any');
    
    for k = 1:length(files_to_process)
        fname = files_to_process(k).name;
        % 正则提取日期部分 (8位数字后跟T)
        tok = regexp(fname, '_(\d{8})T', 'tokens', 'once');
        
        if ~isempty(tok)
            day_str = tok{1}; % 例如 '20230101'
            if isKey(date_map, day_str)
                date_map(day_str) = [date_map(day_str), k];
            else
                date_map(day_str) = k;
            end
        end
    end
    
    all_dates = keys(date_map);
    total_dates = length(all_dates);
    
    if total_dates > 0
        % 2. 随机抽取日期
        n_samp_days = max(1, round(total_dates * RANDOM_SAMPLE_RATIO));
        
        % 随机打乱日期列表并取前 n_samp_days 个
        rand_perm_idx = randperm(total_dates, n_samp_days);
        selected_dates = all_dates(rand_perm_idx);
        
        fprintf('   共识别到 %d 天数据，随机选中 %d 天进行处理。\n', total_dates, n_samp_days);
        
        % 3. 收集这些日期的所有文件
        selected_file_indices = [];
        for i = 1:length(selected_dates)
            day_key = selected_dates{i};
            file_idxs = date_map(day_key);
            selected_file_indices = [selected_file_indices, file_idxs]; 
        end
        
        % 更新待处理文件列表
        files_to_process = files_to_process(sort(selected_file_indices));
        
        % 统计选中情况
        n_A = sum([files_to_process.sat_id] == 1);
        n_C = sum([files_to_process.sat_id] == 3);
        fprintf('   -> 最终选中文件数: %d (含 A星:%d, C星:%d)\n', length(files_to_process), n_A, n_C);
        
        if n_A > 0 && n_C > 0
            fprintf('   -> 状态: 包含成对数据，可进行差分调试。\n');
        else
            warning('   -> 警告: 选中的子集中 A 或 C 缺失，可能无法计算差分 (请检查源数据是否完整)。');
        end
        
    else
        warning('文件名日期解析失败，回退到普通随机采样...');
        n_samp = max(1, round(valid_count * RANDOM_SAMPLE_RATIO));
        files_to_process = files_to_process(sort(randperm(valid_count, n_samp)));
    end
end

% --- 步骤 D: 读取并直接降采样 ---
num_files = length(files_to_process);
sat_data_cell = cell(num_files, 1);

q = parallel.pool.DataQueue;
afterEach(q, @(~) fprintf('.')); 
fprintf('      读取进度: ');

parfor k = 1:num_files
    curr_file = files_to_process(k);
    
    % 调用单个CDF处理函数 (确保使用了最新修改版的 process_single_cdf_file)
    raw = process_single_cdf_file_Swarm(curr_file, curr_file.folder, ref_dn_2000, BINNING_WINDOW_SEC);
    
    if isempty(raw), continue; end
    
    % 数据结构: [Lat, Lon, Rad, B_NEC(3), t_dn, F, SatID]
    data_chunk = [raw(:,1:3), raw(:,4:6), raw(:,7), raw(:,8), ones(size(raw,1),1)*curr_file.sat_id];
    sat_data_cell{k} = data_chunk;
    send(q, k);
end
fprintf('\n');

% --------------------- 数据合并 ---------------------
disp('   正在合并所有数据...');
global_data_container = sat_data_cell(~cellfun('isempty', sat_data_cell));
if isempty(global_data_container), error('所有文件读取后数据为空！'); end

all_data = vertcat(global_data_container{:});
[~, sort_t_idx] = sort(all_data(:,7)); 
all_data = all_data(sort_t_idx, :);
clear global_data_container sat_data_cell;

% 变量标准化
lat_obs = all_data(:,1); lon_obs = all_data(:,2); r_obs = all_data(:,3);
bnec_obs= all_data(:,4:6); t_dn = all_data(:,7); F_obs = all_data(:,8);
sat_id_obs = all_data(:,9);

t_mjd = t_dn - ref_dn_2000;
t_utc = datetime(t_dn, 'ConvertFrom', 'datenum', 'TimeZone', 'UTC');

total_points = length(lat_obs);
fprintf('   Swarm 数据准备完毕。总点数: %d\n', total_points);

% [新增调试] 检查各卫星读取到的点数
n_A_raw = sum(sat_id_obs == 1);
n_B_raw = sum(sat_id_obs == 2);
n_C_raw = sum(sat_id_obs == 3);
fprintf('   [调试] 读取阶段数据分布:\n');
fprintf('     - Swarm A: %d 点\n', n_A_raw);
fprintf('     - Swarm B: %d 点\n', n_B_raw);
fprintf('     - Swarm C: %d 点\n', n_C_raw);

if n_A_raw == 0 || n_C_raw == 0
    warning('   [严重警告] 读取阶段 Swarm A 或 C 数据为 0！请检查 process_single_cdf_file 是否正确读取了变量。');
end
%% ------------------- 4. 前置筛选 (Night, RC, Hp30, Em/Bz) -------------------
disp('4. 执行前置筛选 (Night, RC, Hp30, Em/Bz)...');

% --- 4.1 夜间筛选 ---
[sun_vec_GEI, GST] = sunGEI(t_mjd);
theta_rad = deg2rad(90 - lat_obs); phi_rad = deg2rad(lon_obs);      
sat_x = sin(theta_rad) .* cos(phi_rad); sat_y = sin(theta_rad) .* sin(phi_rad); sat_z = cos(theta_rad);

cos_gst = cos(GST); sin_gst = sin(GST);
sat_vec_GEI_x = sat_x .* cos_gst - sat_y .* sin_gst;
sat_vec_GEI_y = sat_x .* sin_gst + sat_y .* cos_gst;
sat_vec_GEI_z = sat_z;

cos_theta = sun_vec_GEI(:,1) .* sat_vec_GEI_x + sun_vec_GEI(:,2) .* sat_vec_GEI_y + sun_vec_GEI(:,3) .* sat_vec_GEI_z;
mask_night = rad2deg(acos(max(min(cos_theta, 1), -1))) > 100;

% --- 4.2 RC/Hp30/DF/OMNI 筛选 ---
drc_val = interp1(rc_deriv(:,1), rc_deriv(:,2), t_mjd, 'linear', 'extrap');
mask_rc = abs(drc_val) <= 2;

hp_val = interp1(hp30_vals(:,1), hp30_vals(:,2), t_mjd, 'nearest', 'extrap');
mask_hp = hp_val <= 2;

mask_df = abs(F_obs - vecnorm(bnec_obs,2,2)) <= 100;

sat_min = dateshift(t_utc, 'start', 'minute');
[~, loc] = ismember(sat_min, em_table.datetime);
valid_omni = loc > 0;

mask_em = false(size(mask_night)); mask_bz = false(size(mask_night));
if any(valid_omni)
    matched_idx = loc(valid_omni);
    mask_em(valid_omni) = em_table.avg_em_2h(matched_idx) <= 0.8;
    mask_bz(valid_omni) = em_table.avg_bz_2h(matched_idx) > 0;
end

mask_pre_calc = mask_night & mask_rc & mask_hp & mask_df & mask_em & mask_bz;
fprintf('   前置筛选通过: %d / %d (%.1f%%)\n', sum(mask_pre_calc), total_points, sum(mask_pre_calc)/total_points*100);

%% ------------------- 5. CHAOS 计算 (仅针对有效点) -------------------
disp('5. 计算 CHAOS 背景场 (仅计算筛选通过点)...');

idx_calc = find(mask_pre_calc);
if isempty(idx_calc), error('前置筛选后无数据！'); end

% 提取子集
t_sub = t_mjd(idx_calc); r_sub = r_obs(idx_calc);
lat_sub = lat_obs(idx_calc); lon_sub = lon_obs(idx_calc);

addpath('CHAOS-8.4_FWD\'); 
try load('CHAOS-8.4.mat'); catch, error('CHAOS mat missing'); end

% 配置 CHAOS
N_core=20; pp_core=pp; pp_core.dim=N_core*(N_core+2); 
coefs_tmp=reshape(pp.coefs,[],pp.pieces,pp.order);
pp_core.coefs=reshape(coefs_tmp(1:N_core*(N_core+2),:,:),[],pp.order);
g_crust=g(1:(110*(110+2))); mod_ext=model_ext; dip=[-29442.0, -1501.0, 4797.1];
RC_interp = interp1(rc_data(:,1), rc_data(:,3:4), t_sub, 'linear');

% 并行计算
n_sub = length(t_sub);
chunk_size = 50000;
num_chunks = ceil(n_sub / chunk_size);
out_B = cell(num_chunks, 1);

parfor i = 1:num_chunks
    c_idx = (i-1)*chunk_size+1 : min(i*chunk_size, n_sub);
    th_d = 90 - lat_sub(c_idx);
    B_c = synth_values(r_sub(c_idx), th_d, lon_sub(c_idx), pp_core, t_sub(c_idx));
    B_k = synth_values(r_sub(c_idx), th_d, lon_sub(c_idx), g_crust);
    B_e = synth_values_CHAOS_ext(t_sub(c_idx), r_sub(c_idx), th_d, lon_sub(c_idx), ...
        RC_interp(c_idx,:), mod_ext, dip, 'GSM_SM_SHA_3D_IGRF12_2015.mat');
    out_B{i} = B_c + B_k + B_e;
end
B_model_sub = vertcat(out_B{:});
clear pp_core g g_crust out_B;

% 计算残差
bnec_sub = bnec_obs(idx_calc, :);
B_obs_vec_sub = [-bnec_sub(:,3), -bnec_sub(:,1), bnec_sub(:,2)]; 
B_res_sub = B_obs_vec_sub - B_model_sub;
F_mod_sub = vecnorm(B_model_sub, 2, 2);
dF_res_sub = F_obs(idx_calc) - F_mod_sub;

fprintf('   计算 QD 纬度...\n');
QD_lat_sub = calculate_QD_Lat(B_model_sub, r_sub);
Dir_sub = B_model_sub ./ F_mod_sub;

%% ------------------- 6. 后置筛选 (By, 粗差) -------------------
disp('6. 执行后置筛选...');

loc_sub = loc(idx_calc);
valid_omni_sub = loc_sub > 0;
mask_by_sub = false(size(QD_lat_sub));
if any(valid_omni_sub)
    by_vals = em_table.avg_by_2h(loc_sub(valid_omni_sub));
    qd_check = QD_lat_sub(valid_omni_sub);
    is_north = qd_check > 0;
    tmp_pass = false(size(qd_check));
    tmp_pass(is_north) = by_vals(is_north) < 3;
    tmp_pass(~is_north) = by_vals(~is_north) > -3;
    mask_by_sub(valid_omni_sub) = tmp_pass;
end

mask_gross_sub = false(size(QD_lat_sub));
mask_low = abs(QD_lat_sub) < 55;
mask_gross_sub(mask_low) = (vecnorm(B_res_sub(mask_low,:),2,2) < 40) & (abs(dF_res_sub(mask_low)) < 40);
mask_gross_sub(~mask_low) = abs(dF_res_sub(~mask_low)) < 40;

mask_final_sub = mask_by_sub & mask_gross_sub;
idx_final_rel = find(mask_final_sub);

% 提取最终变量
t_fin = t_sub(idx_final_rel);
r_fin = r_sub(idx_final_rel); lat_fin = lat_sub(idx_final_rel); lon_fin = lon_sub(idx_final_rel);
qd_fin = QD_lat_sub(idx_final_rel);
sat_fin = sat_id_obs(idx_calc(idx_final_rel));
B_res_fin = B_res_sub(idx_final_rel, :);
dF_res_fin = dF_res_sub(idx_final_rel);
Dir_fin = Dir_sub(idx_final_rel, :);

fprintf('   最终保留数据点: %d\n', length(t_fin));

% [新增调试] 检查筛选后各卫星的点数
n_A_fin = sum(sat_fin == 1);
n_B_fin = sum(sat_fin == 2);
n_C_fin = sum(sat_fin == 3);
fprintf('   [调试] 筛选后数据分布:\n');
fprintf('     - Swarm A: %d 点 (留存率 %.1f%%)\n', n_A_fin, n_A_fin/max(1,n_A_raw)*100);
fprintf('     - Swarm B: %d 点 (留存率 %.1f%%)\n', n_B_fin, n_B_fin/max(1,n_B_raw)*100);
fprintf('     - Swarm C: %d 点 (留存率 %.1f%%)\n', n_C_fin, n_C_fin/max(1,n_C_raw)*100);

if n_A_fin > 0 && n_C_fin == 0
    warning('   [严重警告] Swarm C 数据在筛选阶段被全部剔除！可能原因: Flag筛选过严 或 Delta-F 校验失败。');
elseif n_A_fin == 0 && n_C_fin > 0
    warning('   [严重警告] Swarm A 数据在筛选阶段被全部剔除！');
end
%% ------------------- 7. 保存绝对数据 -------------------
disp('7. 保存绝对数据 (Weighted)...');

mask_vec = abs(qd_fin) < 55;
mask_sca = abs(qd_fin) >= 55;

Data_Vector_Orig = struct('Time', t_fin(mask_vec), ...
    'Pos', [r_fin(mask_vec), 90-lat_fin(mask_vec), lon_fin(mask_vec)], ...
    'B_res', B_res_fin(mask_vec,:), 'QD_Lat', qd_fin(mask_vec), ...
    'SatID', sat_fin(mask_vec), 'Weight', ones(sum(mask_vec),1));

Data_Scalar_Orig = struct('Time', t_fin(mask_sca), ...
    'Pos', [r_fin(mask_sca), 90-lat_fin(mask_sca), lon_fin(mask_sca)], ...
    'dF', dF_res_fin(mask_sca), 'Dir', Dir_fin(mask_sca,:), ...
    'QD_Lat', qd_fin(mask_sca), 'SatID', sat_fin(mask_sca), ...
    'Weight', ones(sum(mask_sca),1));

save('Swarm_ACC_Input_Original_Weighted.mat', 'Data_Vector_Orig', 'Data_Scalar_Orig');

%% ------------------- 8. 单星梯度计算 (15s间隔) -------------------
disp('8. 计算单星梯度 (15s间隔, 支持Swarm A/B/C)...');

vec_grad_structs = []; sca_grad_structs = [];
sat_list = unique(sat_fin);

for s_idx = 1:length(sat_list)
    curr_sat = sat_list(s_idx);
    idx_sat = find(sat_fin == curr_sat);
    if length(idx_sat) < 2, continue; end
    
    % 提取单星数据
    t_c = t_fin(idx_sat);
    r_c = r_fin(idx_sat); lat_c = lat_fin(idx_sat); lon_c = lon_fin(idx_sat);
    B_c = B_res_fin(idx_sat, :); dF_c = dF_res_fin(idx_sat);
    Dir_c = Dir_fin(idx_sat, :); qd_c = qd_fin(idx_sat);
    
    % 寻找15s间隔点对
    dt_sec = diff(t_c) * 86400;
    valid_pairs = find(abs(dt_sec - 15) <= 0.1);
    
    if isempty(valid_pairs), continue; end
    i1 = valid_pairs; i2 = valid_pairs + 1;
    
    g_v = B_c(i2,:) - B_c(i1,:);
    g_s = dF_c(i2) - dF_c(i1);
    
    % 筛选
    mask_gv = (abs(qd_c(i1)) < 55) & (vecnorm(g_v, 2, 2) < 15);
    mask_gs = (abs(g_s) < 15);
    
    if sum(mask_gv) > 0
        idx1 = i1(mask_gv); idx2 = i2(mask_gv);
        S_vec = struct('Time1', t_c(idx1), 'Time2', t_c(idx2), ...
            'Pos1', [r_c(idx1), 90-lat_c(idx1), lon_c(idx1)], ...
            'Pos2', [r_c(idx2), 90-lat_c(idx2), lon_c(idx2)], ...
            'd_grad', g_v(mask_gv,:), 'QD_Lat', qd_c(idx1), ...
            'SatID', curr_sat*ones(length(idx1),1), 'Weight', ones(length(idx1),1));
        vec_grad_structs = [vec_grad_structs; S_vec]; %#ok<AGROW>
    end
    
    if sum(mask_gs) > 0
        idx1 = i1(mask_gs); idx2 = i2(mask_gs);
        S_sca = struct('Time1', t_c(idx1), 'Time2', t_c(idx2), ...
            'Pos1', [r_c(idx1), 90-lat_c(idx1), lon_c(idx1)], ...
            'Pos2', [r_c(idx2), 90-lat_c(idx2), lon_c(idx2)], ...
            'd_grad', g_s(mask_gs), 'Dir', Dir_c(idx1,:), ...
            'QD_Lat', qd_c(idx1), ...
            'SatID', curr_sat*ones(length(idx1),1), 'Weight', ones(length(idx1),1));
        sca_grad_structs = [sca_grad_structs; S_sca]; %#ok<AGROW>
    end
end

if isempty(vec_grad_structs), Data_Vector_Grad=[]; else, fns=fieldnames(vec_grad_structs); for f=1:length(fns), Data_Vector_Grad.(fns{f})=vertcat(vec_grad_structs.(fns{f})); end; end
if isempty(sca_grad_structs), Data_Scalar_Grad=[]; else, fns=fieldnames(sca_grad_structs); for f=1:length(fns), Data_Scalar_Grad.(fns{f})=vertcat(sca_grad_structs.(fns{f})); end; end

save('Swarm_ACC_Input_Gradient_Weighted.mat', 'Data_Vector_Grad', 'Data_Scalar_Grad');
fprintf('   单星梯度计算完成。\n');

%% ------------------- 9. Swarm A/C 星间梯度计算 (改进版：物理距离过滤) -------------------
disp('9. 计算 Swarm A/C 星间梯度 (50s窗口 + 距离校验)...');

idx_A = find(sat_fin == 1);
idx_C = find(sat_fin == 3);
n_A = length(idx_A);

if n_A > 0 && ~isempty(idx_C)
    fprintf('   检测到双星数据，开始进行 A/C 差分...\n');
    
    % A星数据
    t_A = t_fin(idx_A);
    lat_A = lat_fin(idx_A); 
    pos_A = [r_fin(idx_A), 90-lat_fin(idx_A), lon_fin(idx_A)];
    B_res_A = B_res_fin(idx_A, :);
    dF_res_A = dF_res_fin(idx_A);
    qd_A = qd_fin(idx_A);
    Dir_A = Dir_fin(idx_A, :);
    
    % C星数据
    t_C = t_fin(idx_C);
    lat_C = lat_fin(idx_C);
    pos_C = [r_fin(idx_C), 90-lat_fin(idx_C), lon_fin(idx_C)];
    B_res_C = B_res_fin(idx_C, :);
    dF_res_C = dF_res_fin(idx_C);
    
    pair_indices = zeros(n_A, 1);
    min_lat_diffs = zeros(n_A, 1); % 记录纬度差
    window_days = 25 / 86400; 
    
    fprintf('   正在进行 A/C 配对... 进度: ');
    prog_step = max(1, floor(n_A / 10));
    
    temp_t_C = t_C;
    temp_lat_C = lat_C;
    
    for i = 1:n_A
        if mod(i, prog_step) == 0, fprintf('%.0f%% ', i/n_A*100); end
        
        t_curr = t_A(i);
        t_mask = abs(temp_t_C - t_curr) <= window_days;
        cand_indices = find(t_mask);
        
        if isempty(cand_indices), continue; end
        
        % 纬度差最小筛选
        lat_diffs = abs(temp_lat_C(cand_indices) - lat_A(i));
        [min_diff, min_idx_local] = min(lat_diffs);
        
        pair_indices(i) = cand_indices(min_idx_local);
        min_lat_diffs(i) = min_diff;
    end
    fprintf('\n');
    
    % --- 第一层筛选：是否找到配对 ---
    valid_mask_init = pair_indices > 0;
    idx_A_valid = find(valid_mask_init);
    idx_C_matched = pair_indices(valid_mask_init);
    lat_diff_vals = min_lat_diffs(valid_mask_init);
    
    fprintf('   初步配对: %d 对\n', length(idx_A_valid));
    
    % 计算星间距离
    lat1 = lat_A(idx_A_valid); lon1 = lon_fin(idx_A(idx_A_valid)); r1 = r_fin(idx_A(idx_A_valid));
    lat2 = lat_C(idx_C_matched); lon2 = lon_fin(idx_C(idx_C_matched)); r2 = r_fin(idx_C(idx_C_matched));
    dist_km = calculate_distance_km_batch(lat1, lon1, lat2, lon2, (r1+r2)/2);
    
    % --- 第二层筛选：物理合理性校验 (关键) ---
    % 1. Swarm A/C 标称间距 1.4度经度 (赤道~155km). 
    %    允许范围设为 [10, 300] km，剔除 2000km+ 的离谱值。
    % 2. 匹配的纬度差不应太大 (如果不并行，说明匹配到了轨道缺口处)
    MAX_DIST_KM = 300; 
    MIN_DIST_KM = 10;
    MAX_LAT_MATCH_DIFF = 0.5; % 允许最大 0.5 度纬度错位
    
    mask_geo_logic = (dist_km >= MIN_DIST_KM) & ...
                     (dist_km <= MAX_DIST_KM) & ...
                     (lat_diff_vals <= MAX_LAT_MATCH_DIFF);
                 
    fprintf('   物理校验: 剔除 %d 个异常配对 (距离过大/过小或非并行)\n', sum(~mask_geo_logic));
    
    % 应用筛选
    idx_A_final = idx_A_valid(mask_geo_logic);
    idx_C_final = idx_C_matched(mask_geo_logic);
    dist_final = dist_km(mask_geo_logic);
    
    % 计算差分
    d_grad_vec = B_res_C(idx_C_final, :) - B_res_A(idx_A_final, :);
    d_grad_sca = dF_res_C(idx_C_final) - dF_res_A(idx_A_final);
    
    % --- 第三层筛选：梯度值域筛选 ---
    MAX_GRAD_VEC = 20; 
    MAX_GRAD_SCA = 15;
    qd_check = qd_A(idx_A_final);
    
    mask_vec = (abs(qd_check) < 55) & (vecnorm(d_grad_vec, 2, 2) < MAX_GRAD_VEC);
    mask_sca = abs(d_grad_sca) < MAX_GRAD_SCA;
    
    % 保存
    if any(mask_vec)
        iv = find(mask_vec);
        Data_Vector_Cross = struct(...
            'Time', t_A(idx_A_final(iv)), ...
            'Pos1', pos_A(idx_A_final(iv), :), ...
            'Pos2', pos_C(idx_C_final(iv), :), ...
            'd_grad', d_grad_vec(iv, :), ...
            'QD_Lat', qd_check(iv), ...
            'Weight', ones(length(iv), 1), ...
            'Distance_km', dist_final(iv));
    else
        Data_Vector_Cross = [];
    end
    
    if any(mask_sca)
        is = find(mask_sca);
        Data_Scalar_Cross = struct(...
            'Time', t_A(idx_A_final(is)), ...
            'Pos1', pos_A(idx_A_final(is), :), ...
            'Pos2', pos_C(idx_C_final(is), :), ...
            'd_grad', d_grad_sca(is), ...
            'Dir', Dir_A(idx_A_final(is), :), ...
            'QD_Lat', qd_check(is), ...
            'Weight', ones(length(is), 1), ...
            'Distance_km', dist_final(is));
    else
        Data_Scalar_Cross = [];
    end
    
    if ~isempty(dist_final)
        fprintf('   最终有效星间梯度点数: %d\n', length(dist_final));
        fprintf('   星间距离统计: Mean=%.1f km, Range=[%.1f, %.1f] km\n', ...
            mean(dist_final), min(dist_final), max(dist_final));
    end
    
    save('Swarm_CrossSat_Gradient_Weighted.mat', 'Data_Vector_Cross', 'Data_Scalar_Cross');
else
    fprintf('   未检测到双星数据。\n');
end

%% ------------------- 10. (新增) 保存绘图专用数据 -------------------
disp('10. 正在打包绘图数据...');

% 1. 还原全局掩膜 (Reconstruct Global Mask)
% 逻辑：mask_pre_calc 是全量数据的筛选结果，mask_final_sub 是基于前者子集的筛选结果
mask_final_global = false(size(all_data, 1), 1);
idx_stage1 = find(mask_pre_calc);               % 第一步通过的索引
idx_final_global = idx_stage1(mask_final_sub);  % 最终保留的数据在全局中的索引
mask_final_global(idx_final_global) = true;

% 2. 提取必要列以减小文件体积
% 只保存：时间(7), B_NEC(4:6), 卫星ID(9), 以及筛选标记
PlotData = struct();
PlotData.Time_DN = all_data(:, 7);      % datenum格式时间
PlotData.B_NEC   = all_data(:, 4:6);    % NEC 原始磁场 (未减去CHAOS)
PlotData.Sat_ID  = all_data(:, 9);      % 卫星ID
PlotData.Mask_Selected = mask_final_global; % 逻辑索引 (True=筛选后保留)

% 3. 保存为 MAT 文件
save_name = 'Swarm_Plotting_Data.mat';
save(save_name, 'PlotData', '-v7.3'); % v7.3 支持大文件
fprintf('   绘图数据已保存至: %s (可直接用于独立绘图脚本)\n', save_name);
disp('全部流程执行完毕。');
toc;

function dist_km = calculate_distance_km_batch(lat1_deg, lon1_deg, lat2_deg, lon2_deg, r_km)
    lat1 = deg2rad(lat1_deg(:)); lon1 = deg2rad(lon1_deg(:));
    lat2 = deg2rad(lat2_deg(:)); lon2 = deg2rad(lon2_deg(:));
    dlat = lat2 - lat1; dlon = lon2 - lon1;
    a = sin(dlat/2).^2 + cos(lat1) .* cos(lat2) .* sin(dlon/2).^2;
    c = 2 * atan2(sqrt(a), sqrt(1-a));
    dist_km = r_km(:) .* c;
end