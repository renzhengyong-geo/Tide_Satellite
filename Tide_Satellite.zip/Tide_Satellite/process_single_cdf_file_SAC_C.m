function processed_data = process_single_cdf_file_SAC_C(file_info, curr_folder, ref_dn_2000, data_step)
% 处理单个CDF文件的核心函数 (适配 SAC-C: t, r, theta, phi, F)
% 功能: 将 1Hz 原始数据降采样为 15s 数据

processed_data = [];

if contains(file_info.name, 'empty', 'IgnoreCase', true), return; end

full_path = fullfile(curr_folder, file_info.name);
orig_warn_state = warning; 

try
    warning('off', 'all');
    % 读取 SAC-C 变量 (根据您的截图)
    target_vars = {'theta', 'phi', 'r', 't', 'F'};
    
    cdf_data = cdfread(full_path, ...
        'Variables', target_vars, ...
        'CombineRecords', true, ...
        'ConvertEpochToDatenum', true);
    
    if isempty(cdf_data), warning(orig_warn_state); return; end
    
    raw_theta = double(cdf_data{1});
    raw_phi   = double(cdf_data{2});
    raw_r     = double(cdf_data{3});
    raw_t     = double(cdf_data{4});
    raw_f     = double(cdf_data{5});
    
    if isempty(raw_t) || isempty(raw_f), warning(orig_warn_state); return; end
    
    % --- 预处理 ---
    raw_lat = 90 - raw_theta;
    raw_lon = raw_phi;
    if mean(raw_r, 'omitnan') > 1000000, raw_r = raw_r / 1000; end
    
    % 时间转换 (MJD2000 -> datenum)
    raw_time_dn = ref_dn_2000 + raw_t;
    
    % --- 关键：分箱降采样 (15s) ---
    if data_step > 0
        t_start = floor(min(raw_time_dn) * 86400 / data_step) * data_step / 86400;
        t_end   = ceil(max(raw_time_dn) * 86400 / data_step) * data_step / 86400;
        edges   = t_start : (data_step / 86400) : t_end;
        
        if length(edges) < 2, warning(orig_warn_state); return; end
        
        [Y] = discretize(raw_time_dn, edges);
        valid_mask = ~isnan(Y);
        Y = Y(valid_mask);
        
        if isempty(Y), warning(orig_warn_state); return; end
        
        counts = accumarray(Y, 1);
        has_data = counts > 0;
        
        % 定义求平均函数
        calc_mean = @(data) accumarray(Y, data(valid_mask)) ./ max(1, counts);
        
        val_lat = calc_mean(raw_lat);
        val_lon = calc_mean(raw_lon);
        val_r   = calc_mean(raw_r);
        val_F   = calc_mean(raw_f);
        val_t_num = (edges(1:end-1) + edges(2:end))' / 2; % 箱中心时间
        
        % 提取有效箱子
        val_lat = val_lat(has_data);
        val_lon = val_lon(has_data);
        val_r   = val_r(has_data);
        val_F   = val_F(has_data);
        val_t_num = val_t_num(has_data);
        
    else
        % 不降采样 (如需调试)
        val_lat = raw_lat; val_lon = raw_lon; val_r = raw_r; val_F = raw_f; val_t_num = raw_time_dn;
    end
    
    % --- 输出构建 ---
    val_b = nan(length(val_lat), 3); % 矢量占位
    
    mask = ~isnan(val_lat) & ~isnan(val_F) & (val_F > 1000);
    
    if any(mask)
        % 格式: [Lat, Lon, R, NaN, NaN, NaN, Time, F]
        processed_data = [val_lat(mask), val_lon(mask), val_r(mask), ...
                          val_b(mask, :), val_t_num(mask), val_F(mask)];
    end
    
    warning(orig_warn_state);

catch
    warning(orig_warn_state);
    processed_data = [];
end
end