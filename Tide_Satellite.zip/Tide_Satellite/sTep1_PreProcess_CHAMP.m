% =========================================================================
% CHAMP 磁场数据建模预处理主程序 (v2.1_DebugFriendly)
% 核心功能: 
% 1. 支持按比例随机抽样（以"天"为单位）
% 2. 自动调用封装好的 process_single_cdf_file_CHAMP (含硬件Flag筛选)
% 3. 环境场筛选、CHAOS扣除及沿轨梯度计算
% =========================================================================
clc; clear; close all;
tic;

% 初始化并行池
max_workers = min(6, feature('numcores'));
if isempty(gcp('nocreate')), parpool('local', max_workers); end

%% ------------------- 1. 参数设定 -------------------
disp('1. 设定参数...');
single_data_folder = 'E:\A_graduate\code_and_program\Satellite_data_processing\Satellite_Data\CHAMP\';

% [抽样控制] 用于快速调试
ENABLE_RANDOM_SAMPLING = false;   % 是否开启抽样
RANDOM_SAMPLE_RATIO    = 0.1;   % 抽样比例 (如0.05代表抽取5%的天数进行调试)

BINNING_WINDOW_SEC  = 15;  
ref_dn_2000 = datenum(2000, 1, 1, 0, 0, 0);

%% ------------------- 2. 加载辅助环境数据 -------------------
disp('2. 加载环境参数 (Em, Hp30, RC)...');
AUX_DATA_PATH = '../'; 

% 2.1 OMNI (Em, Bz, By)
em_table = readtable(fullfile(AUX_DATA_PATH, 'omni_min_em_bz_2h_avg.csv'));
em_table.datetime = datetime(em_table.year, 1, 1, 0, 0, 0) + ...
    days(em_table.day - 1) + hours(em_table.hour) + minutes(em_table.minute);
em_table.datetime.TimeZone = 'UTC'; 

% 2.2 Hp30
hp30_table = readtable(fullfile(AUX_DATA_PATH, 'hp30_data_19970101_20250930.csv'));
if isempty(hp30_table.Timestamp_UTC.TimeZone), hp30_table.Timestamp_UTC.TimeZone = 'UTC'; end
hp30_vals = [days(hp30_table.Timestamp_UTC - datetime(2000,1,1,'TimeZone','UTC')), hp30_table.Hp30_Value];

% 2.3 RC Index
rc_data = readmatrix(fullfile(AUX_DATA_PATH, 'RC_1997-2025_Sept25_v3_allLT.dat'), 'FileType', 'text', 'NumHeaderLines', 7);
[t_rc_sort, idx] = sort(rc_data(:,1));
rc_deriv = [t_rc_sort, gradient(rc_data(idx,2), t_rc_sort * 24.0)];

%% ------------------- 3. 文件扫描与抽样控制 -------------------
disp('3. 扫描文件并执行抽样控制...');

if ~isfolder(single_data_folder), error('路径不存在: %s', single_data_folder); end
raw_files = dir(fullfile(single_data_folder, '**', '*.cdf'));
raw_files = raw_files(~[raw_files.isdir]);
num_total_files = length(raw_files);

if num_total_files == 0, error('未找到任何CDF文件！'); end

files_to_process = raw_files;

% 执行按"天"随机抽样
if ENABLE_RANDOM_SAMPLING
    fprintf('   [抽样模式] 正在进行按天随机采样 (比例: %.1f%%)...\n', RANDOM_SAMPLE_RATIO*100);
    
    % 解析文件名中的日期 (假设格式包含 YYYY-MM-DD 或 YYYYMMDD)
    % 常见的CHAMP文件名: CH-ME-2-MAG_2002-05-15_...
    day_map = containers.Map('KeyType', 'char', 'ValueType', 'any');
    for k = 1:num_total_files
        fname = raw_files(k).name;
        % 匹配形如 2002-05-15 的日期
        tok = regexp(fname, '(\d{4}-\d{2}-\d{2})', 'tokens', 'once');
        if isempty(tok)
            % 备选方案：匹配 20020515
            tok = regexp(fname, '(\d{8})', 'tokens', 'once');
        end
        
        if ~isempty(tok)
            day_str = tok{1};
            if isKey(day_map, day_str)
                day_map(day_str) = [day_map(day_str), k];
            else
                day_map(day_str) = k;
            end
        end
    end
    
    all_days = keys(day_map);
    num_total_days = length(all_days);
    
    if num_total_days > 0
        n_samp_days = max(1, round(num_total_days * RANDOM_SAMPLE_RATIO));
        rand_idx = randperm(num_total_days, n_samp_days);
        selected_days = all_days(rand_idx);
        
        selected_indices = [];
        for i = 1:length(selected_days)
            selected_indices = [selected_indices, day_map(selected_days{i})];
        end
        files_to_process = raw_files(sort(selected_indices));
        fprintf('   -> 已从 %d 天中抽取 %d 天，共 %d 个文件。\n', num_total_days, n_samp_days, length(files_to_process));
    else
        warning('日期解析失败，回退到按文件数量随机抽样。');
        n_samp = max(1, round(num_total_files * RANDOM_SAMPLE_RATIO));
        files_to_process = raw_files(sort(randperm(num_total_files, n_samp)));
    end
end

%% ------------------- 4. 数据并行读取 (内含硬件Flag筛选) -------------------
disp('4. 并行读取 CDF 数据...');

num_files = length(files_to_process);
sat_data_cell = cell(num_files, 1);
q = parallel.pool.DataQueue;
afterEach(q, @(~) fprintf('.')); 
fprintf('      进度: ');

parfor k = 1:num_files
    % 调用已封装好的读取函数
    % 返回: [Lat, Lon, Rad, B_N, B_E, B_C, Time, F_scal, F_std]
    res = process_single_cdf_file_CHAMP(files_to_process(k).name, files_to_process(k).folder, ref_dn_2000, BINNING_WINDOW_SEC);
    if ~isempty(res)
        sat_data_cell{k} = [res, ones(size(res,1),1)*4]; % SatID = 4
    end
    send(q, k);
end
fprintf('\n');

all_data = vertcat(sat_data_cell{:});
if isempty(all_data), error('读取后无有效数据，请检查CDF读取函数或Flag定义！'); end

[~, s_idx] = sort(all_data(:,7)); 
all_data = all_data(s_idx, :);

lat_obs = all_data(:,1); lon_obs = all_data(:,2); r_obs = all_data(:,3);
bnec_obs= all_data(:,4:6); t_dn = all_data(:,7); F_obs = all_data(:,8);
F_std   = all_data(:,9);

t_mjd = t_dn - ref_dn_2000;
t_utc = datetime(t_dn, 'ConvertFrom', 'datenum', 'TimeZone', 'UTC');

%% ------------------- 5. 物理准则筛选 -------------------
disp('5. 执行物理筛选 (Night, RC, Hp30, Em/Bz)...');

% 夜间筛选
[sun_vec_GEI, GST] = sunGEI(t_mjd);
th = deg2rad(90 - lat_obs); ph = deg2rad(lon_obs);
sx = sin(th).*cos(ph).*cos(GST) - sin(th).*sin(ph).*sin(GST);
sy = sin(th).*cos(ph).*sin(GST) + sin(th).*sin(ph).*cos(GST);
sz = cos(th);
mask_night = rad2deg(acos(min(max(sun_vec_GEI(:,1).*sx + sun_vec_GEI(:,2).*sy + sun_vec_GEI(:,3).*sz, -1), 1))) > 100;

% 地磁指数
drc_val = interp1(rc_deriv(:,1), rc_deriv(:,2), t_mjd, 'linear', 'extrap');
mask_rc = abs(drc_val) <= 2;
hp_val = interp1(hp30_vals(:,1), hp30_vals(:,2), t_mjd, 'nearest', 'extrap');
mask_hp = hp_val <= 2;

% OMNI
sat_min = dateshift(t_utc, 'start', 'minute');
[~, loc] = ismember(sat_min, em_table.datetime);
mask_omni = false(size(t_mjd));
valid_idx = loc > 0;
mask_omni(valid_idx) = (em_table.avg_em_2h(loc(valid_idx)) <= 0.8) & (em_table.avg_bz_2h(loc(valid_idx)) > 0);

mask_phys = mask_night & mask_rc & mask_hp & mask_omni;
fprintf('   物理筛选通过: %d 点 (通过率 %.1f%%)\n', sum(mask_phys), sum(mask_phys)/length(mask_phys)*100);

%% ------------------- 6. CHAOS 背景场扣除 -------------------
disp('6. 计算 CHAOS 场残差...');
idx_calc = find(mask_phys);
if isempty(idx_calc), error('物理筛选后无可用点'); end

t_sub = t_mjd(idx_calc); r_sub = r_obs(idx_calc);
lat_sub = lat_obs(idx_calc); lon_sub = lon_obs(idx_calc);

addpath('CHAOS-8.4_FWD\'); load('CHAOS-8.4.mat'); 
N_core=20; pp_core=pp; pp_core.dim=N_core*(N_core+2); 
coefs_tmp=reshape(pp.coefs,[],pp.pieces,pp.order);
pp_core.coefs=reshape(coefs_tmp(1:N_core*(N_core+2),:,:),[],pp.order);
g_crust=g(1:(110*(110+2))); mod_ext=model_ext; dip=[-29442.0, -1501.0, 4797.1];
RC_interp = interp1(rc_data(:,1), rc_data(:,3:4), t_sub, 'linear');

n_sub = length(t_sub); chunk = 50000; num_c = ceil(n_sub/chunk);
out_B = cell(num_c, 1);
parfor i = 1:num_c
    ii = (i-1)*chunk+1 : min(i*chunk, n_sub);
    th_d = 90 - lat_sub(ii);
    Bc = synth_values(r_sub(ii), th_d, lon_sub(ii), pp_core, t_sub(ii));
    Bk = synth_values(r_sub(ii), th_d, lon_sub(ii), g_crust);
    Be = synth_values_CHAOS_ext(t_sub(ii), r_sub(ii), th_d, lon_sub(ii), RC_interp(ii,:), mod_ext, dip, 'GSM_SM_SHA_3D_IGRF12_2015.mat');
    out_B{i} = Bc + Bk + Be;
end
B_model = vertcat(out_B{:});

% 残差映射 NEC -> Br, Btheta, Bphi
bnec_sub = bnec_obs(idx_calc, :);
B_obs_trans = [-bnec_sub(:,3), -bnec_sub(:,1), bnec_sub(:,2)]; 
B_res = B_obs_trans - B_model;
dF_res = F_obs(idx_calc) - vecnorm(B_model, 2, 2);

QD_lat = calculate_QD_Lat(B_model, r_sub);
Dir_vec = B_model ./ vecnorm(B_model, 2, 2);

%% ------------------- 7. 综合筛选 (By 准则 + 粗差剔除) -------------------
disp('6. 执行综合筛选 (IMF By + Gross Error)...');

% --- 6.1 定义硬阈值 ---
MAX_ABS_RESID = 40;   % 绝对残差门限 (nT)
MAX_GRAD_RESID = 20;  % 梯度残差门限 (nT)

% --- 6.2 IMF By 筛选逻辑 ---
% 准则：北半球 By < 3nT, 南半球 By > -3nT (减少极区对流场污染)
mask_by = false(size(QD_lat));
% 获取子集对应的 By 值 (loc 是在 Section 4 中计算的 OMNI 索引)
by_val_sub = em_table.avg_by_2h(loc(idx_calc)); 
is_north = (QD_lat > 0);
mask_by(is_north)  = (by_val_sub(is_north) < 3);
mask_by(~is_north) = (by_val_sub(~is_north) > -3);

% --- 6.3 粗差掩码 ---
mask_gross = (abs(dF_res) < MAX_ABS_RESID) & (vecnorm(B_res, 2, 2) < MAX_ABS_RESID);

% --- 6.4 最终有效点掩码 (By + Gross) ---
mask_valid_point = mask_by & mask_gross;

% --- 6.5 分类保存绝对数据 ---
% 1. 矢量绝对数据：仅限低纬 (|QD| < 55) + 有效点
m_v_abs = mask_valid_point & (abs(QD_lat) < 55);
% 2. 标量绝对数据：全纬度 + 有效点
m_s_abs = mask_valid_point & (abs(QD_lat) >= 55); 

Data_Vector_Orig = struct('Time', t_sub(m_v_abs), ...
    'Pos', [r_sub(m_v_abs), 90-lat_sub(m_v_abs), lon_sub(m_v_abs)], ...
    'B_res', B_res(m_v_abs,:), 'QD_Lat', QD_lat(m_v_abs), ...
    'Weight', 1./(F_std(idx_calc(m_v_abs)).^2));

Data_Scalar_Orig = struct('Time', t_sub(m_s_abs), ...
    'Pos', [r_sub(m_s_abs), 90-lat_sub(m_s_abs), lon_sub(m_s_abs)], ...
    'dF', dF_res(m_s_abs), 'Dir', Dir_vec(m_s_abs,:), 'QD_Lat', QD_lat(m_s_abs), ...
    'Weight', 1./(F_std(idx_calc(m_s_abs)).^2));

save('CHAMP_Modeling_Input_Abs.mat', 'Data_Vector_Orig', 'Data_Scalar_Orig');
fprintf('   绝对数据保存完毕 (Vector: %d, Scalar: %d)\n', sum(m_v_abs), sum(m_s_abs));

%% ------------------- 7. 沿轨梯度计算与筛选 (增加权重保存) -------------------
disp('7. 计算分类梯度并保存权重...');

dt_s = diff(t_sub) * 86400;
% 梯度对子基础要求：时间间隔15s + 两个端点都通过了 By 和 Gross 筛选
v_pairs_base = find(abs(dt_s - 15) < 1.0 & mask_valid_point(1:end-1) & mask_valid_point(2:end));

if ~isempty(v_pairs_base)
    i1 = v_pairs_base; 
    i2 = v_pairs_base + 1;
    
    % --- 计算梯度观测值 ---
    gv = B_res(i2,:) - B_res(i1,:);
    gs = dF_res(i2) - dF_res(i1);
    
    % --- 计算梯度权重 (关键修正) ---
    % 理论公式: Var(g) = Var(pt1) + Var(pt2) -> Weight_g = 1 / (std1^2 + std2^2)
    std1 = F_std(idx_calc(i1));
    std2 = F_std(idx_calc(i2));
    grad_weight_full = 1 ./ (std1.^2 + std2.^2);
    
    % --- 修正后的分类逻辑 ---
    % 1. 矢量梯度 (Vector Grad): 仅限低纬 (|QD| < 55)
    m_gv = (abs(QD_lat(i1)) < 55) & (vecnorm(gv, 2, 2) < MAX_GRAD_RESID);
    
    % 2. 标量梯度 (Scalar Grad): 全纬度可用
    m_gs = (abs(gs) < MAX_GRAD_RESID);
    
    % --- 保存带权重的矢量梯度 ---
    if any(m_gv)
        Data_Vector_Grad = struct('Time1', t_sub(i1(m_gv)), 'Time2', t_sub(i2(m_gv)), ...
            'Pos1', [r_sub(i1(m_gv)), 90-lat_sub(i1(m_gv)), lon_sub(i1(m_gv))], ...
            'Pos2', [r_sub(i2(m_gv)), 90-lat_sub(i2(m_gv)), lon_sub(i2(m_gv))], ...
            'd_grad', gv(m_gv,:), 'QD_Lat', QD_lat(i1(m_gv)), ...
            'Weight', grad_weight_full(m_gv)); % 存入权重
    else
        Data_Vector_Grad = [];
    end
        
    % --- 保存带权重的标量梯度 ---
    if any(m_gs)
        Data_Scalar_Grad = struct('Time1', t_sub(i1(m_gs)), 'Time2', t_sub(i2(m_gs)), ...
            'Pos1', [r_sub(i1(m_gs)), 90-lat_sub(i1(m_gs)), lon_sub(i1(m_gs))], ...
            'Pos2', [r_sub(i2(m_gs)), 90-lat_sub(i2(m_gs)), lon_sub(i2(m_gs))], ...
            'd_grad', gs(m_gs), 'Dir', Dir_vec(i1(m_gs),:), 'QD_Lat', QD_lat(i1(m_gs)), ...
            'Weight', grad_weight_full(m_gs)); % 存入权重
    else
        Data_Scalar_Grad = [];
    end
        
    save('CHAMP_Modeling_Input_Grad.mat', 'Data_Vector_Grad', 'Data_Scalar_Grad');
    fprintf('   梯度数据保存完毕 (含权重)。\n');
else
    fprintf('   未找到满足条件的 15s 梯度对。\n');
end