% =========================================================================
% Orsted (奥斯特) 标量数据提取与预处理程序
% 核心功能:
% 1. [单星处理] 读取 Orsted CDF 数据，执行 15s 降采样
% 2. [仅标量] 仅输出标量残差 (dF) 和 沿轨标量梯度 (dF_grad)
% 3. [全纬度] 标量数据覆盖全纬度，不设 QDLat 截断
% 4. [筛选] 包含 Night-side, RC, Hp30, OMNI(By/Bz) 筛选
% =========================================================================
clc; clear; close all;
tic;

% 初始化并行池 (根据电脑配置调整)
max_workers = min(6, feature('numcores'));
p = gcp('nocreate');
if isempty(p), parpool('local', max_workers); end

%% ------------------- 1. 参数设定 -------------------
disp('1. 设定参数...');

% 修改为奥斯特数据的文件夹路径
data_folder = 'E:\A_graduate\code_and_program\Satellite_data_processing\Satellite_Data\Oersted\';

% [功能] 随机读取控制
ENABLE_RANDOM_SAMPLING = false;   
RANDOM_SAMPLE_RATIO    = 0.01; 

% [策略]
% 采样间隔设定为15秒 (用于降采样和梯度步长)
BINNING_WINDOW_SEC  = 15;  
ref_dn_2000 = datenum(2000, 1, 1, 0, 0, 0);

%% ------------------- 2. 加载辅助数据 -------------------
disp('2. 加载环境参数 (Em, Hp30, RC)...');

AUX_DATA_PATH = ''; % 请填写辅助数据文件夹路径

% --- 2.1 加载 Em/Bz/By (分钟级) ---
file_em = fullfile(AUX_DATA_PATH, 'omni_min_em_bz_2h_avg.csv');
if ~isfile(file_em), error('文件缺失: %s', file_em); end
em_table = readtable(file_em);
% 构造 datetime 并显式指定时区为 UTC
em_table.datetime = datetime(em_table.year, 1, 1, 0, 0, 0) + ...
    days(em_table.day - 1) + hours(em_table.hour) + minutes(em_table.minute);
em_table.datetime.TimeZone = 'UTC'; 

% --- 2.2 加载 Hp30 ---
file_hp30 = fullfile(AUX_DATA_PATH, 'hp30_data_19970101_20250930.csv');
if ~isfile(file_hp30), error('文件缺失: %s', file_hp30); end
hp30_table = readtable(file_hp30);

if isdatetime(hp30_table.Timestamp_UTC)
    if isempty(hp30_table.Timestamp_UTC.TimeZone)
        hp30_table.Timestamp_UTC.TimeZone = 'UTC';
    end
else
    hp30_table.Timestamp_UTC = datetime(hp30_table.Timestamp_UTC, 'TimeZone', 'UTC');
end
t_ref_2000_dt = datetime(2000, 1, 1, 0, 0, 0, 'TimeZone', 'UTC');
hp30_vals = [days(hp30_table.Timestamp_UTC - t_ref_2000_dt), hp30_table.Hp30_Value];

% --- 2.3 加载 RC Index ---
file_rc = fullfile(AUX_DATA_PATH, 'RC_1997-2025_Sept25_v3_allLT.dat');
if ~isfile(file_rc), error('文件缺失: %s', file_rc); end
rc_data = readmatrix(file_rc, 'FileType', 'text', 'NumHeaderLines', 7);
[t_rc_sort, idx] = sort(rc_data(:,1));
drc_dt = gradient(rc_data(idx,2), t_rc_sort * 24.0);
rc_deriv = [t_rc_sort, drc_dt];

fprintf('   辅助数据加载完成。\n');

%% ------------------- 3. 统一流读取 (单星处理) -------------------
disp('3. 数据读取：Orsted -> 15s降采样...');

global_data_container = {}; 

% --- 扫描文件夹 ---
files_struct = dir(fullfile(data_folder, '*.cdf'));

% [新增] 过滤掉文件名中包含 'empty' 的无效文件
idx_empty = contains({files_struct.name}, 'empty', 'IgnoreCase', true);
if any(idx_empty)
    fprintf('   已自动跳过 %d 个标记为 empty 的文件。\n', sum(idx_empty));
    files_struct = files_struct(~idx_empty);
end

if isempty(files_struct)
    error('在路径中未找到有效的CDF文件 (已过滤empty文件): %s', data_folder);
end

% 排序文件
[~, sort_idx] = sort({files_struct.name});
files_to_process = files_struct(sort_idx);

% --- 采样控制 ---
num_files = length(files_to_process);
if ENABLE_RANDOM_SAMPLING
    rng(42); 
    n_samp = max(1, round(num_files * RANDOM_SAMPLE_RATIO));
    rand_idx = sort(randperm(num_files, n_samp));
    files_to_process = files_to_process(rand_idx);
    fprintf('   [随机模式] 选中 %d 个文件\n', n_samp);
else
    fprintf('   [全量模式] 选中 %d 个文件\n', num_files);
end

% --- 读取循环 ---
sat_data_cell = cell(length(files_to_process), 1);
q = parallel.pool.DataQueue;
afterEach(q, @(~) fprintf('.')); 
fprintf('      进度: ');

parfor k = 1:length(files_to_process)
    % 调用之前修改过的 process_single_cdf_file (支持Orsted)
    raw = process_single_cdf_file(files_to_process(k), data_folder, ref_dn_2000, BINNING_WINDOW_SEC);
    if isempty(raw), continue; end
    
    % 数据结构: [Lat, Lon, Rad, B_NEC(3), t_dn, F]
    % 添加 SatID 列 (Orsted 设为 1)
    % raw 格式: 1:Lat, 2:Lon, 3:Rad, 4-6:B_NEC, 7:Time, 8:F
    data_chunk = [raw(:,1:3), raw(:,4:6), raw(:,7), raw(:,8), ones(size(raw,1),1)];
    sat_data_cell{k} = data_chunk;
    send(q, k);
end
fprintf('\n');

% 合并数据
global_data_container = vertcat(sat_data_cell{:});
clear sat_data_cell;

if isempty(global_data_container)
    error('没有读取到有效数据，请检查文件格式或读取函数。');
end

% --- 变量标准化 ---
[~, sort_t_idx] = sort(global_data_container(:,7)); 
all_data = global_data_container(sort_t_idx, :);

lat_obs = all_data(:,1); lon_obs = all_data(:,2); r_obs = all_data(:,3);
bnec_obs= all_data(:,4:6); t_dn = all_data(:,7); F_obs = all_data(:,8);
sat_id_obs = all_data(:,9);

t_mjd = t_dn - ref_dn_2000;
t_utc = datetime(t_dn, 'ConvertFrom', 'datenum', 'TimeZone', 'UTC');

total_points = length(lat_obs);
fprintf('   15s降采样数据准备完毕。总点数: %d\n', total_points);

%% ------------------- 4. 前置筛选 (使用 sunGEI，时间对齐) -------------------
disp('4. 执行前置筛选 (Night, RC, Hp30, Em/Bz)...');

% =========================================================================
% 1. 时间诊断
% =========================================================================
t_dn_obs = t_dn; 
fprintf('   [诊断] 数据时间范围: %s 到 %s\n', datestr(min(t_dn_obs)), datestr(max(t_dn_obs)));

% =========================================================================
% 2. 太阳位置计算 (使用 sunGEI，核心修改)
% =========================================================================
% 1. 确认 sunGEI 的时间输入类型
% 检查你的 sunGEI.m 代码，看看它期望的输入是什么
% 通常是 MJD2000 (自 2000 年起的天数)，或者是 MATLAB datenum
% 根据你提供的代码，我们假设 sunGEI 接受的是 MJD2000
% 如果 sunGEI 接受的是 Datenum，请注释掉以下代码，用 datenum(t_dn_obs)
% 2.  如果需要使用MJD2000，请按如下操作
t_mjd2000 = t_dn_obs - datenum(2000, 1, 1); % 转换到 MJD2000
[sun_vec_GEI, ~] = sunGEI(t_mjd2000); % 调用太阳位置函数

% 验证 sunGEI 的结果 (输出太阳天顶角，方便快速检查)
theta_rad = deg2rad(90 - lat_obs);
phi_rad = deg2rad(lon_obs);
sat_x = sin(theta_rad) .* cos(phi_rad);
sat_y = sin(theta_rad) .* sin(phi_rad);
sat_z = cos(theta_rad);
% 计算GST
jd = t_dn_obs + 1721058.5;
T_century = (jd - 2451545.0) / 36525.0;
GST = 280.46061837 + 360.98564736629 * (jd - 2451545.0) + T_century.^2 * 0.000387933 - T_century.^3 / 38710000;
GST = mod(GST, 360) * pi / 180;
cos_gst = cos(GST); sin_gst = sin(GST);
sat_vec_GEI_x = sat_x .* cos_gst - sat_y .* sin_gst;
sat_vec_GEI_y = sat_x .* sin_gst + sat_y .* cos_gst;
sat_vec_GEI_z = sat_z;

cos_theta = sun_vec_GEI(:,1) .* sat_vec_GEI_x + sun_vec_GEI(:,2) .* sat_vec_GEI_y + sun_vec_GEI(:,3) .* sat_vec_GEI_z;
mask_night = rad2deg(acos(max(min(cos_theta, 1), -1))) > 100;
% --- 4.2 RC 筛选 ---
t_rc = rc_data(:,1);
if mean(t_rc) > 40000 % 假设是 MJD (1858)
    t_query_rc = t_dn_obs - 678942; % datenum -> MJD
elseif mean(t_rc) < 3000 % 假设是小数年份
    t_query_rc = t_dn_obs; 
else % 假设是 MJD2000
    t_query_rc = t_dn_obs - datenum(2000,1,1);
end

% 去重插值
[u_rc_t, idx_u] = unique(rc_data(:,1));
u_rc_val = rc_deriv(idx_u, 2);
drc_val = interp1(u_rc_t, u_rc_val, t_query_rc, 'linear', 'extrap');
mask_rc = abs(drc_val) <= 2;

% --- 4.3 Hp30 筛选 ---
t_hp_dn = datenum(hp30_table.Timestamp_UTC);
mask_hp = interp1(t_hp_dn, hp30_table.Hp30_Value, t_dn_obs, 'nearest', 'extrap') <= 2;

% --- 4.4 Delta-F 一致性 ---
b_mag = vecnorm(bnec_obs, 2, 2);
mask_df = (abs(F_obs - b_mag) <= 100) | isnan(b_mag); 

% --- 4.5 OMNI (Em/Bz) 筛选 ---
t_omni_dn = datenum(em_table.datetime);
em_val = interp1(t_omni_dn, em_table.avg_em_2h, t_dn_obs, 'nearest', 'extrap');
bz_val = interp1(t_omni_dn, em_table.avg_bz_2h, t_dn_obs, 'nearest', 'extrap');
mask_em = (em_val <= 0.8) | isnan(em_val);
mask_bz = (bz_val > 0) | isnan(bz_val);

% =========================================================================
% 3. 统计与合并
% =========================================================================
fprintf('   --- 筛选通过率诊断 ---\n');
fprintf('   1. Night Side:   %.2f%%\n', sum(mask_night)/total_points*100);
fprintf('   2. RC Index:     %.2f%%\n', sum(mask_rc)/total_points*100);
fprintf('   3. Hp30:         %.2f%%\n', sum(mask_hp)/total_points*100);
fprintf('   4. Delta-F Check:%.2f%%\n', sum(mask_df)/total_points*100);
fprintf('   5. Em / Bz:      %.2f%% / %.2f%%\n', sum(mask_em)/total_points*100, sum(mask_bz)/total_points*100);

mask_pre_calc = mask_night & mask_rc & mask_hp & mask_df & mask_em & mask_bz;
count_pass = sum(mask_pre_calc);

fprintf('   前置筛选最终结果: %d / %d (%.1f%%)\n', count_pass, total_points, count_pass/total_points*100);

if count_pass == 0
    error('前置筛选后无数据！请检查上方诊断信息（特别是时间范围）。');
end

%% ------------------- 5. CHAOS 计算 (计算残差) -------------------
disp('5. 计算 CHAOS 背景场...');

idx_calc = find(mask_pre_calc);
if isempty(idx_calc), error('前置筛选后无数据！'); end

% 提取子集
t_sub = t_mjd(idx_calc); r_sub = r_obs(idx_calc);
lat_sub = lat_obs(idx_calc); lon_sub = lon_obs(idx_calc);

% 加载 CHAOS 模型
addpath('CHAOS-8.4_FWD\'); 
try load('CHAOS-8.4.mat'); catch, error('CHAOS mat missing'); end

% 配置 CHAOS
N_core=20; pp_core=pp; pp_core.dim=N_core*(N_core+2); 
coefs_tmp=reshape(pp.coefs,[],pp.pieces,pp.order);
pp_core.coefs=reshape(coefs_tmp(1:N_core*(N_core+2),:,:),[],pp.order);
g_crust=g(1:(110*(110+2))); mod_ext=model_ext; dip=[-29442.0, -1501.0, 4797.1];
RC_interp = interp1(rc_data(:,1), rc_data(:,3:4), t_sub, 'linear');

% 并行计算背景场
n_sub = length(t_sub);
chunk_size = 50000;
num_chunks = ceil(n_sub / chunk_size);
out_B = cell(num_chunks, 1);

parfor i = 1:num_chunks
    c_idx = (i-1)*chunk_size+1 : min(i*chunk_size, n_sub);
    th_d = 90 - lat_sub(c_idx);
    
    % Core + Crust + External
    B_c = synth_values(r_sub(c_idx), th_d, lon_sub(c_idx), pp_core, t_sub(c_idx));
    B_k = synth_values(r_sub(c_idx), th_d, lon_sub(c_idx), g_crust);
    B_e = synth_values_CHAOS_ext(t_sub(c_idx), r_sub(c_idx), th_d, lon_sub(c_idx), ...
        RC_interp(c_idx,:), mod_ext, dip, 'GSM_SM_SHA_3D_IGRF12_2015.mat');
    
    out_B{i} = B_c + B_k + B_e;
end
B_model_sub = vertcat(out_B{:});
clear pp_core g g_crust out_B;

% 计算残差
bnec_sub = bnec_obs(idx_calc, :);
% 注意：观测值转为 NEC -> r, theta, phi 对应 -Z, -X, Y ? 
% 通常 bnec 是 North, East, Center(Down)
% 这里假设 B_model 输出也是 NEC
B_res_sub = bnec_sub - B_model_sub; % 简单的矢量相减，具体取决于 B_obs_vec_sub 的定义

% 计算标量残差 (最关键的量)
F_mod_sub = vecnorm(B_model_sub, 2, 2);
dF_res_sub = F_obs(idx_calc) - F_mod_sub;

% 计算辅助参数
fprintf('   计算 QD 纬度...\n');
QD_lat_sub = calculate_QD_Lat(B_model_sub, r_sub);
Dir_sub = B_model_sub ./ F_mod_sub; % 单位方向向量

%% ------------------- 6. 后置筛选 (By, 粗差) - [修复变量定义] -------------------
disp('6. 执行后置筛选 (By 干扰剔除 & 粗差剔除)...');

% 1. 获取 By 数据
t_sub_dn = t_sub + datenum(2000, 1, 1); 
if ~exist('t_omni_dn', 'var')
    t_omni_dn = datenum(em_table.datetime);
end
by_vals_sub = interp1(t_omni_dn, em_table.avg_by_2h, t_sub_dn, 'nearest', 'extrap');

% 2. By 筛选
mask_by_sub = false(size(QD_lat_sub));
is_north = QD_lat_sub > 0;
mask_by_sub(is_north)  = by_vals_sub(is_north) < 3;
mask_by_sub(~is_north) = by_vals_sub(~is_north) > -3;
mask_by_sub(isnan(by_vals_sub)) = false;

% 3. 粗差筛选
mask_gross_sub = abs(dF_res_sub) < 20; 

% 4. 合并
mask_final_sub = mask_by_sub & mask_gross_sub;
idx_final_rel = find(mask_final_sub);

% 5. 提取最终变量
t_fin = t_sub(idx_final_rel);
r_fin = r_sub(idx_final_rel); 
lat_fin = lat_sub(idx_final_rel); 
lon_fin = lon_sub(idx_final_rel);
qd_fin = QD_lat_sub(idx_final_rel);
dF_res_fin = dF_res_sub(idx_final_rel);
Dir_fin = Dir_sub(idx_final_rel, :);

% [修复] 显式定义 sat_fin (Orsted = 1)
sat_fin = ones(length(t_fin), 1);

fprintf('   后置筛选统计:\n');
fprintf('     - By 筛选通过率: %.1f%%\n', sum(mask_by_sub)/length(mask_by_sub)*100);
fprintf('     - 粗差筛选通过率: %.1f%%\n', sum(mask_gross_sub)/length(mask_gross_sub)*100);
fprintf('   最终保留数据点: %d / %d (%.1f%%)\n', ...
    length(t_fin), length(t_sub), length(t_fin)/length(t_sub)*100);

%% ------------------- 7. 保存绝对数据 (仅标量，全纬度) -------------------
disp('7. 保存绝对数据 (Orsted Scalar Data - All Latitudes)...');

if isempty(t_fin)
    warning('没有数据可通过保存！');
else
    Data_Scalar_Orig = struct('Time', t_fin, ...
        'Pos', [r_fin, 90-lat_fin, lon_fin], ... 
        'dF', dF_res_fin, ...
        'Dir', Dir_fin, ...
        'QD_Lat', qd_fin, ...
        'SatID', sat_fin, ... % 现在这里不会报错了
        'Weight', ones(length(t_fin),1));
    
    save('Orsted_ACC_Input_Original_Scalar.mat', 'Data_Scalar_Orig');
    fprintf('   标量数据保存完成 (Orsted_ACC_Input_Original_Scalar.mat)。\n');
end

%% ------------------- 8. 沿轨梯度计算 (全局索引回溯版) -------------------
disp('8. 计算单星沿轨标量梯度 (15s间隔)...');

% =========================================================================
% 核心思路修正：
% 1. 在"全量数据"层面寻找时间间隔为 15s 的物理点对 (i, i+1)。
% 2. 检查点 i 和 i+1 是否"同时"通过了之前所有的筛选 (Step 4 + Step 6)。
% 3. 只有两者都有效时，才计算梯度。
% =========================================================================

% 1. 构建全局有效性掩膜 (Global Mask)
%    初始化全为 false (无效)
mask_global_valid = false(total_points, 1);

%    idx_calc: 通过 Step 4 (前置筛选) 的原始索引
%    mask_final_sub: 在 idx_calc 基础上通过 Step 6 (后置筛选) 的逻辑掩膜
%    找到最终有效的原始索引:
idx_final_global = idx_calc(mask_final_sub);
mask_global_valid(idx_final_global) = true;

fprintf('   - 全局有效点数 (筛选后): %d\n', length(idx_final_global));

% 2. 将计算好的残差 (dF) 映射回全局数组
%    (因为之前只计算了子集的残差，这里需要复原，未计算的留 NaN)
dF_global = nan(total_points, 1);
dF_global(idx_calc) = dF_res_sub; 

%    还需要全局的 Dir (方向向量)，用于保存
Dir_global = nan(total_points, 3);
Dir_global(idx_calc, :) = Dir_sub;

%    还需要全局的 QDLat
QD_global = nan(total_points, 1);
QD_global(idx_calc) = QD_lat_sub;

% 3. 在全局时间轴上寻找 15s 间隔的物理相邻点
%    t_dn 是 Step 3 产生的全量时间 (已排序)
dt_global = diff(t_dn) * 86400; % 秒
raw_pair_idx = find(abs(dt_global - BINNING_WINDOW_SEC) <= 0.5);

fprintf('   - 原始数据中 15s 间隔的物理点对数: %d\n', length(raw_pair_idx));

if isempty(raw_pair_idx)
    warning('数据中完全没有 15s 间隔的连续数据，可能是降采样步长设置错误！');
    Data_Scalar_Grad = [];
else
    % 定义候选点对索引 (原始全局索引)
    i1 = raw_pair_idx;
    i2 = raw_pair_idx + 1;
    
    % 4. 关键筛选：要求 i1 和 i2 必须同时有效
    mask_pair_valid = mask_global_valid(i1) & mask_global_valid(i2);
    
    % 提取最终有效的点对索引
    fin_i1 = i1(mask_pair_valid);
    fin_i2 = i2(mask_pair_valid);
    
    fprintf('   - 双端均通过筛选的有效梯度对数: %d\n', length(fin_i1));
    
    if isempty(fin_i1)
        warning('没有梯度点对通过筛选 (数据过于破碎)。');
        Data_Scalar_Grad = [];
    else
        % 5. 计算梯度 (使用映射好的全局残差)
        dF1 = dF_global(fin_i1);
        dF2 = dF_global(fin_i2);
        
        g_s = dF2 - dF1;
        
        % 6. 梯度本身的粗差剔除 (去除异常突变)
        %    阈值: 20 nT / 15s
        mask_grad_val = abs(g_s) < 20;
        
        % 应用梯度值筛选
        valid_g_idx = find(mask_grad_val);
        fin_i1 = fin_i1(valid_g_idx);
        fin_i2 = fin_i2(valid_g_idx);
        g_s_final = g_s(valid_g_idx);
        
        if isempty(g_s_final)
            Data_Scalar_Grad = [];
        else
            % 提取其他信息用于保存 (使用 i1 点的信息)
            t_final  = t_dn(fin_i1);
            t2_final = t_dn(fin_i2);
            
            % 位置 (从全量数据提取)
            pos1 = [r_obs(fin_i1), 90-lat_obs(fin_i1), lon_obs(fin_i1)];
            pos2 = [r_obs(fin_i2), 90-lat_obs(fin_i2), lon_obs(fin_i2)];
            
            % 辅助数据 (从映射好的全局数组提取)
            Dir_final = Dir_global(fin_i1, :);
            QD_final  = QD_global(fin_i1);
            
            % 构建结构体
            Data_Scalar_Grad = struct(...
                'Time1', t_final, ...
                'Time2', t2_final, ...
                'Pos1', pos1, ...
                'Pos2', pos2, ...
                'd_grad', g_s_final, ...
                'Dir', Dir_final, ...
                'QD_Lat', QD_final, ...
                'SatID', ones(length(t_final), 1), ... % Orsted = 1
                'Weight', ones(length(t_final), 1));
            
            fprintf('   - 梯度值筛选(<20nT)后最终保留: %d\n', length(g_s_final));
        end
    end
end

save('Orsted_ACC_Input_Gradient_Scalar.mat', 'Data_Scalar_Grad');
fprintf('   沿轨梯度保存完成 (Orsted_ACC_Input_Gradient_Scalar.mat)。\n');
% 移除星间梯度部分 (Section 9 Removed)

%% 结束
toc;