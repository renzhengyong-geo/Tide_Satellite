% =========================================================================
% CryoSat-2 (CS-2) 潮汐提取预处理程序
% 基于 Swarm/MSS 架构修改适配
% 核心功能:
% 1. [单一路径] 读取 CryoSat 文件夹数据 (CDF格式)
% 2. [单星处理] 针对 CryoSat-2 极轨卫星进行筛选 (Night/RC/Hp30)
% 3. [梯度计算] 仅保留单星沿轨梯度 (15s差分)
% =========================================================================
clc; clear; close all;
tic;

% 初始化并行池
max_workers = min(6, feature('numcores'));
p = gcp('nocreate');
if isempty(p), parpool('local', max_workers); end

%% ------------------- 1. 参数设定 -------------------
disp('1. 设定参数...');

% [修改] CryoSat 数据文件夹路径
% 请修改为您实际存放 CryoSat CDF 文件的路径
single_data_folder = fullfile('..', '..', 'Satellite_Data', 'CryoSat');

% [标识] 设定 CryoSat 的卫星 ID (例如 90)
SAT_ID_CRYOSAT = 90;

% [功能] 随机读取控制 (测试时可开启)
ENABLE_RANDOM_SAMPLING = false;   
RANDOM_SAMPLE_RATIO    = 0.1; 

% [策略]
% 基础采样间隔设定为15秒 (用于读取和单星处理)
BINNING_WINDOW_SEC  = 60;  
ref_dn_2000 = datenum(2000, 1, 1, 0, 0, 0);

%% ------------------- 2. 加载辅助数据 -------------------
disp('2. 加载环境参数 (Em, Hp30, RC)...');

AUX_DATA_PATH = '../'; % 辅助数据路径

% --- 2.1 加载 Em/Bz/By (分钟级) ---
file_em = fullfile(AUX_DATA_PATH, 'omni_min_em_bz_2h_avg.csv');
if ~isfile(file_em), error('文件缺失: %s', file_em); end
em_table = readtable(file_em);
% 构造 datetime 对象
em_table.datetime = datetime(em_table.year, 1, 1, 0, 0, 0) + ...
    days(em_table.day - 1) + hours(em_table.hour) + minutes(em_table.minute);
em_table.datetime.TimeZone = 'UTC'; 

% --- 2.2 加载 Hp30 ---
file_hp30 = fullfile(AUX_DATA_PATH, 'hp30_data_19970101_20250930.csv');
if ~isfile(file_hp30), error('文件缺失: %s', file_hp30); end
hp30_table = readtable(file_hp30);

if isdatetime(hp30_table.Timestamp_UTC)
    if isempty(hp30_table.Timestamp_UTC.TimeZone)
        hp30_table.Timestamp_UTC.TimeZone = 'UTC';
    end
else
    hp30_table.Timestamp_UTC = datetime(hp30_table.Timestamp_UTC, 'TimeZone', 'UTC');
end
t_ref_2000_dt = datetime(2000, 1, 1, 0, 0, 0, 'TimeZone', 'UTC');
hp30_vals = [days(hp30_table.Timestamp_UTC - t_ref_2000_dt), hp30_table.Hp30_Value];

% --- 2.3 加载 RC Index ---
file_rc = fullfile(AUX_DATA_PATH, 'RC_1997-2025_Sept25_v3_allLT.dat');
if ~isfile(file_rc), error('文件缺失: %s', file_rc); end
rc_data = readmatrix(file_rc, 'FileType', 'text', 'NumHeaderLines', 7);
[t_rc_sort, idx] = sort(rc_data(:,1));
drc_dt = gradient(rc_data(idx,2), t_rc_sort * 24.0);
rc_deriv = [t_rc_sort, drc_dt];

fprintf('   辅助数据加载完成。\n');

%% ------------------- 3. 统一流读取 CryoSat 数据 -------------------
disp('3. 数据读取：CryoSat 递归扫描 -> 15s降采样...');

global_data_container = {}; 

% --- 步骤 A: 递归扫描所有子文件夹 ---
if ~isfolder(single_data_folder)
    error('文件夹不存在: %s', single_data_folder);
end

fprintf('   正在递归扫描目录: %s\n', single_data_folder);
% 扫描 CDF 文件
raw_files = dir(fullfile(single_data_folder, '**', '*.cdf'));
raw_files = raw_files(~[raw_files.isdir]);

if isempty(raw_files)
    error('在路径及其子文件夹中未找到任何CDF文件: %s', single_data_folder);
end
fprintf('   共扫描到 %d 个CDF文件。\n', length(raw_files));

% --- 步骤 B: 建立文件列表 ---
files_to_process = struct('name', {}, 'folder', {}, 'sat_id', {});
valid_count = 0;

for k = 1:length(raw_files)
    fname = raw_files(k).name;
    
    % 这里可以增加针对 CryoSat 文件名的过滤，例如:
    % if ~contains(fname, 'CS_') && ~contains(fname, 'MAG'), continue; end
    
    valid_count = valid_count + 1;
    files_to_process(valid_count).name = fname;
    files_to_process(valid_count).folder = raw_files(k).folder;
    files_to_process(valid_count).sat_id = SAT_ID_CRYOSAT; 
end

fprintf('   待处理 CryoSat 文件: %d 个\n', valid_count);

% --- 步骤 C: 采样控制 ---
if ENABLE_RANDOM_SAMPLING
    fprintf('   [随机模式] 随机抽取部分文件...\n');
    n_samp = max(1, round(valid_count * RANDOM_SAMPLE_RATIO));
    rand_idx = randperm(valid_count, n_samp);
    files_to_process = files_to_process(sort(rand_idx));
    fprintf('   -> 最终选中文件数: %d\n', length(files_to_process));
end

% --- 步骤 D: 读取并直接降采样 ---
num_files = length(files_to_process);
sat_data_cell = cell(num_files, 1);

q = parallel.pool.DataQueue;
afterEach(q, @(~) fprintf('.')); 
fprintf('      读取进度: ');

parfor k = 1:num_files
    curr_file = files_to_process(k);
    
    % [重要] 调用 CryoSat 专用的 CDF 处理函数
    % 请确保该函数返回格式为: [Lat, Lon, Radius_km, B_NEC(3), t_dn, F, SatID_Placeholder]
    % 注意: Radius 单位必须是 km (Re + altitude)
    raw = process_single_cdf_file_CryoSat(curr_file, curr_file.folder, ref_dn_2000, BINNING_WINDOW_SEC);
    
    if isempty(raw), continue; end
    
    % 重新组装数据，确保最后一列是正确的 SatID
    % 假设 raw(:,1:8) 是数据内容，手动附加 SatID
    data_chunk = [raw(:,1:3), raw(:,4:6), raw(:,7), raw(:,8), ones(size(raw,1),1)*curr_file.sat_id];
    sat_data_cell{k} = data_chunk;
    send(q, k);
end
fprintf('\n');

% --------------------- 数据合并 ---------------------
disp('   正在合并所有数据...');
global_data_container = sat_data_cell(~cellfun('isempty', sat_data_cell));
if isempty(global_data_container)
    warning('所有文件读取后数据为空！请检查子函数读取逻辑。'); 
else
    all_data = vertcat(global_data_container{:});
    [~, sort_t_idx] = sort(all_data(:,7)); 
    all_data = all_data(sort_t_idx, :);
end
clear global_data_container sat_data_cell;

if ~exist('all_data', 'var') || isempty(all_data)
    error('无有效数据，程序终止。');
end

% 变量标准化
lat_obs = all_data(:,1); lon_obs = all_data(:,2); r_obs = all_data(:,3);
bnec_obs= all_data(:,4:6); t_dn = all_data(:,7); F_obs = all_data(:,8);
sat_id_obs = all_data(:,9);

t_mjd = t_dn - ref_dn_2000;
t_utc = datetime(t_dn, 'ConvertFrom', 'datenum', 'TimeZone', 'UTC');

total_points = length(lat_obs);
fprintf('   CryoSat 数据准备完毕。总点数: %d\n', total_points);

%% ------------------- 4. 前置筛选 (Night, RC, Hp30, Em/Bz) -------------------
disp('4. 执行前置筛选 (Night, RC, Hp30, Em/Bz)...');

% --- 4.1 夜间筛选 ---
% 计算太阳天顶角
[sun_vec_GEI, GST] = sunGEI(t_mjd);
theta_rad = deg2rad(90 - lat_obs); phi_rad = deg2rad(lon_obs);      
sat_x = sin(theta_rad) .* cos(phi_rad); sat_y = sin(theta_rad) .* sin(phi_rad); sat_z = cos(theta_rad);

cos_gst = cos(GST); sin_gst = sin(GST);
sat_vec_GEI_x = sat_x .* cos_gst - sat_y .* sin_gst;
sat_vec_GEI_y = sat_x .* sin_gst + sat_y .* cos_gst;
sat_vec_GEI_z = sat_z;

cos_theta = sun_vec_GEI(:,1) .* sat_vec_GEI_x + sun_vec_GEI(:,2) .* sat_vec_GEI_y + sun_vec_GEI(:,3) .* sat_vec_GEI_z;
mask_night = rad2deg(acos(max(min(cos_theta, 1), -1))) > 100;

% --- 4.2 RC/Hp30/DF/OMNI 筛选 ---
drc_val = interp1(rc_deriv(:,1), rc_deriv(:,2), t_mjd, 'linear', 'extrap');
mask_rc = abs(drc_val) <= 2;

hp_val = interp1(hp30_vals(:,1), hp30_vals(:,2), t_mjd, 'nearest', 'extrap');
mask_hp = hp_val <= 2;

% Delta-F 粗筛 (100nT)
mask_df = abs(F_obs - vecnorm(bnec_obs,2,2)) <= 100;

sat_min = dateshift(t_utc, 'start', 'minute');
[~, loc] = ismember(sat_min, em_table.datetime);
valid_omni = loc > 0;

mask_em = false(size(mask_night)); mask_bz = false(size(mask_night));
if any(valid_omni)
    matched_idx = loc(valid_omni);
    mask_em(valid_omni) = em_table.avg_em_2h(matched_idx) <= 0.8;
    mask_bz(valid_omni) = em_table.avg_bz_2h(matched_idx) > 0;
end

mask_pre_calc = mask_night & mask_rc & mask_hp & mask_df & mask_em & mask_bz;
fprintf('   前置筛选通过: %d / %d (%.1f%%)\n', sum(mask_pre_calc), total_points, sum(mask_pre_calc)/total_points*100);

%% ------------------- 5. CHAOS 计算 (仅针对有效点) -------------------
disp('5. 计算 CHAOS 背景场 (使用 CHAOS-8.4)...');

idx_calc = find(mask_pre_calc);
if isempty(idx_calc), error('前置筛选后无数据！'); end

t_sub = t_mjd(idx_calc); r_sub = r_obs(idx_calc);
lat_sub = lat_obs(idx_calc); lon_sub = lon_obs(idx_calc);

% 确保 CHAOS 文件夹存在
addpath('CHAOS-8.4_FWD\'); 
try load('CHAOS-8.4.mat'); catch, error('CHAOS mat missing'); end

% 配置 CHAOS
N_core=20; pp_core=pp; pp_core.dim=N_core*(N_core+2); 
coefs_tmp=reshape(pp.coefs,[],pp.pieces,pp.order);
pp_core.coefs=reshape(coefs_tmp(1:N_core*(N_core+2),:,:),[],pp.order);
g_crust=g(1:(110*(110+2))); mod_ext=model_ext; dip=[-29442.0, -1501.0, 4797.1];
RC_interp = interp1(rc_data(:,1), rc_data(:,3:4), t_sub, 'linear');

n_sub = length(t_sub);
chunk_size = 50000;
num_chunks = ceil(n_sub / chunk_size);
out_B = cell(num_chunks, 1);

parfor i = 1:num_chunks
    c_idx = (i-1)*chunk_size+1 : min(i*chunk_size, n_sub);
    th_d = 90 - lat_sub(c_idx);
    B_c = synth_values(r_sub(c_idx), th_d, lon_sub(c_idx), pp_core, t_sub(c_idx));
    B_k = synth_values(r_sub(c_idx), th_d, lon_sub(c_idx), g_crust);
    
    % 外部场计算
    B_e = synth_values_CHAOS_ext(t_sub(c_idx), r_sub(c_idx), th_d, lon_sub(c_idx), ...
        RC_interp(c_idx,:), mod_ext, dip, 'GSM_SM_SHA_3D_IGRF12_2015.mat');
    out_B{i} = B_c + B_k + B_e;
end
B_model_sub = vertcat(out_B{:});
clear pp_core g g_crust out_B;

% 计算残差
bnec_sub = bnec_obs(idx_calc, :);
B_obs_vec_sub = [-bnec_sub(:,3), -bnec_sub(:,1), bnec_sub(:,2)]; 
B_res_sub = B_obs_vec_sub - B_model_sub;
F_mod_sub = vecnorm(B_model_sub, 2, 2);
dF_res_sub = F_obs(idx_calc) - F_mod_sub;

fprintf('   计算 QD 纬度...\n');
QD_lat_sub = calculate_QD_Lat(B_model_sub, r_sub);
Dir_sub = B_model_sub ./ F_mod_sub;

%% ------------------- 6. 后置筛选 (By, 粗差) -------------------
disp('6. 执行后置筛选...');

loc_sub = loc(idx_calc);
valid_omni_sub = loc_sub > 0;
mask_by_sub = false(size(QD_lat_sub));
if any(valid_omni_sub)
    by_vals = em_table.avg_by_2h(loc_sub(valid_omni_sub));
    qd_check = QD_lat_sub(valid_omni_sub);
    is_north = qd_check > 0;
    tmp_pass = false(size(qd_check));
    tmp_pass(is_north) = by_vals(is_north) < 3;
    tmp_pass(~is_north) = by_vals(~is_north) > -3;
    mask_by_sub(valid_omni_sub) = tmp_pass;
end

mask_gross_sub = false(size(QD_lat_sub));
% 极轨卫星处理策略：
% QD Lat < 55: 矢量 + 标量 均需质量好
% QD Lat >= 55: 仅使用标量 (忽略矢量分量中的极光电流干扰)
mask_low = abs(QD_lat_sub) < 55;
mask_gross_sub(mask_low) = (vecnorm(B_res_sub(mask_low,:),2,2) < 40) & (abs(dF_res_sub(mask_low)) < 40);
mask_gross_sub(~mask_low) = abs(dF_res_sub(~mask_low)) < 40;

mask_final_sub = mask_by_sub & mask_gross_sub;
idx_final_rel = find(mask_final_sub);

% 提取最终变量
t_fin = t_sub(idx_final_rel);
r_fin = r_sub(idx_final_rel); lat_fin = lat_sub(idx_final_rel); lon_fin = lon_sub(idx_final_rel);
qd_fin = QD_lat_sub(idx_final_rel);
sat_fin = sat_id_obs(idx_calc(idx_final_rel));
B_res_fin = B_res_sub(idx_final_rel, :);
dF_res_fin = dF_res_sub(idx_final_rel);
Dir_fin = Dir_sub(idx_final_rel, :);

fprintf('   最终保留 CryoSat 数据点: %d\n', length(t_fin));

%% ------------------- 7. 保存绝对数据 -------------------
disp('7. 保存绝对数据 (Weighted)...');

mask_vec = abs(qd_fin) < 55;
mask_sca = abs(qd_fin) >= 55;

Data_Vector_Orig = struct('Time', t_fin(mask_vec), ...
    'Pos', [r_fin(mask_vec), 90-lat_fin(mask_vec), lon_fin(mask_vec)], ...
    'B_res', B_res_fin(mask_vec,:), 'QD_Lat', qd_fin(mask_vec), ...
    'SatID', sat_fin(mask_vec), 'Weight', ones(sum(mask_vec),1));

% 极轨卫星在高纬度主要贡献 Scalar 数据
Data_Scalar_Orig = struct('Time', t_fin(mask_sca), ...
    'Pos', [r_fin(mask_sca), 90-lat_fin(mask_sca), lon_fin(mask_sca)], ...
    'dF', dF_res_fin(mask_sca), 'Dir', Dir_fin(mask_sca,:), ...
    'QD_Lat', qd_fin(mask_sca), 'SatID', sat_fin(mask_sca), ...
    'Weight', ones(sum(mask_sca),1));

% [保存] 文件名改为 CryoSat
save('CryoSat_Input_Original_Weighted.mat', 'Data_Vector_Orig', 'Data_Scalar_Orig');

%% ------------------- 8. 单星梯度计算 (15s间隔) -------------------
disp('8. 计算 CryoSat 单星梯度 (15s间隔)...');

vec_grad_structs = []; sca_grad_structs = [];
curr_sat = SAT_ID_CRYOSAT;
idx_sat = find(sat_fin == curr_sat);

if length(idx_sat) >= 2
    t_c = t_fin(idx_sat);
    r_c = r_fin(idx_sat); lat_c = lat_fin(idx_sat); lon_c = lon_fin(idx_sat);
    B_c = B_res_fin(idx_sat, :); dF_c = dF_res_fin(idx_sat);
    Dir_c = Dir_fin(idx_sat, :); qd_c = qd_fin(idx_sat);
    
    dt_sec = diff(t_c) * 86400;
    % 寻找相邻点 (15s)
    valid_pairs = find(abs(dt_sec - BINNING_WINDOW_SEC) <= 0.1);
    
    if ~isempty(valid_pairs)
        i1 = valid_pairs; i2 = valid_pairs + 1;
        
        g_v = B_c(i2,:) - B_c(i1,:);
        g_s = dF_c(i2) - dF_c(i1);
        
        % 筛选: 同样遵循低纬度矢量，全球标量的逻辑
        mask_gv = (abs(qd_c(i1)) < 55) & (vecnorm(g_v, 2, 2) < 15);
        mask_gs = (abs(g_s) < 15); % CryoSat 高纬度梯度数据主要依靠 Scalar
        
        if sum(mask_gv) > 0
            idx1 = i1(mask_gv); idx2 = i2(mask_gv);
            S_vec = struct('Time1', t_c(idx1), 'Time2', t_c(idx2), ...
                'Pos1', [r_c(idx1), 90-lat_c(idx1), lon_c(idx1)], ...
                'Pos2', [r_c(idx2), 90-lat_c(idx2), lon_c(idx2)], ...
                'd_grad', g_v(mask_gv,:), 'QD_Lat', qd_c(idx1), ...
                'SatID', curr_sat*ones(length(idx1),1), 'Weight', ones(length(idx1),1));
            vec_grad_structs = [vec_grad_structs; S_vec]; 
        end
        
        if sum(mask_gs) > 0
            idx1 = i1(mask_gs); idx2 = i2(mask_gs);
            S_sca = struct('Time1', t_c(idx1), 'Time2', t_c(idx2), ...
                'Pos1', [r_c(idx1), 90-lat_c(idx1), lon_c(idx1)], ...
                'Pos2', [r_c(idx2), 90-lat_c(idx2), lon_c(idx2)], ...
                'd_grad', g_s(mask_gs), 'Dir', Dir_c(idx1,:), ...
                'QD_Lat', qd_c(idx1), ...
                'SatID', curr_sat*ones(length(idx1),1), 'Weight', ones(length(idx1),1));
            sca_grad_structs = [sca_grad_structs; S_sca]; 
        end
    end
end

if isempty(vec_grad_structs), Data_Vector_Grad=[]; else, fns=fieldnames(vec_grad_structs); for f=1:length(fns), Data_Vector_Grad.(fns{f})=vertcat(vec_grad_structs.(fns{f})); end; end
if isempty(sca_grad_structs), Data_Scalar_Grad=[]; else, fns=fieldnames(sca_grad_structs); for f=1:length(fns), Data_Scalar_Grad.(fns{f})=vertcat(sca_grad_structs.(fns{f})); end; end

% [保存] 文件名改为 CryoSat
save('CryoSat_Input_Gradient_Weighted.mat', 'Data_Vector_Grad', 'Data_Scalar_Grad');
fprintf('   CryoSat 单星梯度计算完成。\n');

%% ------------------- 10. (新增) 保存绘图专用数据 -------------------
disp('10. 正在打包绘图数据...');

% 1. 还原全局掩膜 (Reconstruct Global Mask)
% 逻辑：mask_pre_calc 是全量数据的筛选结果，mask_final_sub 是基于前者子集的筛选结果
mask_final_global = false(size(all_data, 1), 1);
idx_stage1 = find(mask_pre_calc);               % 第一步通过的索引
idx_final_global = idx_stage1(mask_final_sub);  % 最终保留的数据在全局中的索引
mask_final_global(idx_final_global) = true;

% 2. 提取必要列以减小文件体积
% 只保存：时间(7), B_NEC(4:6), 卫星ID(9), 以及筛选标记
PlotData = struct();
PlotData.Time_DN = all_data(:, 7);      % datenum格式时间
PlotData.B_NEC   = all_data(:, 4:6);    % NEC 原始磁场 (未减去CHAOS)
PlotData.Sat_ID  = all_data(:, 9);      % 卫星ID
PlotData.Mask_Selected = mask_final_global; % 逻辑索引 (True=筛选后保留)

% 3. 保存为 MAT 文件
save_name = 'CS2_Plotting_Data.mat';
save(save_name, 'PlotData', '-v7.3'); % v7.3 支持大文件
fprintf('   绘图数据已保存至: %s (可直接用于独立绘图脚本)\n', save_name);
disp('全部流程执行完毕。');

toc;