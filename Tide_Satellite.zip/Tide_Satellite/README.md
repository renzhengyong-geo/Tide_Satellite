# Satellite — Multi-Mission Magnetic Data Processing & M2 Tidal Inversion

> This directory covers the **complete pipeline** from **data ingestion → single-satellite preprocessing (downsampling, quality control, CHAOS removal, environmental screening, along-track gradient) → multi-satellite joint inversion → publication-grade visualization** for M2 tidal magnetic signal extraction.
> Missions involved: CHAMP, Swarm A/B/C (Alpha/Bravo/Charlie), GRACE-FO GF1/GF2, CryoSat-2, MSS-1 (Macau Science Satellite-1), Ørsted, SAC-C.

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Data Download (Python)](#2-data-download-python)
3. [Single-File Processing Engine (MATLAB)](#3-single-file-processing-engine-matlab)
4. [Single-Satellite Preprocessing (MATLAB)](#4-single-satellite-preprocessing-matlab)
5. [Multi-Satellite Joint Inversion (MATLAB)](#5-multi-satellite-joint-inversion-matlab)
6. [Core Utilities (MATLAB)](#6-core-utilities-matlab)
7. [Visualization Tools (MATLAB)](#7-visualization-tools-matlab)
8. [Comprehensive Plotting (Publication-Grade)](#8-comprehensive-plotting-publication-grade)
9. [Appendix](#9-appendix)

---

## 1. Architecture Overview

```
┌─ Data Download (Python) ──────────────────────────────────────────┐
│  APIgetSwarm_raw_Data/    ← Swarm A/B/C MAGx_LR (ESA swarm-diss)  │
│  APIgetGraceFO_raw_Data/  ← GRACE-FO GF1/GF2 (ISDC GFZ)            │
│  APIgetCryosat_raw_Data/  ← CryoSat-2 (ESA swarm-diss)             │
│  APIgetKp/                ← Kp / Hp30 indices (GFZ Potsdam API)    │
│  calculate_em.py          ← OMNI solar wind params (Em / Bz / By)  │
└──────────────────────────────────────────────────────────────────-┘
    │
    ▼
┌─ Single-File Processing Engine (process_single_cdf_file_*.m) ────┐
│  Mission-specific CDF reader + QC + 15s bin averaging              │
│  * CHAMP / Swarm / CryoSat / MSS / gracefo / orsted / SAC_C       │
└──────────────────────────────────────────────────────────────────-┘
    │
    ▼
┌─ Single-Satellite Preprocessing (sTep1_PreProcess_*.m) ──────────┐
│  Batch CDF scan → call processing engine → QD latitude            │
│  → CHAOS core-field subtraction → RC/Hp30/Em filtering            │
│  → Night-side selection → along-track gradient → MAT output       │
│  * Swarm / CHAMP / CS2 / MSS / SAC_C / Orsted / GraceFO(v6)      │
└───────────────────────────────────────────────────────────────────┘
    │
    ▼
┌─ Multi-Satellite Joint Inversion (sTep2_ALL_Satellite_inversion_v2.m) ──┐
│  IRLS (Huber weighting) + satellite-specific params + block-wise │
│  parallel computation + regularization                            │
│  Output: Spherical Harmonic (SH) Coefficients → SH_coefficients_*.txt│
└───────────────────────────────────────────────────────────────────┘
    │
    ▼
┌─ Core Utilities (MATLAB) ────────────────────────────────────────┐
│  build_K_matrix_paper.m  ← SH design matrix                       │
│  calculate_QD_Lat.m      ← Quasi-Dipole latitude                  │
│  sunGEI.m                ← Sun GEI coordinates & Greenwich Sidereal│
└───────────────────────────────────────────────────────────────────┘
    │
    ▼
┌─ Visualization (MATLAB) ─────────────────────────────────────────┐
│  MSS_oribit.m              ← Swarm/MSS orbit ground tracks        │
│  ComprehensivePlots/ (25 scripts) ← publication-grade figures     │
└───────────────────────────────────────────────────────────────────┘
```

---

## 2. Data Download (Python)

### 2.1 Swarm A/B/C — `APIgetSwarm_raw_Data/swarm_data_downloader.py`

Downloads Swarm Level 1b MAGx_LR data (CDF ZIP format) from ESA swarm-diss.

| Item | Description |
|------|-------------|
| Source | `https://swarm-diss.eo.esa.int/swarm/Level1b/Entire_mission_data/MAGx_LR/Sat_{A,B,C}/` |
| Output | `Satellite_Data/Swarm/2025latest/{A,B,C}/` |
| Naming | `SW_OPER_MAG{A,B,C}_LR_1B_YYYYMMDDT*_YYYYMMDDT*_0701.CDF.ZIP` |
| Fallback | 0701 first, 0702 on failure |
| Parallel | `ThreadPoolExecutor(max_workers=5)` |
| Options | `--start-date` (default `2025-03-01`), `--end-date` (default today) |

### 2.2 GRACE-FO GF1/GF2 — `APIgetGraceFO_raw_data/gracefo_data_downloader.py`

Downloads GRACE-FO magnetometer data (FGM ACAL CORR calibrated) from ISDC GFZ.

| Item | Description |
|------|-------------|
| Source | `https://isdc-data.gfz.de/grace-fo/MAGNETIC_FIELD/0201/GF{1,2}/ACAL_CORR/` |
| Output | `Satellite_Data/GRACEFO/GF1/`, `GF2/` |
| Format | `GF{1,2}_OPER_FGM_ACAL_CORR_*.cdf` |
| Options | `--start-date` (default `2025-05-01`), `--end-date` (default today) |

### 2.3 CryoSat-2 — `APIgetCryosat_raw_data/cryosat_data_downloader.py`

Hybrid downloader: FTP listing then HTTPS download (firewall-friendly).

| Item | Description |
|------|-------------|
| Source | FTP/HTTPS → `swarm-diss.eo.esa.int/Multimission/CryoSat-2/{year}/` |
| Output | `Satellite_Data/CryoSat/` |
| Format | `CS_OPER_MAG_*.cdf` |
| Auth | Requires ESA username/password (hardcoded; update before use) |
| Options | Edit `START_DATE`, `END_DATE`, `SAVE_DIR` in script directly |

### 2.4 Geomagnetic Indices — `APIgetKp/`

| Script | Content | Source | Output |
|--------|---------|--------|--------|
| `getKpindex.py` | Generic GFZ API client (Kp/ap/Ap/Cp/C9/Hp30/Hp60 etc.) | `kp.gfz-potsdam.de` | — (library) |
| `fetch_kp.py` | Kp index (2018–2025) | same | `kp_data_for_gracefo.csv` |
| `fetch_hp30.py` | Hp30 index (1964–2025) | same | `hp30_data_*.csv` |

### 2.5 CDF Integrity Check — `check_cdf_integrity.py`

| File | Target |
|------|--------|
| `APIgetCryosat_raw_data/check_cdf_integrity.py` | CryoSat-2 CDF integrity |
| `APIgetGraceFO_raw_data/check_cdf_integrity.py` | GRACE-FO CDF integrity |

Uses `spacepy.pycdf` to open each CDF file and read the first 10 records. Corrupted files are logged in `corrupt_files.txt`.

### 2.6 OMNI Solar Wind Parameters — `calculate_em.py`

Reads OMNI high-resolution (1-min / 5-min) solar wind data, computes the Newell coupling parameter Em, and outputs 2-hour moving averages.

| Item | Description |
|------|-------------|
| Input | `Omni_raw_Data_HR/*.dat` / `*.txt` |
| Output | `omni_min_em_bz_2h_avg.csv` |
| Em formula | `Em = 0.33 × V^(4/3) × Bt^(2/3) × sin⁸/³(|θ|/2) × 10⁻³` |
| Window | 120 minutes (two-pointer sliding) |
| Columns | `datetime, em, by_gsm, bz_gsm, avg_em_2h, avg_by_2h, avg_bz_2h` |

---

## 3. Single-File Processing Engine (MATLAB)

**7 dedicated functions**, one per mission (or mission group). All share the same work flow:

1. **CDF reading**: `cdfread` or `cdfinfo`, variables matched to mission data handbooks  
2. **Quality control**: hardware flags (FGM/ASM/attitude) to retain only high-quality data  
3. **Bin averaging**: average over 15 s windows — avoids Gibbs oscillations from low-pass filters  
4. **Longitude fix**: trigonometric mean via `atan2(sin, cos)` to handle ±180° wraps  
5. **Std output**: within-bin standard deviation for weighted least-squares inversion  

Uniform output (9-column matrix):

```
[Lat(°), Lon(°), Rad(km), B_N(nT), B_E(nT), B_C(nT), Time(datenum), F(nT), F_Std(nT)]
```

> **Note**: Scalar-only missions (Ørsted, SAC-C) output NaN for the B_N/E/C columns.

### 3.1 `process_single_cdf_file_CHAMP.m`

| Item | Description |
|------|-------------|
| Variables | `EPOCH`, `GEO_LAT`, `GEO_LON`, `GEO_ALT`, `GEO_STAT`, `FGM_SCAL`, `NEC_VEC`, `FGM_FLAGS`, `ASC_STAT` |
| QC | (1) `GEO_STAT == [0,20,0]` (2) FGM_FLAGS bit2-3=0, bit4=0 (3) ASC_STAT ten-thousands digit = 7 |
| Binning | 15 s window, ≥10 points per bin |
| Radius | `alt + 6371.2` (km) |

### 3.2 `process_single_cdf_file_Swarm.m`

| Item | Description |
|------|-------------|
| Variables | `Timestamp`, `Latitude`, `Longitude`, `Radius`, `F`, `B_NEC`, `Flags_F`, `Flags_B`, `Flags_q`, `Flags_Platform` |
| QC | (A/B) `Flags_B ≤ 1, Flags_F ≤ 1, Flags_q < 30`; (C) `Flags_B ≤ 30` (relaxed for Swarm C ASM-VFM discrepancy) |
| Binning | 60 s window, ≥10 points per bin |
| Scalar fill | Missing F filled with `|B_NEC|` |

### 3.3 `process_single_cdf_file_CryoSat.m`

Robust version auto-adapting to multiple CDF format revisions.

| Item | Description |
|------|-------------|
| Variables | Auto-detects `B_NEC` / `B_NEC1` / `M1_B_NEC`; computes F manually if not in file |
| QC | `q_error < 40″`, `6500 < r < 7500` km, `10000 < F < 75000` nT |
| Binning | 60 s window, ≥1 point per bin |
| Highlight | Dynamic variable-name detection — compatible across versions |

### 3.4 `process_single_cdf_file_MSS.m`

Designed for MSS-1 (Macau Science Satellite-1) Level 2 LR VFM data.

| Item | Description |
|------|-------------|
| Variables | `Timestamp`, `Latitude`, `Longitude`, `Radius`, `F`, `B_NEC`, `flag_B`, `flag_q` |
| QC | `flag_B ≤ 1` (reject Outlier/PosFault); `flag_q < 20″` (attitude threshold, ref. MSS handbook §6.4-260) |
| Binning | 15 s window, ≥10 points per bin |
| Remark | Attitude thresholds: <10″ (strict), **<20″ (recommended)**, <60″ (loose) |

### 3.5 `process_single_cdf_file_gracefo.m` & `process_single_cdf_file_orsted.m`

Both files share the same function body (branching logic), handling GRACE-FO and Ørsted.

**GRACE-FO branch**:

| Item | Description |
|------|-------------|
| Variables | `Timestamp`, `Latitude`, `Longitude`, `Radius`, `B_NEC`, `B_FGM`, `B_FLAG` |
| Downsampling | **Direct decimation** (no bin averaging), step `data_step` (recommended 15 s) |
| QC | `B_FLAG == 0`, scalar > 1000 nT |
| Radius | auto m→km conversion |

**Ørsted branch**:

| Item | Description |
|------|-------------|
| Variables | `Theta`, `Phi`, `R`, `B`, `T`, `F`, `Day`, `Qf`, `Qb` |
| Downsampling | Same direct decimation |
| Coords | Theta colatitude → latitude; Time = 2000-01-01 + Day + sec/86400 |
| QC | `Qf+Qb == 0` (clean quality flags) |

### 3.6 `process_single_cdf_file_SAC_C.m`

| Item | Description |
|------|-------------|
| Variables | `theta`, `phi`, `r`, `t`, `F` (scalar-only, no vector B) |
| Downsampling | 15 s bin averaging; output `B_NEC` columns are all NaN |
| Time | MJD2000 → datenum |
| QC | `F > 1000` nT, NaN removed |

---

## 4. Single-Satellite Preprocessing (MATLAB)

**7 main preprocessing scripts**, one per mission (or family). All follow the same architecture:

```
Step 0: Initialize parallel pool (parpool, max_workers=6)
Step 1: Configure parameters (data path, binning window, sampling control)
Step 2: Load auxiliary data (OMNI Em/Bz/By, Hp30, RC Index)
Step 3: Scan/read → call process_single_cdf_file_* → 15 s downsampling
Step 4: Environmental screening (Night, Hp30, OMNI, RC)
Step 5: Subtract CHAOS-8.4 core field model
Step 6: Compute along-track gradient (15 s forward difference → dF/dt)
Step 7: Save MAT file(s) + diagnostic plots
```

### 4.1 `sTep1_PreProcess_Swarm.m` — Swarm A/B/C (v13)

**Core**: single-path recursive scan → auto-classify MAGA/MAGB/MAGC → pair A and C for cross-track gradient.

| Item | Description |
|------|-------------|
| Data path | `Satellite_Data/Swarm/` |
| Binning | 60 s (read-time downsampling) |
| Aux data | OMNI (Em/Bz/By) + Hp30 + RC Index |
| Core field | CHAOS-8.4 (`CHALLENGE_MF_0409.mat`) |
| Gradient | 15 s forward diff → `dF/dt` + Swarm A/C cross-track difference |
| Filters | Night (zenith>100°) + Quiet (Hp30≤2.0, |Bz|>2, |By|<5) + RC derivative rejection |
| Output | `Swarm_Input_Weighted.mat` / `Swarm_Gradient_Weighted.mat` |
| Diagnostic | Residual distribution, data count before/after filtering |

**A/C cross-track pairing algorithm**:
- After 15 s downsampling, apply a 50 s sliding window to Swarm A and C
- Within each window, find the pair with minimum latitude difference
- Output inter-satellite differential field (removes common-mode non-tidal noise)

### 4.2 `sTep1_PreProcess_CHAMP.m` — CHAMP (v2.1)

| Item | Description |
|------|-------------|
| Data path | `Satellite_Data/CHAMP/` |
| Binning | 15 s |
| QC | Triple hardware flag screening (GEO_STAT + FGM_FLAGS + ASC_STAT, see §3.1) |
| Sampling | Supports day-level random sampling (`ENABLE_RANDOM_SAMPLING` + `RANDOM_SAMPLE_RATIO`) |
| Output | `CHAMP_Input_Vector.mat` / `CHAMP_Scalar.mat` + along-track gradient |

### 4.3 `sTep1_PreProcess_CS2.m` — CryoSat-2

| Item | Description |
|------|-------------|
| Data path | `Satellite_Data/CryoSat/` |
| Binning | 60 s |
| Output type | Single-satellite along-track gradient only (scalar + vector) |
| Sat ID | `SAT_ID_CRYOSAT = 90` |

### 4.4 `sTep1_PreProcess_MSS.m` — MSS-1 (Macau Science Satellite-1)

| Item | Description |
|------|-------------|
| Data path | `Satellite_Data/MSS_v07xx/` |
| Binning | 15 s |
| Feature | Low-inclination (~41°) optimized; attitude threshold `flag_q < 20″` |
| Output | `MSS_Input_Vector.mat` / `MSS_Scalar.mat` + along-track gradient |

### 4.5 `sTep1_PreProcess_SAC_C.m` — SAC-C

| Item | Description |
|------|-------------|
| Data path | `Satellite_Data/SAC-C/` |
| Feature | **Scalar-only** (shares the downsampling engine `process_single_cdf_file` with Ørsted), 1 Hz → 15 s |
| Output type | Scalar residual dF + along-track scalar gradient dF_grad |
| Latitude | Full coverage (no QD Lat truncation) |

### 4.6 `sTep1_Orsted_PreProcess.m` — Ørsted

| Item | Description |
|------|-------------|
| Data path | `Satellite_Data/Oersted/` |
| Feature | **Scalar-only** (output dF + dF_grad), Theta/Phi/R coordinate format |
| Filters | Night + RC + Hp30 + OMNI (By/Bz) |

### 4.7 `sTep1_Combined_GraceFO_PreProcess_v6.m` — GRACE-FO (v6 inter-satellite gradient)

The most complex preprocessing script, handling the GRACE-FO dual-satellite (GF1/GF2) pursuit formation.

| Item | Description |
|------|-------------|
| Data path | `Satellite_Data/GRACEFO/GF1/` + `GF2/` |
| Binning | 15 s (single-satellite) → **30 s resampling** (inter-satellite gradient matching) |
| Core algorithm | Date synchronization → GF1/GF2 joint pairing → 30 s dual-satellite gradient |
| Aux data | Em/Bz/By, Hp30, RC Index |
| Output | `GraceFO_Gradient_Weighted.mat` / `GraceFO_Scalar.mat` |

---

## 5. Multi-Satellite Joint Inversion (MATLAB)

### `sTep2_ALL_Satellite_inversion_v2.m` — Unified Inversion Framework

Merges all preprocessed MAT files and performs IRLS (Iteratively Reweighted Least Squares) spherical harmonic inversion.

| Item | Description |
|------|-------------|
| **Model** | `N_max = 32`, `period_tidal = 12.42060122 h` |
| **Method** | IRLS + Huber weighting (per-satellite Huber constant) |
| **Satellite config** | See table §5.1 |
| **Block processing** | `BLOCK_SIZE = 15000`, `parfor` (30 workers) |
| **Regularization** | Degree-dependent Tikhonov: `λ · diag([n(n+1)]²)`; n=1 penalty = 110000 |
| **Night filter** | `sunGEI` zenith > 100° |
| **QD filter** | `|QD_Lat| > 6°` (exclude equatorial electrojet) |
| **Output** | SH coefficient TXT: `SH_coefficients_*.txt` (n, m, Real, Imag, Error) |

#### 5.1 Satellite Weight Configuration

| Satellite | `SigAbs` (nT) | `SigGrad` (nT) | `Scale` | `HuberK` | Notes |
|-----------|:---:|:---:|:---:|:---:|-------|
| **Swarm A/B/C** | 2.2 | 0.4 | 1.0 | 1.5 | Gold standard, highest weight |
| **CHAMP** | 2.5 | 0.4 | 1.0 | 1.5 | Critical for early-epoch constraint |
| **MSS-1** | 2.2 | 0.4 | 1.0 | 0.5 | Low-inclination complement |
| **Ørsted** | 2.5 | 0.4 | **0.1** | 1.345 | Scalar-only, low weight |
| **SAC-C** | 2.5 | 0.4 | **0.1** | 1.345 | Scalar-only, low weight |
| **CryoSat-2** | 6.0 | 3.0 | **0.1** | 1.5 | High noise, spatial filler |
| **GRACE-FO** | 10.0 | 4.0 | **0.01** | 0.6 | Inter-satellite gradient, extremely low weight |

#### 5.2 Inversion Workflow

```
1. Scan *_Weighted.mat / *_Scalar.mat / *_Input_*.mat
2. Identify satellite from filename → match SAT_DB config
3. Call standardize_data_fixed for outlier rejection (Abs>5 nT, Grad>2 nT)
4. Split into blocks (BLOCK_SIZE = 15000)
5. Build K matrix (get_K_block)
6. IRLS iteration (MAX_ITER = 80):
   a. Compute residuals
   b. compute_table3_sigma (physical sigma + geometric weight)
   c. Huber weighting (satellite-specific k)
   d. Update normal equations → conjugate-gradient solve
7. Output SH coefficients
```

---

## 6. Core Utilities (MATLAB)

### 6.1 `build_K_matrix_paper.m` — Spherical Harmonic Design Matrix

Maps SH coefficients to the three magnetic-field components (radial Br, polar Bθ, azimuthal Bφ). Corresponds to paper equations 2-15 through 2-17.

```
Input:  Pos [r(km), θ(°), φ(°)]  (n_pts × 3)
        cos_t, sin_t              tidal-time cosine/sine column vectors
        N_max                     maximum spherical harmonic degree
        a                         Earth reference radius (km)
Output: K_r, K_t, K_p             design matrices (n_pts × N_params)
```

**Technical details**:
- Legendre derivative `dP/dθ`: finite difference (`Δ = 1e-4°`, second-order central)
- Pole protection: `sinθ < 1e-10` → clamped to 1e-10
- Each `(n, m)` produces 2 columns (cos real + sin imag) + 2 columns `h_nm` when `m>0`
- Total columns `N_params = N_max × (N_max + 2) × 2`

### 6.2 `calculate_QD_Lat.m` — Quasi-Dipole Latitude

Computes the local quasi-dipole (QD) latitude from the geomagnetic field vector and satellite position, used for equatorial electrojet exclusion.

| Input | `B_vec (N×3)`, `r_sat` (km), `Re = 6371.2` km |
| Output | `QD_Lat` (°), derived from magnetic inclination I |
| Note | Bug fix applied: older L-shell mapping caused data gaps near the dip equator |

### 6.3 `sunGEI.m` — Sun Position & Greenwich Sidereal Time

| Input | `md2000` — MJD2000 time (scalar or vector) |
| Output | `S` — 3-D sun direction unit vector; `GST` — Greenwich Sidereal Time (rad) |
| Validity | 1901–2099 |
| Uses | Night-side screening (zenith angle), coordinate transformations |

---

## 7. Visualization Tools (MATLAB)

### 7.1 `MSS_oribit.m` — Raw Orbit Ground Tracks

Reads a small set of Swarm-A and MSS-1 CDF files and plots continuous orbit arcs in Robinson projection.

| Input | Local CDF files (paths hardcoded; adjust as needed) |
| Output | `Raw_Orbit_Distribution.png` (600 dpi) |

---

## 8. Comprehensive Plotting (Publication-Grade)

`ComprehensivePlots/` contains **25 scripts** for multi-mission diagnostics and publication-grade figures, organized into functional groups:

### 8.1 Thesis Final Figures

| Script | Description |
|--------|-------------|
| `Thesis_Plot_Final_v11_A4_Standard.m` | 7-sat × 4-component spatial distribution (A4 format) |
| `Thesis_Plot_Final_v12_A4_Standard.m` | v11 upgrade (tweaked parameters) |
| `Thesis_Plot_Final_v8_LayoutOptimized.m` | Layout-optimized (early version) |
| `Thesis_Plot_PPT_16x9.m` | 16:9 presentation version (slide-friendly colors) |

### 8.2 Power Spectrum & Correlation Analysis

| Script | Description |
|--------|-------------|
| `Analysis_Power_Spectrum_Layers.m` | Multi-layer power spectral analysis |
| `Plot_Power_Spectrum_Layout_Adjusted.m` | 8-sat/model power spectrum comparison + zoomed inset |
| `Plot_Spectrum_and_Correlation_Comparison.m` | Spectrum + degree-wise correlation (Ours vs external models) |
| `Plot_Spectrum_and_Correlation_Comparison_N2.m` | Same for N2 tidal constituent |
| `Plot_Spectrum_and_Correlation_Comparison_N2_mat.m` | N2 comparison (MAT file format version) |
| `Plot_Spectrum_and_Correlation_Comparison_O1.m` | Same for O1 tidal constituent |

### 8.3 Multi-Mission Diagnostics

| Script | Description |
|--------|-------------|
| `Plot_All_Satellites_Full_Diagnostics.m` | 7-sat residual diagnostics summary panel |
| `plot_mission_dashboard_V13_SplitHist.m` | Multi-mission dashboard + split histograms |
| `plot_orbit_geometry_v8.m` | 3-D satellite orbit geometry visualization |
| `Plot_Datanum_Circle.m` | Data-volume distribution circle plot |

### 8.4 SH Coefficient Comparison

| Script | Description |
|--------|-------------|
| `Plot_SH_From_CSV.m` | Load and plot SH coefficients from CSV |
| `Plot_Normalized_Coefficient_Differences_v0312.m` | Normalized coefficient-difference triangle plot |
| `Plot_N2_Coefficient_Differences_Thesis.m` | N2 coefficient differences |
| `Plot_Correlation_Dual_Panels.m` | Dual-panel correlation heatmap |
| `Plot_Correlation_Dual_Panels_Thesis_N2.m` | N2 dual-panel |
| `Plot_Correlation_M2_Thesis_Final.m` | M2 correlation thesis final version |

### 8.5 Multi-Satellite vs Forward Model

| Script | Description |
|--------|-------------|
| `Plot_Multisat_vs_Forward_Thesis.m` | Multi-satellite joint inversion vs forward model |
| `Plot_Multisat_vs_Forward_Thesis_N2.m` | N2 vs forward |
| `Plot_MSS_Forward_Comparison_Individual.m` | MSS-1 component-wise vs forward |

### 8.6 Utilities & Auxiliary

| Script | Description |
|--------|-------------|
| `convert_sh_csv_to_txt.m` | SH coefficient CSV → regular-grid TXT + plot validation |
| `build_K_matrix_paper.m` | Copy of the root-level design matrix builder |
| `calculate_QD_Lat.m` | Copy of QD latitude function |
| `sunGEI.m` | Copy of sun position function |
| `inspect_mat_files.m` | MAT file structure inspector |
| `load_spa_constants.m` | Load SPA astronomical constants |
| `spa1.m` / `spa_const.m` | NREL SPA solar position algorithm (for precise zenith) |

---

## 9. Appendix

### 9.1 Recommended Execution Order

```
Step 0 — Data download (run once, incremental afterward)
  │
  ├─ APIgetSwarm_raw_Data/swarm_data_downloader.py
  ├─ APIgetGraceFO_raw_data/gracefo_data_downloader.py
  ├─ APIgetCryosat_raw_data/cryosat_data_downloader.py
  ├─ APIgetKp/fetch_kp.py + fetch_hp30.py
  └─ calculate_em.py

Step 1 — Auxiliary data (skip if pre-stored files exist)
  └─ omni_min_em_bz_2h_avg.csv, hp30_data_*.csv, RC_*.dat

Step 2 — Single-satellite preprocessing (mutually independent, can run in parallel)
  │
  ├─ sTep1_PreProcess_CHAMP.m        → CHAMP input mat
  ├─ sTep1_PreProcess_Swarm.m        → Swarm input mat (+ A/C Diff)
  ├─ sTep1_Combined_GraceFO_PreProcess_v6.m  → GraceFO mat (+ inter-sat gradient)
  ├─ sTep1_PreProcess_CS2.m          → CryoSat mat
  ├─ sTep1_PreProcess_MSS.m          → MSS mat
  ├─ sTep1_Orsted_PreProcess.m       → Ørsted mat
  └─ sTep1_PreProcess_SAC_C.m        → SAC-C mat

Step 3 — Multi-satellite joint inversion
  └─ sTep2_ALL_Satellite_inversion_v2.m  → SH_coefficients_*.txt

Step 4 — Visualization (depends on Step 2–3 outputs)
  ├─ MSS_oribit.m                    → orbit-track check
  └─ ComprehensivePlots/*.m           → publication-grade figures
```

### 9.2 Auxiliary Data Files

| File | Purpose | Source |
|------|---------|--------|
| `omni_min_em_bz_2h_avg.csv` | OMNI solar wind (Em/Bz/By) | Generated by `calculate_em.py` |
| `hp30_data_*.csv` | Hp30 geomagnetic index | Generated by `fetch_hp30.py` |
| `kp_data_for_gracefo.csv` | Kp index | Generated by `fetch_kp.py` |
| `RC_*.dat` | RC ring-current index | External (GFZ) |
| `CHALLENGE_MF_0409.mat` / `CHAOS-8.4.mat` | CHAOS-8.4 core field model | External (DTU Space) |
| `CHALLENGE_CHAOS_shc.txt` | CHAOS SH coefficient text file | External |

> **Path convention**: All auxiliary files above are expected under the directory specified by `AUX_DATA_PATH` in each `sTep1_*.m` script (typically `../`, i.e., the project root). Each preprocessing script checks for these files on startup and errors out if they are missing.

### 9.3 Required Toolboxes

- **MATLAB R2020b+** — base platform
- **Parallel Computing Toolbox** — `parpool` / `parfor` (used by all sTep1 and sTep2)
- **Statistics and Machine Learning Toolbox** — `robustfit` (Huber weighting in inversion)
- **M_Map** (third-party) — `m_proj`, `m_pcolor`, `m_coast` (global projection plots)
- **CDF/PAC Toolbox** or MATLAB `cdfread` — CDF file I/O

### 9.4 Mission Parameters Summary

| Satellite | Span | Inclination | Data type | N_max | Bin interval | Special handling |
|-----------|------|:-----------:|-----------|:-----:|:------------:|------------------|
| **CHAMP** | 2000–2010 | 87.3° | Vector + scalar | 15 | 15 s | Triple hardware flags + ASC |
| **Swarm A/B/C** | 2013–present | 87.4° | Vector + scalar | 15 | 60 s | A/C cross-track difference |
| **GRACE-FO** | 2018–present | 89.0° | Vector + scalar | 28 | 15 s→30 s | GF1–GF2 inter-satellite gradient |
| **MSS-1** | 2023–present | 41.0° | Vector + scalar | 15 | 15 s | Low inclination + arcsec attitude |
| **CryoSat-2** | 2010–present | 92.0° | Vector + scalar | 15 | 60 s | Auto variable-name detection |
| **Ørsted** | 1999–2013 | 96.5° | **Scalar only** | 10 | 15 s | Qf/Qpos flag fusion |
| **SAC-C** | 2000–2007 | 98.0° | **Scalar only** | 8 | 15 s | MJD2000 time, Theta/Phi coords |

### 9.5 Output Products

| Product | Format | Description |
|---------|--------|-------------|
| `{Satellite}_Input_Vector.mat` | MAT | Vector data (B_NEC, residual, along-track gradient) |
| `{Satellite}_Scalar.mat` | MAT | Scalar data (F, residual, scalar gradient) |
| `{Satellite}_Gradient_Weighted.mat` | MAT | Inter-satellite gradient (Swarm A/C, GRACE-FO) |
| `{Satellite}_Input_Weighted.mat` | MAT | Weighted input (incl. std column for inversion weighting) |
| `SH_coefficients_M2_*.txt` | TXT | SH coefficients (n, m, Real_cos, Imag_sin, Error) |
| `*.pdf / *.png` | Figure | Diagnostic + thesis figures (in ComprehensivePlots/) |

### 9.6 Frequently Asked Questions

**Q: CDF read error "Variable not found"**
A: Variable names differ across data versions. The CryoSat script auto-detects (`B_NEC`/`B_NEC1`/`M1_B_NEC`). For other missions, check `cdfinfo` output and update `target_vars`.

**Q: Preprocessing script says "File missing: omni_min_em_bz_2h_avg.csv"**
A: Run `calculate_em.py` first, or update `AUX_DATA_PATH` in the script to point to the correct auxiliary data directory.

**Q: sTep2 inversion does not converge**
A: Check the `lambda_base` parameter (default `2e-3`). Increase to `2.0` if the solution oscillates; decrease to `1e-4` if over-regularized.

**Q: Swarm A/C cross-track pairing fails**
A: Ensure GF1/GF2 directories contain files for the same dates. The GraceFO script includes date-synchronization logic; the Swarm script relies on the `MAGA`/`MAGB`/`MAGC` filename identifier.

---

> **Document version**: 2026 · **Scope**: All files in the Satellite directory (including the full preprocessing and inversion pipeline)
