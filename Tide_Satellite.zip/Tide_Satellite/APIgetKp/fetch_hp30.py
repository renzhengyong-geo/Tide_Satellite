# fetch_hp30.py
# -------------------------
# 用于调用 getKpindex 函数获取 Hp30 指数并保存结果的脚本

from getKpindex import getKpindex
from datetime import datetime
import pandas as pd

def main():
    """
    主函数，用于设置参数、获取 Hp30 数据并保存。
    """
    # --- 1. 设置参数 ---
    start_date = '1964-01-01'
    end_date   = '2025-09-30'
    index_name = 'Hp30'  # 获取 Hp30 指数
    output_filename = 'hp30_data_19640101_20250930.csv'
    
    print(f"正在从 GFZ API 获取 {start_date} 到 {end_date} 的 {index_name} 指数...")
    
    # --- 2. 调用 API 函数 ---
    try:
        # 只关心时间和 Hp30 值，第三个返回值 (status) 可以忽略，因为 Hp30 没有状态信息
        hp30_time_str, hp30_values, _ = getKpindex(start_date, end_date, index_name)
        
        if hp30_time_str == 0:
            print("未能获取到数据，请检查网络或 API 状态。")
            return

        # --- 3. 格式化并保存数据 ---
        # 将返回的字符串时间元组转换为 datetime 对象
        hp30_time_utc = [datetime.strptime(t, '%Y-%m-%dT%H:%M:%SZ') for t in hp30_time_str]
        
        df = pd.DataFrame({
            'Timestamp_UTC': hp30_time_utc,
            'Hp30_Value': list(hp30_values)
        })
        
        # 将 DataFrame 保存为 CSV 文件，不包含索引列
        df.to_csv(output_filename, index=False, date_format='%Y-%m-%d %H:%M:%S')
        
        print(f"数据成功获取并保存到文件: {output_filename}")
        
    except Exception as e:
        print(f"在获取或处理数据时发生错误: {e}")


if __name__ == "__main__":
    main()