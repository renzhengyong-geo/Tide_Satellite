# fetch_kp.py
# -------------------------
# 用于调用 getKpindex 函数并保存结果的脚本

from getKpindex import getKpindex
from datetime import datetime
import pandas as pd

def main():
    """
    主函数，用于设置参数、获取数据并保存。
    """
    # --- 1. 设置参数 ---
    start_date = '2018-01-01'
    end_date   = '2025-09-30'
    index_name = 'Kp'
    output_filename = 'kp_data_for_gracefo.csv'
    
    print(f"正在从 GFZ API 获取 {start_date} 到 {end_date} 的 {index_name} 指数...")
    
    # --- 2. 调用 API 函数 ---
    try:
        # 只关心时间和 Kp 值，第三个返回值 (status) 可以忽略
        kp_time_str, kp_values, _ = getKpindex(start_date, end_date, index_name, 'def')
        
        if kp_time_str == 0:
            print("未能获取到数据，请检查网络或 API 状态。")
            return

        # --- 3. 格式化并保存数据 ---
        # 将返回的字符串时间元组转换为 datetime 对象
        kp_time_utc = [datetime.strptime(t, '%Y-%m-%dT%H:%M:%SZ') for t in kp_time_str]
        
        df = pd.DataFrame({
            'Timestamp_UTC': kp_time_utc,
            'Kp_Value': list(kp_values)
        })
        
        # 将 DataFrame 保存为 CSV 文件，不包含索引列
        df.to_csv(output_filename, index=False, date_format='%Y-%m-%d %H:%M:%S')
        
        print(f"数据成功获取并保存到文件: {output_filename}")
        
    except Exception as e:
        print(f"在获取或处理数据时发生错误: {e}")


if __name__ == "__main__":
    main()