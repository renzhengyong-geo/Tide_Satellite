import os
import re
import logging
import requests
from datetime import datetime
from ftplib import FTP_TLS
import getpass
from tqdm import tqdm
import time

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('cryosat_hybrid_download.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('CryoSatHybrid')

class CryoSatHybridDownloader:
    def __init__(self, save_path, username, password):
        self.ftp_host = "swarm-diss.eo.esa.int"
        # HTTP 下载的基础 URL (对应 FTP 的 /Multimission/...)
        self.http_base_url = "https://swarm-diss.eo.esa.int/swarm/Multimission/CryoSat-2"
        
        self.save_path = save_path
        self.username = username
        self.password = password
        
        # FTP 上的路径
        self.ftp_target_dir = "/Multimission/CryoSat-2"
        
        self.filename_pattern = re.compile(r'CS_OPER_MAG_(\d{8}T\d{6})_(\d{8}T\d{6})_(\d{4})\.(cdf|zip|nc)', re.IGNORECASE)

    def get_file_list_via_ftp(self, year, start_date, end_date):
        """步骤 1: 使用 FTP 获取准确的文件名列表"""
        files_to_download = []
        ftps = None
        try:
            logger.info(f"Connecting to FTP ({self.ftp_host}) to list files...")
            ftps = FTP_TLS(timeout=60)
            ftps.connect(self.ftp_host, 21)
            ftps.auth()
            ftps.prot_p()
            ftps.login(self.username, self.password)
            
            year_dir = f"{self.ftp_target_dir}/{year}"
            logger.info(f"Listing directory: {year_dir}")
            ftps.cwd(year_dir)
            filenames = ftps.nlst()
            
            logger.info(f"Scanning {len(filenames)} files...")
            for filename in filenames:
                match = self.filename_pattern.search(filename)
                if match:
                    start_str = match.group(1)
                    try:
                        file_date = datetime.strptime(start_str, "%Y%m%dT%H%M%S")
                        if start_date <= file_date <= end_date:
                            files_to_download.append(filename)
                    except ValueError:
                        continue
            return files_to_download
            
        except Exception as e:
            logger.error(f"FTP Listing failed: {e}")
            return []
        finally:
            if ftps:
                try:
                    ftps.quit()
                except:
                    pass

    def download_file_via_https(self, filename, year):
        """步骤 2: 使用 HTTPS 下载文件 (防火墙友好)"""
        # 构建 URL: https://swarm-diss.eo.esa.int/swarm/Multimission/CryoSat-2/2025/filename
        url = f"{self.http_base_url}/{year}/{filename}"
        local_path = os.path.join(self.save_path, filename)
        
        # 检查是否已存在
        if os.path.exists(local_path):
            local_size = os.path.getsize(local_path)
            # 简单的非零检查，如果想更严谨可以用 HEAD 请求拿 Content-Length
            if local_size > 0:
                logger.info(f"Skipping (exists): {filename}")
                return True

        logger.info(f"Downloading via HTTPS: {filename}")
        
        try:
            # 使用 HTTP Basic Auth
            with requests.get(url, auth=(self.username, self.password), stream=True, timeout=60) as r:
                if r.status_code == 403:
                    logger.error("HTTP 403 Forbidden. Check credentials.")
                    return False
                r.raise_for_status()
                
                total_size = int(r.headers.get('content-length', 0))
                
                with open(local_path, 'wb') as f, tqdm(
                    desc=filename,
                    total=total_size,
                    unit='B',
                    unit_scale=True,
                    unit_divisor=1024,
                    leave=False
                ) as bar:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
                        bar.update(len(chunk))
            return True
        except Exception as e:
            logger.error(f"HTTP Download failed for {filename}: {e}")
            if os.path.exists(local_path):
                os.remove(local_path)
            return False

    def run(self, start_date_str, end_date_str):
        if not self.username:
            logger.error("Username required.")
            return

        os.makedirs(self.save_path, exist_ok=True)
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d")
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").replace(hour=23, minute=59, second=59)
        
        years = range(start_date.year, end_date.year + 1)
        
        for year in years:
            # 1. 获取列表 (FTP)
            files = self.get_file_list_via_ftp(year, start_date, end_date)
            
            if not files:
                logger.warning(f"No files found for year {year}")
                continue
                
            logger.info(f"Found {len(files)} files. Starting HTTP download batch...")
            
            # 2. 下载文件 (HTTP)
            success_count = 0
            for filename in files:
                if self.download_file_via_https(filename, year):
                    success_count += 1
                else:
                    # 如果 HTTP 失败，稍微暂停一下避免请求过于频繁被封
                    time.sleep(1)
            
            logger.info(f"Year {year} finished. Success: {success_count}/{len(files)}")

if __name__ == "__main__":
    # ---------------- 配置区 ----------------
    SAVE_DIR = r"E:\A_graduate\code_and_program\Satellite_data_processing\Satellite_Data\CryoSat\2025"
    START_DATE = "2025-05-01"
    END_DATE = "2025-09-30"
    
    ESA_USERNAME = "Yipiao01119@163.com" 
    ESA_PASSWORD = "Huang@1piao"
    # ---------------------------------------

    if not ESA_USERNAME:
        ESA_USERNAME = input("Enter ESA Username: ").strip()
    if not ESA_PASSWORD:
        ESA_PASSWORD = getpass.getpass("Enter ESA Password: ").strip()

    downloader = CryoSatHybridDownloader(SAVE_DIR, ESA_USERNAME, ESA_PASSWORD)
    downloader.run(START_DATE, END_DATE)