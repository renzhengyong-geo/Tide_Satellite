clc; clear;

%% ========================================================================
%  1. 初始化
% ========================================================================
disp('1. 初始化多星融合反演 (Fast Huber Strategy)...');

target_workers = 30; 
current_pool = gcp('nocreate');
if isempty(current_pool) || current_pool.NumWorkers ~= target_workers
    delete(current_pool);
    parpool('local', target_workers);
end

% 模型参数
a = 6371.2;
N_max = 32;                 % 28阶
period_tidal = 12.42060122; 
V0_u_rad = 2.352113;        
omega_tidal = 2 * pi / period_tidal; 
num_params = N_max * (N_max + 2) * 2;

% 求解参数
MAX_ITER = 80;        % Huber 收敛快，40次足够
BLOCK_SIZE = 15000;

%% ========================================================================
%  2. 卫星配置 (优化版：增强 Swarm/CHAMP 主导地位)
% ========================================================================
SAT_DB = containers.Map();

% [Swarm] 基准 - 黄金标准
SAT_DB('Swarm')   = struct('SigAbs', 2.2, 'SigGrad', 0.4, 'Att', 5.0,  'Scale', 1.0, 'HuberK', 1.5);
SAT_DB('Alpha')   = SAT_DB('Swarm'); SAT_DB('Bravo') = SAT_DB('Swarm'); SAT_DB('Charlie') = SAT_DB('Swarm');

% [CHAMP] 极其关键，对早期磁场约束很大
SAT_DB('CHAMP')   = struct('SigAbs', 2.5, 'SigGrad', 0.4, 'Att', 10.0, 'Scale', 1.0, 'HuberK', 1.5); 

% [辅助卫星组] 降低 Scale，但 HuberK 不能太严，否则会产生病态矩阵
% Orsted/SAC-C 姿态不稳，给较低 Scale
SAT_DB('Orsted')  = struct('SigAbs', 2.5, 'SigGrad', 0.4, 'Att', 60.0, 'Scale', 0.1, 'HuberK', 1.345); 
SAT_DB('SACC')    = struct('SigAbs', 2.5, 'SigGrad', 0.4, 'Att', 40.0, 'Scale', 0.1, 'HuberK', 1.345);
SAT_DB('MSS')     = struct('SigAbs', 2.2, 'SigGrad', 0.4, 'Att', 10.0, 'Scale', 1.0, 'HuberK', 0.5);

% [低权重组] 仅作为空间补充，避免过度干扰核心解
SAT_DB('CryoSat') = struct('SigAbs', 6.0, 'SigGrad', 3.0, 'Att', 30.0, 'Scale', 0.1, 'HuberK', 1.5); 
SAT_DB('GraceFO') = struct('SigAbs', 10.0,'SigGrad', 4.0, 'Att', 60.0, 'Scale', 0.01, 'HuberK', 0.6); 

%% ========================================================================
%  3. 数据加载 (包含 QD 筛选)
% ========================================================================
disp('2. 加载数据...');
D = {};
file_patterns = {'*_Weighted.mat', '*_Scalar.mat', '*_Input_*.mat'};
file_list = [];
for p = 1:length(file_patterns), file_list = [file_list; dir(file_patterns{p})]; end
[~, idx_u] = unique({file_list.name}); file_list = file_list(idx_u);

for i = 1:length(file_list)
    fname = file_list(i).name;
    sat_key = ''; keys_reg = SAT_DB.keys;
    for k = 1:length(keys_reg)
        if contains(fname, keys_reg{k}, 'IgnoreCase', true), sat_key = keys_reg{k}; break; end
    end
    if isempty(sat_key), continue; end 
    
    cfg = SAT_DB(sat_key);
    tmp = load(fname); vars = fieldnames(tmp);
    for v = 1:length(vars)
        Raw = tmp.(vars{v}); if ~isstruct(Raw), continue; end
        is_vec = contains(vars{v}, 'Vector') || isfield(Raw, 'B_res');
        is_cross = contains(vars{v}, 'Cross');
        is_grad  = contains(vars{v}, 'Grad') || isfield(Raw, 'd_grad') || isfield(Raw, 'dF');
        if is_vec, if is_cross, type=5; elseif is_grad, type=3; else, type=1; end
        else, if is_cross, type=6; elseif is_grad, type=4; else, type=2; end; end
        
        % 【调用更新后的标准化函数】
        % 这里会自动执行粗差剔除 (Abs>5nT, Grad>2nT)
        [S, filter_msg] = standardize_data_fixed(Raw, type, sat_key, cfg);
        
        if ~isempty(S)
            % 修改点：既然已经做了粗差剔除，所有保留的数据都是高质量的，
            % 因此将采样比例设为 1.0 (100% 使用)
            ratio = 1.0; 
            
            [cell_added, debug_msg] = sample_and_add(S, ratio, cfg.Scale);
            if ~isempty(cell_added)
                D = [D; cell_added]; 
                % 打印一下剔除情况，方便调试
                % fprintf('   [Loaded] %s: %s, %s\n', sat_key, filter_msg, debug_msg);
            end
        end
    end
end
if isempty(D), error('无数据'); end

JobList = []; total_obs_count = 0;
for k = 1:length(D)
    type = D{k}.Type; is_vec = ismember(type, [1,3,5]);
    n_pts = length(D{k}.Obs) / (is_vec*2 + 1);
    total_obs_count = total_obs_count + length(D{k}.Obs);
    num_blocks = ceil(n_pts / BLOCK_SIZE);
    for b = 1:num_blocks
        job.DataSetID = k; job.SatConfig = D{k}.Config;
        job.StartIdx  = (b-1)*BLOCK_SIZE + 1; job.EndIdx = min(b*BLOCK_SIZE, n_pts);
        JobList = [JobList; job]; 
    end
end
D_const = parallel.pool.Constant(D);
fprintf('   总观测数: %d\n', total_obs_count);

%% --- Step 4: 靶向正则化 (让低阶相关性优先回升) ---
disp('3. 构建软约束正则化矩阵...');
reg_diag = zeros(num_params, 1);
idx_ptr = 1;

for n = 1:N_max

    % 高阶使用幂次，防止拟合数据中的高频非潮汐噪声
    w_n = (n*(n+1))^2; 

    % n=1 必须重罚，因为它是环电流干扰最重的地方
    if n == 1, w_n = 110000.0; end 
    
    num_coeffs_n = 2 * (2*n + 1);
    reg_diag(idx_ptr : idx_ptr + num_coeffs_n - 1) = w_n;
    idx_ptr = idx_ptr + num_coeffs_n;
end
R_mat = spdiags(reg_diag, 0, num_params, num_params);

tic
sample_jobs = randperm(length(JobList), min(40, length(JobList)));
trace_acc = 0;
for i = 1:length(sample_jobs)
    job = JobList(sample_jobs(i)); DS = D{job.DataSetID};
    K = get_K_block(DS, job.StartIdx:job.EndIdx, N_max, a, omega_tidal, V0_u_rad);
    trace_acc = trace_acc + sum(K(:).^2);
end
avg_trace = (trace_acc / length(sample_jobs)) / BLOCK_SIZE;

% Lambda 的选取建议手动微调，如果结果依然抖动，请将 0.5 改为 2.0 或更高
lambda_base = 2e-3; % 初始量级参考
lambda = lambda_base * avg_trace; 
fprintf('   Lambda 设定为: %.2e\n', lambda);
toc

%% ========================================================================
%  5. IRLS 反演 (Strict Satellite-Specific Huber)
% ========================================================================csust
disp('4. 开始反演...');
U_est = zeros(num_params, 1);

for iter = 1:MAX_ITER
    iter_tic = tic;
    
    res_cell = cell(length(JobList), 1);
    parfor i = 1:length(JobList)
        job = JobList(i); DS = D_const.Value{job.DataSetID}; idx = job.StartIdx:job.EndIdx;
        K = get_K_block(DS, idx, N_max, a, omega_tidal, V0_u_rad);
        d = get_obs_block(DS, idx);
        res_cell{i} = d - K * U_est;
    end
    
    LHS_total = sparse(num_params, num_params);
    RHS_total = zeros(num_params, 1);
    
    parfor i = 1:length(JobList)
        job = JobList(i); DS = D_const.Value{job.DataSetID}; idx = job.StartIdx:job.EndIdx;
        cfg = job.SatConfig;
        
        K = get_K_block(DS, idx, N_max, a, omega_tidal, V0_u_rad);
        d = get_obs_block(DS, idx);
        r = res_cell{i};
        
        % 1. 获取物理 Sigma (含 Table 3 逻辑)
        [sig_phys, geo_w] = compute_table3_sigma(DS, idx, cfg);
        
        % 2. 获取该卫星的 Huber 常数
        k_sat = 1.5;
        if isfield(cfg, 'HuberK'), k_sat = cfg.HuberK; end
        
        % 3. 梯度数据再严一点 (x0.7)
        is_grad = ismember(DS.Type, [3,4,5,6]);
        if is_grad, k_eff = k_sat * 0.5; else, k_eff = k_sat; end
        
        % 4. 计算权重
        r_norm = abs(r) ./ sig_phys;
        
        % 标准 Huber (收敛最稳)
        w_huber = (r_norm <= k_eff).*1.0 + (r_norm > k_eff).*(k_eff ./ (r_norm+1e-8));
        
        % 综合权重
        w_final = (DS.Scale .* geo_w .* w_huber) ./ (sig_phys.^2);
        
        sqrt_W = sqrt(w_final);
        Kw = K .* sqrt_W; dw = d .* sqrt_W;
        
        LHS_total = LHS_total + Kw' * Kw;
        RHS_total = RHS_total + Kw' * dw;
    end
    
    % 求解 (带强正则化)
    LHS_reg = LHS_total + lambda * R_mat;
    U_new = LHS_reg \ RHS_total;
    
    change = norm(U_new - U_est) / (norm(U_est) + 1e-9);
    fprintf('   Iter %d: Change=%.2e (%.1fs)\n', iter, change, toc(iter_tic));
    
    U_est = U_new;
    if change < 1e-5, break; end
end

%% ========================================================================
%  6. 结果保存 (完美对齐 build_K_matrix_paper 列顺序)
% ========================================================================
% 1. 提取实部 (cos wt) 和虚部 (sin wt)
coeffs_real = U_est(1:2:end); 
coeffs_imag = U_est(2:2:end);

% 2. 按照 build_K_matrix_paper 的三层循环生成 (n, m) 标签
n_out = []; 
m_out = [];

for n = 1:N_max
    for m = 0:n
        % 第一部分：g_nm (对应 m=0 以及 m>0 的余弦分量)R
        n_out = [n_out; n];
        m_out = [m_out; m]; % 此时标签为 0, 1, 2...
        
        % 第二部分：h_nm (仅当 m > 0 时存在)
        if m > 0
            n_out = [n_out; n];
            m_out = [m_out; -m]; % 此时标签为 -1, -2...
        end
    end
end

% 3. 安全校验：标签总数必须等于 U_est 的一半 (系数对的数量)
if length(n_out) ~= length(coeffs_real)
    error('映射错误：标签数(%d)与系数数(%d)不符！请检查阶数设置。', ...
        length(n_out), length(coeffs_real));
end

% 4. 计算 Rn 用于质量检查
Rn = zeros(N_max, 1);
for n = 1:N_max
    idx = (n_out == n);
    % 功率谱公式: (n+1) * sum(Real^2 + Imag^2)
    Rn(n) = (n + 1) * sum(coeffs_real(idx).^2 + coeffs_imag(idx).^2);
end

fprintf('\n=== 质量检查 (映射修正版) ===\n');
fprintf('N=1:  %.4e\n', Rn(1));
fprintf('N=6:  %.4e\n', Rn(6));
fprintf('N=%d: %.4e\n', N_max, Rn(N_max));

% 5. 保存到 CSV (CSV格式会自动对齐绘图脚本的 get_iota 逻辑)
T = table(n_out, m_out, coeffs_real, coeffs_imag, 'VariableNames', {'n', 'm', 'Real', 'Imag'});
writetable(T, 'MultiSat_Result_HighVol_Strict.csv');
fprintf('结果已保存。映射已修正，现在相关性应该能正常显示了。\n');


%% ================== 辅助函数 (Update) ==================

function [sigma_vec, geo_w] = compute_table3_sigma(DS, idx, cfg)
    type = DS.Type;
    is_vec = ismember(type, [1,3,5]); 
    is_grad = ismember(type, [3,4,5,6]);
    N_pts = length(idx); 
    if type <= 2, pos = DS.Pos(idx,:); else, pos = DS.Pos1(idx,:); end
    colat = pos(:, 2);
    
    if is_grad, base_sigma = cfg.SigGrad; else, base_sigma = cfg.SigAbs; end
    
    if type == 1 
        B_local = 30000 * sqrt(1 + 3 * cos(deg2rad(colat)).^2);
        sigma_att = B_local * (cfg.Att * pi / 648000);
        val = sqrt(base_sigma^2 + sigma_att.^2); 
        sigma_vec = [val; val; val];      
    elseif type == 2 
        B_local = 30000 * sqrt(1 + 3 * cos(deg2rad(colat)).^2);
        sigma_att = B_local * (cfg.Att * pi / 648000);
        val = sqrt(base_sigma^2 + (0.1 * sigma_att).^2);
        sigma_vec = val;
    else 
        % 梯度数据：使用表格中的极低 Sigma (0.4nT)
        val = base_sigma * ones(N_pts, 1);
        if is_vec, sigma_vec = [val; val; val]; else, sigma_vec = val; end
    end
    w_g = max(sin(deg2rad(colat)), 0.2);
    if is_vec, geo_w = [w_g; w_g; w_g]; else, geo_w = w_g; end
end

function [S, msg] = standardize_data_fixed(Raw, type, sat_name, cfg)
    S = struct(); S.Type = type; S.Config = cfg; S.Scale = cfg.Scale;
    msg = ''; t=[]; d=[]; pos=[]; qd=[];
    
    is_grad = ismember(type, [3,4,5,6]); % 3,5=VecGrad; 4,6=ScaGrad
    is_vec  = ismember(type, [1,3,5]);   % 1=VecAbs;  3,5=VecGrad
    
    % --- 1. 基础字段提取 ---
    try
        if is_grad
             if isfield(Raw, 'Time1'), t=Raw.Time1; elseif isfield(Raw, 'Time'), t=Raw.Time; end
             if isfield(Raw, 'Pos1'), pos=Raw.Pos1; end
             % 梯度数据通常存在 d_grad 或 dF 字段
             if isfield(Raw, 'd_grad'), d=Raw.d_grad; elseif isfield(Raw, 'dF'), d=Raw.dF; end
        else
             if isfield(Raw, 'Time'), t=Raw.Time; end
             if isfield(Raw, 'Pos'), pos=Raw.Pos; end
             % 绝对值数据通常存在 B_res 或 dF 字段
             if isfield(Raw, 'B_res'), d=Raw.B_res; elseif isfield(Raw, 'dF'), d=Raw.dF; end
        end
        if isfield(Raw, 'Dir'), S.Dir = Raw.Dir; end
        if isfield(Raw, 'QD_Lat'), qd = Raw.QD_Lat; end
    catch
        S=[]; msg='Field Missing'; return; 
    end
    
    if isempty(d) || isempty(t) || isempty(pos), S=[]; msg='Empty Data'; return; end
    
    % --- 2. 时间标准化 ---
    t_mean = mean(t, 'omitnan'); 
    t_days = t; % 默认
    if t_mean > 700000 % MATLAB datenum 格式
        t_days = t - 730486.0; 
    elseif t_mean > 15000 && t_mean < 40000 % MJD2000 格式
        t_days = t - 18262.0; 
    end
    t_hours = t_days * 24.0; 
    
    % --- 3. 基础有效性筛选 (NaN, 高度, EEJ) ---
    % 基础掩码：非空且高度 > 300km (近似 R>6671, 此处保留原本的 >5000 逻辑)
    valid = ~isnan(t_hours) & (vecnorm(pos,2,2) > 6371);
    
    % EEJ (赤道电急流) 剔除: 针对 Orsted/SAC-C
    target_sats = {'Orsted', 'SAC'};
    is_target_sat = false;
    for k=1:length(target_sats)
        if contains(sat_name, target_sats{k}, 'IgnoreCase', true), is_target_sat=true; break; end
    end
    
    if is_target_sat && ~isempty(qd) && length(qd)==length(valid)
        valid = valid & (abs(qd) >= 10.0);
    end
    
    % 如果基础筛选后数据太少，直接返回
    if sum(valid) < 10, S=[]; msg='Valid<10'; return; end
    
    % --- 提取基础筛选后的临时数据 ---
    t_tmp = t_hours(valid);
    d_tmp = d(valid, :);
    
    % 处理位置和辅助时间 (Pos1/Pos2/Time2)
    if is_grad
        if isfield(Raw, 'Time2'), t2_raw = Raw.Time2;
            if mean(t2_raw,'omitnan')>700000, dt=t2_raw-730486.0; elseif mean(t2_raw,'omitnan')>15000, dt=t2_raw-18262.0; else, dt=t2_raw; end
            t2_tmp = dt(valid) * 24.0; 
        else
            t2_tmp = t_tmp + (10/3600); 
        end
        p1_tmp = Raw.Pos1(valid,:); 
        p2_tmp = Raw.Pos2(valid,:);
    else
        p_tmp = pos(valid,:);
    end
    
    if isfield(S, 'Dir'), dir_tmp = S.Dir(valid,:); else, dir_tmp=[]; end

    % --- 4. 【新增】粗差剔除 (Gross Error Check) ---
    % 设定阈值
    if is_grad
        limit = 2.0; % 梯度数据阈值 (nT)
    else
        limit = 5.0; % 绝对数据阈值 (nT)
    end
    
    % 计算保留掩码 (Keep Mask)
    % 对于矢量数据 (N x 3)，如果任意分量超过阈值，整行剔除。
    if size(d_tmp, 2) > 1
        % max(abs(row)) > limit 则剔除
        is_outlier = any(abs(d_tmp) > limit, 2);
    else
        % 标量直接判断
        is_outlier = abs(d_tmp) > limit;
    end
    
    keep_mask = ~is_outlier;
    n_kept = sum(keep_mask);
    n_total = length(keep_mask);
    msg = sprintf('Outlier Removed: %d/%d', n_total - n_kept, n_total);
    
    if n_kept < 10, S=[]; msg='Filtered to Empty'; return; end
    
    % --- 5. 应用粗差剔除并封装到 S ---
    if is_grad
        S.Time1 = t_tmp(keep_mask);
        S.Time2 = t2_tmp(keep_mask);
        S.Pos1  = p1_tmp(keep_mask, :);
        S.Pos2  = p2_tmp(keep_mask, :);
    else
        S.Time = t_tmp(keep_mask);
        S.Pos  = p_tmp(keep_mask, :);
    end
    
    if ~isempty(dir_tmp), S.Dir = dir_tmp(keep_mask, :); end
    
    % 处理观测值
    obs_final = d_tmp(keep_mask, :);
    
    % 最终拉直向量 (Flatten)
    if is_vec
        S.Obs = reshape(obs_final, [], 1); % [N1; N2...; E1; E2...; C1; C2...]
    else
        S.Obs = obs_final;
    end
end

function [cell_out, debug_info] = sample_and_add(S, ratio, scale)
    cell_out = {}; is_vec = ismember(S.Type, [1,3,5]);
    if is_vec, n_total = length(S.Obs)/3; else, n_total = length(S.Obs); end
    n_keep = floor(n_total * ratio);
    if n_keep < 20, debug_info='Too few'; return; end
    p = randperm(n_total, n_keep)';
    S_new = S; S_new.Scale = scale;
    if isfield(S, 'Time'), S_new.Time = S.Time(p); end
    if isfield(S, 'Time1'), S_new.Time1 = S.Time1(p); S_new.Time2 = S.Time2(p); end
    if isfield(S, 'Pos'), S_new.Pos = S.Pos(p,:); end
    if isfield(S, 'Pos1'), S_new.Pos1 = S.Pos1(p,:); S_new.Pos2 = S.Pos2(p,:); end
    if isfield(S, 'Dir'), S_new.Dir = S.Dir(p,:); end
    if is_vec, S_new.Obs = S.Obs([p; p+n_total; p+2*n_total]);
    else, S_new.Obs = S.Obs(p); end
    cell_out{1} = S_new; debug_info = sprintf('Keep %d', n_keep);
end

function K_block = get_K_block(DS, idx, N_max, a, omega, V0)
type = DS.Type;
is_vec = ismember(type, [1, 3, 5]);

if is_vec
    % idx 是点索引 (1..N)
    if type == 1
        [Kr, Kt, Kp] = build_K_matrix_paper(DS.Pos(idx,:), cos(omega*DS.Time(idx)+V0), sin(omega*DS.Time(idx)+V0), N_max, a);
        K_block = [Kr; Kt; Kp];
    elseif ismember(type, [3, 5])
        ph1=omega*DS.Time1(idx)+V0; ph2=omega*DS.Time2(idx)+V0;
        [Kr1, Kt1, Kp1]=build_K_matrix_paper(DS.Pos1(idx,:),cos(ph1),sin(ph1),N_max,a);
        [Kr2, Kt2, Kp2]=build_K_matrix_paper(DS.Pos2(idx,:),cos(ph2),sin(ph2),N_max,a);
        K_block = [Kr2-Kr1; Kt2-Kt1; Kp2-Kp1];
    end
else
    % idx 是点索引 (1..N)
    if type == 2
        [Kr, Kt, Kp] = build_K_matrix_paper(DS.Pos(idx,:), cos(omega*DS.Time(idx)+V0), sin(omega*DS.Time(idx)+V0), N_max, a);
        K_block = DS.Dir(idx,1).*Kr + DS.Dir(idx,2).*Kt + DS.Dir(idx,3).*Kp;
    elseif ismember(type, [4, 6])
        ph1=omega*DS.Time1(idx)+V0; ph2=omega*DS.Time2(idx)+V0;
        [Kr1, Kt1, Kp1]=build_K_matrix_paper(DS.Pos1(idx,:),cos(ph1),sin(ph1),N_max,a);
        [Kr2, Kt2, Kp2]=build_K_matrix_paper(DS.Pos2(idx,:),cos(ph2),sin(ph2),N_max,a);
        K_block = DS.Dir(idx,1).*(Kr2-Kr1) + DS.Dir(idx,2).*(Kt2-Kt1) + DS.Dir(idx,3).*(Kp2-Kp1);
    end
end
end

function obs = get_obs_block(DS, idx)
    if ismember(DS.Type, [1,3,5])
        N = length(DS.Obs)/3;
        obs = DS.Obs([idx(:); idx(:)+N; idx(:)+2*N]);
    else
        obs = DS.Obs(idx);
    end
end