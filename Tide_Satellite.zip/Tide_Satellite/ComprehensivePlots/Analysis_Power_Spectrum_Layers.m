function Analysis_Power_Spectrum_Layers()
    % -------------------------------------------------------------------------
    % 主程序：GEMMIE 多层模型功率谱对比分析
    % -------------------------------------------------------------------------
    
    clc; close all;
    
    %% === 1. 参数配置 ===
    
    % 物理常数
    const.a_radius = 6371.2;  % 地球半径 (km)
    const.N_max    = 40;      % 最大球谐阶数
    
    % 路径配置 (请修改为实际路径)
    base_dir = 'TIMF_ECCO/Magnetic_2017_layer_use_lateral/0km'; 
    suffix   = '0Km'; 
    
    files.L1  = fullfile(base_dir, sprintf('Magnetic_L1_real_2017_M2_TPXO8_IGRF13_1deg_height%s.h5', suffix));
    files.L20 = fullfile(base_dir, sprintf('Magnetic_L15_real_2017_M2_TPXO8_IGRF13_1deg_height%s.h5', suffix));
    files.L35 = fullfile(base_dir, sprintf('Magnetic_L35_real_2017_M2_TPXO8_IGRF13_1deg_height%s.h5', suffix));
    
    % ---------------------------------------------------------------------
    % 【样式配置区】 更改此处即可快速改变全图颜色
    % ---------------------------------------------------------------------
    % 推荐学术色值：
    % 黑色: [0 0 0] | 蓝色: [0 0.447 0.741] | 砖红: [0.85 0.325 0.098] | 紫色: [0.494 0.184 0.556]
   
    plot_cfg.L35  = struct('Name', 'Ref (35 Layers)', 'Color', [0 0 0],       'Style', '-',  'Marker', 'o'); % 黑色实线
    plot_cfg.L20  = struct('Name', 'Ours (15 Layers)', 'Color',  [0 0.5 0.5], 'Style', '-',  'Marker', '*');    % 科学蓝
    plot_cfg.L1   = struct('Name', '1 Layer',         'Color', [0.85 0.325 0.098], 'Style', '-', 'Marker', 's');    % 砖红色虚线
    plot_cfg.Diff = struct('Name', 'Diff (L35 - L1)', 'Color',  [0 0.447 0.741], 'Style', '-',  'Marker', 'o'); % 深紫色点线
    % ---------------------------------------------------------------------
    
    %% === 2. 计算核心循环 ===
    
    fprintf('=== 开始功率谱分析 (高度: %s) ===\n', suffix);
    
    % 2.1 处理 L35 (基准)
    [coeffs_35, ~] = process_gemmie_file(files.L35, const);
    Rn_35 = calculate_spectrum(coeffs_35, const.a_radius, const.N_max);
    
    % 2.2 处理 L20 (15层)
    [coeffs_20, ~] = process_gemmie_file(files.L20, const);
    Rn_20 = calculate_spectrum(coeffs_20, const.a_radius, const.N_max);
    
    % 2.3 处理 L1 (1层)
    [coeffs_1, ~] = process_gemmie_file(files.L1, const);
    Rn_1 = calculate_spectrum(coeffs_1, const.a_radius, const.N_max);
    
    % 2.4 计算差值谱
    coeffs_diff = coeffs_35 - coeffs_1; 
    Rn_diff = calculate_spectrum(coeffs_diff, const.a_radius, const.N_max);
    
    %% === 3. 绘图 (Publication Quality) ===
    
    % 设定物理尺寸: 18cm (单栏或双栏宽度)
    fig = figure('Units', 'centimeters', 'Position', [2, 2, 18, 14], 'Color', 'w');
    ax = gca;
    hold on;
    
    degrees = 1:const.N_max;
    
    % 绘制线条
    h1 = plot_line(degrees, Rn_35, plot_cfg.L35);
    h2 = plot_line(degrees, Rn_20, plot_cfg.L20);
    h3 = plot_line(degrees, Rn_1,  plot_cfg.L1);
    h4 = plot_line(degrees, Rn_diff, plot_cfg.Diff);
    
    % 坐标轴精细化
    set(ax, 'YScale', 'log', 'FontSize', 12, 'FontName', 'Arial', 'LineWidth', 1.2);
    set(ax, 'XMinorTick', 'on', 'YMinorTick', 'on', 'TickDir', 'out', 'Box', 'on');
    grid on;
    set(ax, 'GridLineStyle', ':', 'GridColor', [0.8 0.8 0.8], 'GridAlpha', 0.7);
    
    % 标签 (期刊规范: 加粗且增大)
    xlim([1, const.N_max]);
    xlabel('Spherical Harmonic Degree (n)', 'FontSize', 13, 'FontWeight', 'bold');
    ylabel('Power Spectrum R_n (nT^2)', 'FontSize', 13, 'FontWeight', 'bold');
    title(['M2 Tidal Inudced Magnetic Power Spectrum (' suffix ')'], 'FontSize', 14, 'FontWeight', 'bold');
    
    % 图例 (精简)
    legend([h1, h2, h3, h4], ...
           {plot_cfg.L35.Name, plot_cfg.L20.Name, plot_cfg.L1.Name, plot_cfg.Diff.Name}, ...
           'Location', 'best', 'FontSize', 11, 'Box', 'on', 'EdgeColor', 'none');
       
    hold off;
    
    %% === 4. 保存图片 ===
    if ~exist('Figures', 'dir'), mkdir('Figures'); end
    out_name = fullfile('Figures', ['Power_Spectrum_' suffix]);
    
    % 保存 FIG, PDF (矢量图) 和 PNG (300 DPI)
    savefig(fig, [out_name '.fig']);
    exportgraphics(fig, [out_name '.pdf'], 'ContentType', 'vector');
    exportgraphics(fig, [out_name '.png'], 'Resolution', 300);
    
    fprintf('完成！所有格式图片已保存到 Figures 文件夹。\n');
end


%% ================= 子函数区域 =================

function [coeffs, r_data] = process_gemmie_file(filepath, const)
    if ~isfile(filepath), error('找不到文件: %s', filepath); end
    
    try
        Re_Ht_r = h5read(filepath, '/Re_Ht_r');
        Im_Ht_r = h5read(filepath, '/Im_Ht_r');
        Theta   = h5read(filepath, '/Theta'); 
        Phi     = h5read(filepath, '/Phi');
        
        field_val = double(Re_Ht_r) + 1i * double(Im_Ht_r);
        % 单位转换 (A/m -> nT)
        unit_factor = 4 * pi * 100; 
        field_nT = field_val * unit_factor;
    catch
        error('H5 读取失败，请检查变量名。');
    end
    
    Theta = double(Theta(:)); Phi = double(Phi(:)); Data = double(field_nT(:));
    
    if contains(filepath, '450Km'), r_data = const.a_radius + 450;
    elseif contains(filepath, '200Km'), r_data = const.a_radius + 200;
    else, r_data = const.a_radius; end
    
    coeffs = sha_solver_vectorized(Theta, Phi, Data, r_data, const);
end

function coeffs = sha_solver_vectorized(colat, lon, data, r_data, const)
    N_max = const.N_max; a = const.a_radius;
    n_pts = length(colat); n_coeffs = N_max * (N_max + 2);
    A = zeros(n_pts, n_coeffs);
    col_idx = 1; rad_ratio = a / r_data; cos_colat = cosd(colat); 
    
    for n = 1:N_max
        radial_term = (n + 1) * (rad_ratio)^(n + 2);
        P = legendre(n, cos_colat', 'sch');
        for m = 0:n
            P_nm = P(m+1, :)'; 
            term_common = radial_term * P_nm;
            if m == 0
                A(:, col_idx) = term_common; col_idx = col_idx + 1;
            else
                A(:, col_idx) = term_common .* cosd(m * lon); col_idx = col_idx + 1;
                A(:, col_idx) = term_common .* sind(m * lon); col_idx = col_idx + 1;
            end
        end
    end
    coeffs = A \ data;
end

function Rn = calculate_spectrum(coeffs, a_radius, N_max)
    Rn = zeros(N_max, 1); curr_idx = 1;
    for n = 1:N_max
        num_m = 2*n + 1;
        c_n = coeffs(curr_idx : curr_idx + num_m - 1);
        Rn(n) = (n + 1) * sum(abs(c_n).^2);
        curr_idx = curr_idx + num_m;
    end
end

function h = plot_line(x, y, cfg)
    h = semilogy(x, y, ...
        'Color', cfg.Color, ...
        'LineStyle', cfg.Style, ...
        'LineWidth', 1.8, ...
        'Marker', cfg.Marker, ...
        'MarkerSize', 5, ...
        'MarkerFaceColor', cfg.Color, ...
        'DisplayName', cfg.Name);
end