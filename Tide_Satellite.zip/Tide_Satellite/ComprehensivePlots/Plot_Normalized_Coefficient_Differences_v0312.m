function Plot_Normalized_Coefficient_Differences_v0312()
% -------------------------------------------------------------------------
% Purpose: 比较 Ours (CSV), HRM2, CM6, Kalman 与 正演模型 的差异
% Layout:  TiledLayout (2x2), 白底黑字
% Fix:     1. 修正文件读取逻辑（与参考代码对齐）
%          2. 修正归一化系数差异公式（严格按公式12）
%             S(n,m) = 100*(g_e - g_r)/Dn  for m>=0  [g系数]
%             S(n,m) = 100*(h_e - h_r)/Dn  for m<0   [h系数]
%             Dn = sqrt( 1/(2n+1) * sum_{m=0}^{n} [g_r^2 + h_r^2] )
%          3. 修正 Forward 模型系数虚部问题（SHA结果取实部存储）
% -------------------------------------------------------------------------
clc; close all;

%% ========= 1. 参数与文件配置 =========
const.a_radius = 6371.2;
const.N_max    = 40;

file_Ours   = '潮汐磁场结果/MultiSat_Result_HighVol_Strict.csv';
file_HRM2   = 'Grayver_result/HRM2.txt';
file_CM6    = 'CM6/M2.txt';
file_Kalman = 'Kalman_result/M2/Model/TIDALM2_MEAN_Radius_6371.2.txt';
file_Fwd    = '正演模拟结果/KUV_RES_0001.h5';

% 跳过行数（与参考代码保持一致，已包含 N_max 那行）
% HRM2: 9行注释 + 1行"32 12.4206" = 10
% CM6:  6行注释 + 1行说明 + 1行"36 12.4206" = 8
skip_Ours   = 1;
skip_HRM2   = 10;
skip_CM6    = 7;
skip_Kalman = 0;

Target_Max_N = 30;

cfg.bg_color   = 'w';
cfg.txt_color  = 'k';
cfg.cmap_limit = [-5 5];

%% ========= 2. 数据读取 =========
fprintf('正在读取模型系数数据...\n');

Ours_Coeffs   = load_coeffs_robust(file_Ours,   'Ours',   skip_Ours);
HRM2_Coeffs   = load_coeffs_robust(file_HRM2,   'HRM2',   skip_HRM2);
CM6_Coeffs    = load_coeffs_robust(file_CM6,    'CM6',    skip_CM6);
Kalman_Coeffs = load_coeffs_robust(file_Kalman, 'Kalman', skip_Kalman);

fprintf('  读取 H5 正演模型...\n');
Fwd_Coeffs = load_h5_forward_model(file_Fwd, const);

% 强制转为实数（SHA求解结果理论上应为实数，虚部为数值噪声）
Fwd_Coeffs = real(Fwd_Coeffs);

check_model_order(Ours_Coeffs,   'Ours');
check_model_order(HRM2_Coeffs,   'HRM2');
check_model_order(CM6_Coeffs,    'CM6');
check_model_order(Kalman_Coeffs, 'Kalman');
check_model_order(Fwd_Coeffs,    'Forward');

% 打印前3行用于验证读取正确性
fprintf('\n=== 前3行验证 ===\n');
print_first_rows(Ours_Coeffs,   'Ours',    3);
print_first_rows(HRM2_Coeffs,   'HRM2',    3);
print_first_rows(CM6_Coeffs,    'CM6',     3);
print_first_rows(Kalman_Coeffs, 'Kalman',  3);
print_first_rows(Fwd_Coeffs,    'Forward', 3);

%% ========= 3. 计算差异矩阵（严格按公式12）=========
fprintf('\n正在计算差异 (截断至 N=%d)...\n', Target_Max_N);

[S_Ours,   n_ours] = compute_diff_matrix(Ours_Coeffs,   Fwd_Coeffs, Target_Max_N);
[S_HRM2,   n_hrm2] = compute_diff_matrix(HRM2_Coeffs,   Fwd_Coeffs, Target_Max_N);
[S_CM6,    n_cm6]  = compute_diff_matrix(CM6_Coeffs,    Fwd_Coeffs, Target_Max_N);
[S_Kalman, n_kal]  = compute_diff_matrix(Kalman_Coeffs, Fwd_Coeffs, Target_Max_N);

fprintf('实际计算阶数: Ours=%d, HRM2=%d, CM6=%d, Kalman=%d\n', ...
    n_ours, n_hrm2, n_cm6, n_kal);

%% ========= 4. 绘图 (TiledLayout 2x2) =========
fig = figure('Color', cfg.bg_color, 'Unit', 'Centimeters', 'Position', [2 2 18 18]);
t = tiledlayout(2, 2, 'TileSpacing', 'compact', 'Padding', 'tight');

% 循环调用绘图
data_list = {S_Ours, S_HRM2, S_CM6, S_Kalman};
titles    = {'Ours – Model', 'HRM2 – Model', 'CM6 – Model', 'Kalman – Model'};

for i = 1:4
    ax = nexttile;
    % 判断：左侧列 (1,3)，底部行 (3,4)
    is_left = (mod(i,2) == 1);
    is_bottom = (i > 2);
    
    plot_triangle(ax, data_list{i}, Target_Max_N, cfg, is_left, is_bottom);
    title(ax, titles{i}, 'Color', cfg.txt_color, 'FontWeight', 'bold', 'FontSize', 11);
end

% 共享色棒
try
    colormap(fig, nclCM('BlueDarkRed18'));
catch
    nc = 256;
    s1 = [linspace(1.0,0.9,nc/4)', linspace(1.0,0.95,nc/4)', linspace(1.0,0.98,nc/4)'];
    s2 = [linspace(0.9,0.85,nc/4)', linspace(0.95,0.8,nc/4)', linspace(0.98,0.9,nc/4)'];
    s3 = [linspace(0.85,0.5,nc/4)', linspace(0.8,0.4,nc/4)', linspace(0.9,0.6,nc/4)'];
    s4 = [linspace(0.5,0.2,nc/4)', linspace(0.4,0.15,nc/4)', linspace(0.6,0.3,nc/4)'];
    my_cmap = max(0, min(1, [s1;s2;s3;s4]));
    colormap(fig, my_cmap);
end

cb = colorbar;
cb.Layout.Tile = 'south';
cb.Color = cfg.txt_color;
cb.Label.String = 'Normalized Coefficient Difference (%)';
cb.Label.FontWeight = 'bold';

exportgraphics(fig, '归一化系数差异_30阶_Fixed.pdf', 'Resolution', 600);
fprintf('绘图完成。\n');
end

%% ========================================================================
%                      H5正演模型读取函数
%% ========================================================================
function D = load_h5_forward_model(filepath, const)
if ~isfile(filepath)
    error('找不到H5文件: %s', filepath);
end
try
    Re_Ht_r = h5read(filepath, '/Re_Ht_r');
    Im_Ht_r = h5read(filepath, '/Im_Ht_r');
    Theta   = h5read(filepath, '/Theta');
    Phi     = h5read(filepath, '/Phi');
    field_val   = double(Re_Ht_r) + 1i * double(Im_Ht_r);
    unit_factor = 4 * pi * 100;   % A/m -> nT
    field_nT    = field_val * unit_factor;
catch ME
    error('H5读取失败: %s', ME.message);
end

Theta = double(Theta(:));
Phi   = double(Phi(:));
Data  = double(field_nT(:));

if contains(filepath, '450Km')
    r_data = const.a_radius + 450;
elseif contains(filepath, '200Km')
    r_data = const.a_radius + 200;
else
    r_data = const.a_radius;
end

coeffs = sha_solver_vectorized(Theta, Phi, Data, r_data, const);

% SHA结果转为标准格式，强制取实部（虚部为数值误差）
D = coeffs_to_standard_format(real(coeffs), const.N_max);
fprintf('    正演模型生成 %d 个系数 (最大阶数 %d)\n', size(D,1), max(D(:,1)));
end

function coeffs = sha_solver_vectorized(colat, lon, data, r_data, const)
N_max     = const.N_max;
a         = const.a_radius;
n_pts     = length(colat);
n_coeffs  = N_max * (N_max + 2);
A         = zeros(n_pts, n_coeffs);
col_idx   = 1;
rad_ratio = a / r_data;
cos_colat = cosd(colat);

for n = 1:N_max
    radial_term = (n + 1) * (rad_ratio)^(n + 2);
    P = legendre(n, cos_colat', 'sch');
    for m = 0:n
        P_nm        = P(m+1, :)';
        term_common = radial_term * P_nm;
        if m == 0
            A(:, col_idx) = term_common;
            col_idx = col_idx + 1;
        else
            A(:, col_idx)   = term_common .* cosd(m * lon);
            col_idx = col_idx + 1;
            A(:, col_idx)   = term_common .* sind(m * lon);
            col_idx = col_idx + 1;
        end
    end
end
coeffs = A \ data;
end

function D = coeffs_to_standard_format(coeffs, N_max)
% 输出格式 [n, m, coeff_val, 0]，全部为实数
% 约定: m>=0 行的第3列存 g_n^m (余弦项系数)
%       m<0  行的第3列存 h_n^|m| (正弦项系数)
D   = [];
idx = 1;
for n = 1:N_max
    num_m = 2*n + 1;
    if idx + num_m - 1 > length(coeffs), break; end
    c_n = real(coeffs(idx : idx + num_m - 1));  % 强制实数
    % m=0: g_n^0
    D = [D; n, 0, c_n(1), 0]; %#ok<AGROW>
    for m = 1:n
        D = [D; n,  m,  c_n(2*m),   0]; %#ok<AGROW>  % g_n^m
        D = [D; n, -m,  c_n(2*m+1), 0]; %#ok<AGROW>  % h_n^m
    end
    idx = idx + num_m;
end
end

%% ========================================================================
%                      文件读取函数
%% ========================================================================
function D = load_coeffs_robust(fname, label, nskip)
if ~isfile(fname)
    warning('文件不存在: %s', fname);
    D = []; return;
end
try
    if contains(fname, '.csv')
        T    = readtable(fname);
        vars = T.Properties.VariableNames;
        idx_n  = find(strcmpi(vars,'n')    | strcmpi(vars,'Degree')    | strcmpi(vars,'Degree_n'), 1);
        idx_m  = find(strcmpi(vars,'m')    | strcmpi(vars,'Order')     | strcmpi(vars,'Order_m'),  1);
        idx_re = find(strcmpi(vars,'Real') | strcmpi(vars,'Real_Part'), 1);
        idx_im = find(strcmpi(vars,'Imag') | strcmpi(vars,'Imag_Part'), 1);
        if isempty(idx_n) || isempty(idx_m)
            D = T{:, 1:4};
        else
            D = [T{:,idx_n}, T{:,idx_m}, T{:,idx_re}, T{:,idx_im}];
        end

    elseif contains(label, 'Kalman')
        raw = readmatrix(fname);
        D   = reconstruct_kalman_structure(raw);

    else
        % 标准文本格式：nskip 已包含注释行 + N_max 行
        raw = readmatrix(fname, 'NumHeaderLines', nskip);
        D   = raw(:, 1:4);
    end
    % 强制转为实数
    D = real(double(D));
catch ME
    warning('读取 %s 失败: %s', label, ME.message);
    D = [];
end
end

function D = reconstruct_kalman_structure(raw)
n_rows      = size(raw, 1);
re_vals     = raw(:, 1);
im_vals     = raw(:, 2);
D           = [];
current_idx = 1;
n           = 1;
while current_idx <= n_rows
    num_coeffs = 2*n + 1;
    if current_idx + num_coeffs - 1 > n_rows, break; end
    block_re = re_vals(current_idx : current_idx + num_coeffs - 1);
    block_im = im_vals(current_idx : current_idx + num_coeffs - 1);
    m_list   = zeros(num_coeffs, 1);
    m_list(1) = 0;
    ptr = 2;
    for k = 1:n
        m_list(ptr) = k; m_list(ptr+1) = -k; ptr = ptr + 2;
    end
    n_col = repmat(n, num_coeffs, 1);
    D = [D; n_col, m_list, block_re, block_im]; %#ok<AGROW>
    current_idx = current_idx + num_coeffs;
    n = n + 1;
end
end

function check_model_order(Data, label)
if isempty(Data)
    fprintf('  %s: 无数据\n', label);
else
    fprintf('  %s: 最大阶数 n=%d, 系数个数 %d\n', label, max(Data(:,1)), size(Data,1));
end
end

function print_first_rows(Data, label, nrows)
if isempty(Data)
    fprintf('  %s: 无数据\n', label); return;
end
fprintf('  %s 前%d行:\n', label, nrows);
disp(Data(1:min(nrows, size(Data,1)), :));
end

%% ========================================================================
%   差异计算：严格按公式(12)
%
%   S(n,m) = 100 * |g_e^m - g_r^m| / Dn    for m >= 0
%   S(n,m) = 100 * |h_e^m - h_r^m| / Dn    for m <  0
%
%   Dn = sqrt( 1/(2n+1) * ( g_r^{n,0}^2 + sum_{m=1}^{n}[g_r^{n,m}^2 + h_r^{n,m}^2] ) )
%
%   数据约定:
%     行 [n,  m, val, *]  m>=0 -> val = g_n^m
%     行 [n, -m, val, *]  m>0  -> val = h_n^m
%% ========================================================================
function [S, nmax_calc] = compute_diff_matrix(Eval_Mod, Ref_Mod, limit_n)
if isempty(Eval_Mod) || isempty(Ref_Mod)
    S = nan(limit_n+1, 2*limit_n+1);
    nmax_calc = limit_n; return;
end

nmax_calc  = min([max(Eval_Mod(:,1)), max(Ref_Mod(:,1)), limit_n]);
S          = zeros(nmax_calc+1, 2*nmax_calc+1);   % 预填0，非NaN
S(:)       = NaN;
center_col = nmax_calc + 1;

for n = 1:nmax_calc
    % ---- 分母 Dn：只对 m=0..n 单侧参考系数求和 ----
    g0     = get_gauss_val(Ref_Mod, n, 0);
    sum_sq = g0^2;
    for m = 1:n
        g_r    = get_gauss_val(Ref_Mod, n,  m);
        h_r    = get_gauss_val(Ref_Mod, n, -m);
        sum_sq = sum_sq + g_r^2 + h_r^2;
    end
    Dn = sqrt(sum_sq / (2*n + 1));
    if Dn < 1e-20, Dn = 1e-20; end

    % ---- 分子：逐 m 计算差异百分比 ----
    for m = -n:n
        val_E = get_gauss_val(Eval_Mod, n, m);
        val_R = get_gauss_val(Ref_Mod,  n, m);
        S(n+1, center_col + m) = (val_E - val_R) / Dn;
    end
end

% 确保输出为实数矩阵（防止数值噪声引入微小虚部）
S = real(S);
end

function val = get_gauss_val(Data, n, m)
% 取 [n, m] 行的第3列（实数标量）
idx = find(Data(:,1)==n & Data(:,2)==m, 1);
if isempty(idx)
    val = 0;
else
    val = real(Data(idx, 3));
end
end

%% ========================================================================
%                      绘图辅助
%% ========================================================================
function plot_triangle(ax, S, nmax_limit, cfg, is_left, is_bottom)
    % 1. 基本绘图
    [rows, ~] = size(S);
    actual_n  = rows - 1;
    x_axis    = -actual_n : actual_n;
    y_axis    = 0 : actual_n;
    
    h = imagesc(ax, x_axis, y_axis, S);
    set(h, 'AlphaData', ~isnan(S));
    
    % 2. 去除方框与刻度
    set(ax, 'Color', 'none', 'Box', 'off', 'XColor', 'none', 'YColor', 'none', 'YDir', 'reverse');
    hold(ax, 'on');
    
    % 3. 绘制三角形外框
    plot(ax, [-nmax_limit, 0, nmax_limit, -nmax_limit], [nmax_limit, 0, nmax_limit, nmax_limit], 'k-', 'LineWidth', 1.2);
    
    % 4. 左侧标签
    if is_left
        set(ax, 'YColor', 'k', 'YTick', 0:10:nmax_limit);
        ylabel(ax, 'degree {\itn}', 'FontWeight', 'bold');
    end
    
    % 5. 底部标签 (与 N2 风格一致)
    if is_bottom
        set(ax, 'XColor', 'k', 'XTick', -nmax_limit:5:nmax_limit);
        xlabel(ax, '{h_n^m}, order({\itm}), {g_n^m}', 'FontSize', 10, 'FontWeight', 'bold');
    end
    
    % 6. 设置范围
    xlim(ax, [-nmax_limit-0.5, nmax_limit+0.5]);
    ylim(ax, [0, nmax_limit+0.5]);
    clim(ax, cfg.cmap_limit);
end