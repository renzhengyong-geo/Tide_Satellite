function Plot_Spectrum_and_Correlation_Comparison_N2_mat()
    % -------------------------------------------------------------------------
    % Purpose: 比较 Ours, HRM2, CM6, Kalman, GO19 与 正演模型 (针对 N2 分潮)
    %          1. 左图: 功率谱对比 (Power Spectrum)
    %          2. 右图: 阶相关系数对比 (Correlation vs Forward)
    % -------------------------------------------------------------------------
    clc; close all;

    %% ========= 1. 参数与文件配置 =========
    % 物理常数
    const.a_radius = 6371.2;  % 地球半径 (km)
    const.N_max    = 40;      % 最大球谐阶数
    
    % 模型文件定义 {文件名, 标签, 表头行数, 线条颜色, 标记符号}
    % 注意：Ours 现在使用 MAT 文件格式
    models = {
        '潮汐磁场结果/Joint_SwarmA_MSS1_EP_Result_N2.mat',                    'Ours',     0,[0.90, 0.10, 0.10], '-*'; 
        'Grayver_result/HRN2.txt',                               'HRM2',     10,[0.00, 0.45, 0.74], '-^'; 
        'CM6/N2.txt',                                            'CM6',      7,  [0.47, 0.67, 0.19], '-s'; 
        'Kalman_result/N2/Model/TIDALN2_MEAN_Radius_6371.2.txt', 'Kalman',   0,[0.49, 0.18, 0.56], '-d'; 
        'GO19/N2.txt',                                           'GO19',     10,[0.93, 0.69, 0.13], '-p'; 
    };

    % 正演参考模型 (Reference) - DAT 格式
    file_Fwd = '正演模拟结果/n2/B_surface.dat'; 
    
    c_Fwd    =[0.2, 0.2, 0.2]; % 深灰

    % 截断阶数 (对应 510 个系数，即 n=1 到 15)
    Max_N = 15;
    
    %% ========= 2. 数据读取 =========
    fprintf('正在读取所有模型数据 (N2 分潮)...\n');
    
    % 读取参考模型 (DAT格式)
    fprintf('  - Loading Forward (DAT format)...\n');
    Dat_Fwd = load_dat_forward_model(file_Fwd, const);
    
    % 读取待评估模型
    num_models = size(models, 1);
    Model_Data = cell(num_models, 1);
    
    for i = 1:num_models
        fname = models{i, 1};
        label = models{i, 2};
        nskip = models{i, 3};
        fprintf('  - Loading %s ...\n', label);
        Model_Data{i} = load_coeffs_robust(fname, label, nskip);
        
        % 检查模型数据完整性
        if ~isempty(Model_Data{i})
            check_coefficient_completeness(Model_Data{i}, Max_N, label);
        end
    end

    %% ========= 3. 计算指标 =========
    fprintf('正在计算功率谱和相关系数...\n');
    [Rn_Fwd, n_vec] = compute_Rn_matrix(Dat_Fwd, Max_N);
    Results = struct('Rn', {}, 'rho', {}, 'label', {}, 'color', {}, 'marker', {});
    
    for i = 1:num_models
        dat = Model_Data{i};
        [rn, ~] = compute_Rn_matrix(dat, Max_N);
        rho = compute_rho_n_aligned(dat, Dat_Fwd, Max_N);
        Results(i).Rn = rn;
        Results(i).rho = rho;
        Results(i).label = models{i, 2};
        Results(i).color = models{i, 4};
        Results(i).marker = models{i, 5};
    end

    %% ========= 4. 绘图 =========
    fig = figure('Units', 'centimeters', 'Position', [5, 5, 17, 9.5], 'Color', 'w');
    t = tiledlayout(1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

    % --- Left Subplot: Power Spectrum ---
    ax1 = nexttile;
    hold(ax1, 'on'); box(ax1, 'on'); grid(ax1, 'on');
    plot(n_vec, Rn_Fwd, '-', 'Color', c_Fwd, 'LineWidth', 2.5, 'DisplayName', 'Forward (N2)');
    for i = 1:num_models
        R = Results(i);
        plot(n_vec, R.Rn, R.marker, 'Color', R.color, 'LineWidth', 1.2, ...
             'MarkerSize', 5, 'MarkerFaceColor', 'w', 'DisplayName', R.label);
    end
    set(ax1, 'YScale', 'log');
    xlim(ax1, [1, Max_N]); xticks(ax1, 1:2:Max_N);
    xlabel(ax1, 'Degree {\itn}', 'FontWeight', 'bold');
    ylabel(ax1, 'Power Spectrum {\itR}_{\itn} (nT^2)', 'FontWeight', 'bold');
    title(ax1, '(a) Power Spectra (N2)', 'FontWeight', 'bold');
    legend(ax1, 'Location', 'southwest', 'FontSize', 7, 'Box', 'off', 'NumColumns', 2);

    % --- Right Subplot: Correlation ---
    ax2 = nexttile;
    hold(ax2, 'on'); box(ax2, 'on'); grid(ax2, 'on');
    for i = 1:num_models
        R = Results(i);
        plot(n_vec, R.rho, R.marker, 'Color', R.color, 'LineWidth', 1.2, ...
             'MarkerSize', 5, 'MarkerFaceColor', 'w', 'DisplayName', R.label);
    end
    xlim(ax2, [1, Max_N]); xticks(ax2, 1:2:Max_N);
    ylim(ax2,[0, 1.05]);
    xlabel(ax2, 'Degree {\itn}', 'FontWeight', 'bold');
    ylabel(ax2, 'Correlation \rho_{\itn}', 'FontWeight', 'bold');
    title(ax2, '(b) Correlation w.r.t Forward (N2)', 'FontWeight', 'bold');
    yline(ax2, 1, '-', 'Color', [0.5 0.5 0.5], 'HandleVisibility', 'off');
    legend(ax2, 'Location', 'best', 'FontSize', 7, 'Box', 'off', 'NumColumns', 2);

    exportgraphics(fig, 'Spectrum_Corr_Comparison_N2.pdf', 'Resolution', 300);
end

%% ========================================================================
%                               核心加载函数修改
%% ========================================================================

function D = load_coeffs_robust(fname, label, nskip)
    if ~isfile(fname), warning('找不到: %s', fname); D =[]; return; end
    
    try
        if contains(fname, '.mat')
            % 调用新编写的处理 MAT 系数的函数
            D = load_ours_mat_result(fname);
        elseif contains(fname, '.csv')
            T = readtable(fname);
            vars = T.Properties.VariableNames;
            idx_n = find(strcmpi(vars, 'n') | strcmpi(vars, 'Degree'), 1);
            idx_m = find(strcmpi(vars, 'm') | strcmpi(vars, 'Order'), 1);
            idx_re = find(strcmpi(vars, 'Real'), 1);
            idx_im = find(strcmpi(vars, 'Imag'), 1);
            if isempty(idx_n), D = T{:, 1:4}; else, D =[T{:, idx_n}, T{:, idx_m}, T{:, idx_re}, T{:, idx_im}]; end
        elseif contains(label, 'Kalman')
            raw = readmatrix(fname);
            D = reconstruct_kalman_structure(raw);
        else
            raw = readmatrix(fname, 'NumHeaderLines', nskip);
            D = raw(:, 1:4);
        end
    catch ME
        warning('%s 读取失败: %s', label, ME.message);
        D =[];
    end
end

function D = load_ours_mat_result(fname)
    % 处理 Joint_SwarmA_MSS1_EP_Result_N2.mat 中的 Result_N2.Coeffs
    % 规则：510x1 向量，奇数为 Re(cos)，偶数为 Im(sin)
    % 阶数顺序：n=1..15, m=[0, 1, -1, 2, -2, ..., n, -n]
    
    data = load(fname);
    coeffs_vec = data.Result_N2.Coeffs;
    
    D = [];
    ptr = 1; % 向量指针
    for n = 1:15
        num_m = 2*n + 1; % 每个阶数 n 对应的 m 数量
        
        % 生成 m 的列表顺序: [0, 1, -1, 2, -2, ..., n, -n]
        m_list = zeros(num_m, 1);
        m_list(1) = 0;
        k = 2;
        for val = 1:n
            m_list(k) = val;
            m_list(k+1) = -val;
            k = k + 2;
        end
        
        % 将对应的复数对填入结果 [n, m, Re, Im]
        for i = 1:num_m
            m = m_list(i);
            re_val = coeffs_vec(ptr);     % 奇数位：cos 项
            im_val = coeffs_vec(ptr + 1); % 偶数位：sin 项
            D = [D; n, m, re_val, im_val];
            ptr = ptr + 2;
        end
    end
end

%% ========================================================================
%                         DAT正演模型读取 (原有逻辑)
%% ========================================================================
function D = load_dat_forward_model(filepath, const)
    if ~isfile(filepath), error('找不到文件: %s', filepath); end
    try
        raw_data = readmatrix(filepath);
        lon = raw_data(:, 1); lat = raw_data(:, 2);
        colat = 90 - lat;
        field_nT = double(raw_data(:, 3)) + 1i * double(raw_data(:, 4));
        r_data = const.a_radius;
        coeffs = sha_solver_vectorized(colat(:), lon(:), field_nT(:), r_data, const);
        D = coeffs_to_standard_format(coeffs, const.N_max);
    catch ME
        error('DAT 文件读取失败: %s', ME.message);
    end
end

function coeffs = sha_solver_vectorized(colat, lon, data, r_data, const)
    N_max = const.N_max; a = const.a_radius;
    n_pts = length(colat); n_coeffs = N_max * (N_max + 2);
    A = zeros(n_pts, n_coeffs); col_idx = 1;
    rad_ratio = a / r_data; cos_colat = cosd(colat);
    for n = 1:N_max
        radial_term = (n + 1) * (rad_ratio)^(n + 2);
        P = legendre(n, cos_colat', 'sch');
        for m = 0:n
            P_nm = P(m+1, :)';
            term_common = radial_term * P_nm;
            if m == 0
                A(:, col_idx) = term_common; col_idx = col_idx + 1;
            else
                A(:, col_idx) = term_common .* cosd(m * lon); col_idx = col_idx + 1;
                A(:, col_idx) = term_common .* sind(m * lon); col_idx = col_idx + 1;
            end
        end
    end
    coeffs = A \ data;
end

function D = coeffs_to_standard_format(coeffs, N_max)
    D =[]; idx = 1;
    for n = 1:N_max
        num_m = 2*n + 1;
        c_n = coeffs(idx : idx + num_m - 1);
        D =[D; n, 0, real(c_n(1)), imag(c_n(1))];
        for m = 1:n
            D =[D; n, m, real(c_n(2*m)), imag(c_n(2*m))];
            D =[D; n, -m, real(c_n(2*m+1)), imag(c_n(2*m+1))];
        end
        idx = idx + num_m;
    end
end

function D = reconstruct_kalman_structure(raw)
    re_vals = raw(:, 1); im_vals = raw(:, 2);
    D =[]; ptr = 1; n = 1;
    while ptr <= length(re_vals)
        num = 2*n + 1;
        if ptr + num - 1 > length(re_vals), break; end
        m_list = [0, reshape([1:n; -(1:n)], 1, [])];
        D = [D; repmat(n, num, 1), m_list', re_vals(ptr:ptr+num-1), im_vals(ptr:ptr+num-1)];
        ptr = ptr + num; n = n + 1;
    end
end

function [Rn, n_list] = compute_Rn_matrix(Data, max_n)
    n_list = (1:max_n)'; Rn = zeros(max_n, 1);
    for k = 1:max_n
        n = n_list(k);
        idx = (Data(:,1) == n);
        if ~any(idx), continue; end
        Rn(k) = (n + 1) * sum(Data(idx, 3).^2 + Data(idx, 4).^2);
    end
end

function rho = compute_rho_n_aligned(E, R, nmax)
    rho = zeros(nmax,1);
    for n = 1:nmax
        Em = []; Rm =[];
        for m = -n:n
            ze = get_iota(E, n, m); zr = get_iota(R, n, m);
            Em = [Em; ze]; Rm = [Rm; zr];
        end
        if sum(abs(Em).^2) < 1e-18 || sum(abs(Rm).^2) < 1e-18, continue; end
        rho(n) = abs(sum(Em .* conj(Rm))) / sqrt(sum(abs(Em).^2) * sum(abs(Rm).^2));
    end
end

function z = get_iota(Data, n, m)
    idx = find(Data(:,1)==n & Data(:,2)==m, 1);
    if isempty(idx), z = 0; else, z = Data(idx, 3) + 1i * Data(idx, 4); end
end

function check_coefficient_completeness(Data, max_n, label)
    found = 0; expected = max_n * (max_n + 2);
    for n = 1:max_n
        for m = -n:n
            if ~isempty(find(Data(:,1)==n & Data(:,2)==m, 1)), found = found + 1; end
        end
    end
    fprintf('  [%s] 完备度检查: %d/%d 个系数已加载\n', label, found, expected);
end