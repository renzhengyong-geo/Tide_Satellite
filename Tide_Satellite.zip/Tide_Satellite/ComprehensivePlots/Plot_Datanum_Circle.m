function Plot_Datanum_Circle()
    % -------------------------------------------------------------------------
    % Purpose: Academic-quality radial time series stacked plot for thesis
    % Optimized for: Full-page thesis figures (single column)
    % Fixes: Correct handling of SAC-C and Ørsted scalar-only gradient data
    % -------------------------------------------------------------------------
    clc; clear; close all;

    % ================= 1. Configuration =================
    dir_data = '卫星残差数据';
    if ~isfolder(dir_data), error('Folder "%s" does not exist', dir_data); end

    % --- Satellite definitions (Thesis-optimized palette) ---
    sat_def = {
        'CHAMP',        [0.400, 0.400, 0.450];  % Dark Gray
        'Ørsted',       [0.851, 0.373, 0.008];  % Deep Orange
        'SAC-C',        [0.957, 0.643, 0.376];  % Light Orange
        'CryoSat-2',    [0.196, 0.533, 0.741];  % Ocean Blue
        'MSS',          [0.769, 0.145, 0.145];  % Crimson Red
        'GF1',          [0.235, 0.596, 0.235];  % Forest Green
        'GF2',          [0.486, 0.753, 0.486];  % Light Green
        'Swarm-A',      [0.031, 0.188, 0.420];  % Navy Blue
        'Swarm-B',      [0.157, 0.392, 0.643];  % Royal Blue
        'Swarm-C',      [0.380, 0.580, 0.800];  % Sky Blue
    };
    
    num_sub_sats = size(sat_def, 1);
    sat_names = sat_def(:,1);
    sat_colors = vertcat(sat_def{:,2});

    % Mapping: generic name -> index array
    map_idx.CHAMP    = 1;
    map_idx.Orsted   = 2;
    map_idx.SACC     = 3;
    map_idx.CryoSat  = 4;
    map_idx.MSS      = 5;
    map_idx.GraceFO  = [6, 7];
    map_idx.Swarm    = [8, 9, 10];

    file_patterns = {'CHAMP', 'Orsted', 'SACC', 'CryoSat', 'MSS', 'GraceFO', 'Swarm'};

    % Data types (4 columns)
    type_labels = {'Vector', 'Scalar', 'Vec-Grad', 'Scl-Grad'};
    num_types = 4;
    
    years = 1999:2025;
    num_years = length(years);

    % ================= 2. Data Statistics (Fixed Logic) =================
    Counts = zeros(num_years, num_types, num_sub_sats);
    
    fprintf('Processing data with fixed scalar gradient detection...\n');
    files = dir(fullfile(dir_data, '*.mat'));
    file_list = {files.name};

    for i = 1:length(file_patterns)
        pattern = file_patterns{i};
        target_indices = map_idx.(pattern);
        
        matches = file_list(contains(file_list, pattern, 'IgnoreCase', true));
        fprintf('  Pattern "%s" -> %d files, indices=[%s]\n', pattern, length(matches), num2str(target_indices));
        
        for k = 1:length(matches)
            try
                fpath = fullfile(dir_data, matches{k});
                D = load(fpath);
                fname = matches{k};
                
                fprintf('    File: %s\n', fname);
                
                % === Type 1: Vector Original ===
                if isfield(D, 'Data_Vector_Orig')
                    fprintf('      -> Data_Vector_Orig found (Type 1)\n');
                    process_field(D.Data_Vector_Orig, 1, target_indices, years);
                end
                
                % === Type 2: Scalar Original ===
                if isfield(D, 'Data_Scalar_Orig')
                    fprintf('      -> Data_Scalar_Orig found (Type 2)\n');
                    process_field(D.Data_Scalar_Orig, 2, target_indices, years);
                end
                
                % === Type 3: Vector Gradient ===
                if isfield(D, 'Data_Vector_Grad')
                    fprintf('      -> Data_Vector_Grad found (Type 3)\n');
                    process_field(D.Data_Vector_Grad, 3, target_indices, years);
                end
                if isfield(D, 'Data_Vector_Cross')
                    fprintf('      -> Data_Vector_Cross found (Type 3)\n');
                    process_field(D.Data_Vector_Cross, 3, target_indices, years);
                end
                
                % === Type 4: Scalar Gradient ===
                if isfield(D, 'Data_Scalar_Grad')
                    fprintf('      -> Data_Scalar_Grad found (Type 4) *** KEY DATA ***\n');
                    process_field(D.Data_Scalar_Grad, 4, target_indices, years);
                end
                if isfield(D, 'Data_Scalar_Cross')
                    fprintf('      -> Data_Scalar_Cross found (Type 4)\n');
                    process_field(D.Data_Scalar_Cross, 4, target_indices, years);
                end
                
            catch ME
                fprintf('  Error reading %s: %s\n', matches{k}, ME.message);
            end
        end
    end
    
    function process_field(S_inner, type_id, indices, yrs)
        % Extract time
        t = [];
        if isfield(S_inner, 'Time')
            t = S_inner.Time;
        elseif isfield(S_inner, 'Time1')
            t = S_inner.Time1;
        end
        
        if isempty(t)
            fprintf('        WARNING: No time data found!\n');
            return;
        end
        
        % CRITICAL FIX: Detect and convert absolute MJD to MJD2000
        % MJD (Modified Julian Date) for 2000-01-01 12:00 UTC is 51544.5
        % MJD2000 is days since 2000-01-01 00:00 UTC
        % If time values are > 50000, they're likely absolute MJD, not MJD2000
        if min(t) > 50000
            fprintf('        Detected absolute MJD format (min=%.2f)\n', min(t));
            % For Ørsted/SAC-C gradient data which appear to be in a different epoch
            % Let's check if this is GPS time or another reference
            % GPS time starts 1980-01-06, which is MJD 44244
            % If the range is ~730000, this might be Excel serial date!
            % Excel serial date 1 = 1900-01-01, but accounting for leap year bug
            % Excel date 730194 ≈ 2000-01-01
            if min(t) > 700000
                fprintf('        Converting from Excel serial date to MJD2000...\n');
                % Excel serial date for 2000-01-01 is 36526 (accounting for 1900 bug)
                % Actually, let's use the proper conversion:
                % Excel 730194 should map to around year 2000
                % So: MJD2000 = Excel_date - 730119.5 (Excel date for 2000-01-01 00:00)
                t = t - 730486;
            else
                fprintf('        Converting from absolute MJD to MJD2000...\n');
                t = t - 51544.0;
            end
            fprintf('        After conversion, range=[%.2f, %.2f]\n', min(t), max(t));
        end
        
        fprintf('        Time data: %d records, range=[%.2f, %.2f]\n', ...
                length(t), min(t), max(t));
        
        % Extract SatID
        sat_ids = [];
        if isfield(S_inner, 'SatID')
            sat_ids = S_inner.SatID;
        end
        
        % Logic branching
        if length(indices) == 1
            % Single satellite: add all data
            c = hist_years(t, yrs);
            Counts(:, type_id, indices) = Counts(:, type_id, indices) + c;
            fprintf('        Added %.2fM records to satellite %d, type %d\n', sum(c)/1e6, indices, type_id);
        else
            % Multi-satellite mission
            if isempty(sat_ids)
                % No SatID (e.g., Cross data) -> assign to primary satellite
                c = hist_years(t, yrs);
                Counts(:, type_id, indices(1)) = Counts(:, type_id, indices(1)) + c;
            else
                % Split by SatID
                u_ids = unique(sat_ids);
                for uid = u_ids'
                    mask = (sat_ids == uid);
                    t_sub = t(mask);
                    if uid <= length(indices)
                        g_idx = indices(uid);
                        c = hist_years(t_sub, yrs);
                        Counts(:, type_id, g_idx) = Counts(:, type_id, g_idx) + c;
                        fprintf('        Added %.2fM records to satellite %d (SatID=%d), type %d\n', sum(c)/1e6, g_idx, uid, type_id);
                    end
                end
            end
        end
    end

    Counts = Counts / 1e6; % Convert to millions
    
    fprintf('\n=== Data Summary ===\n');
    for s = 1:num_sub_sats
        total = sum(Counts(:,:,s), 'all');
        fprintf('%10s: %.2f M records\n', sat_names{s}, total);
    end

    % ================= 3. Thesis-Quality Visualization =================
    fprintf('\nGenerating thesis-quality figure...\n');
    
    % Large format for thesis (full page, ~20cm width)
    fig = figure('Color', 'w', 'Units', 'centimeters', 'Position', [1, 1, 16.5, 16.5]);
    ax = axes(fig);
    hold(ax, 'on');
    axis equal; axis off;
    
    % Set renderer for best quality
    set(fig, 'Renderer', 'painters');

    % --- Parameters ---
    total_per_year_type = sum(Counts, 3);
    max_val = max(total_per_year_type(:));
    if max_val < 0.1, max_val = 1; end
    
    inner_r = 12; 
    scale_f = 13 / max_val; 
    
    start_angle = pi/2 + pi/num_years; 
    total_angle = 2*pi * 0.90;
    angle_step = total_angle / num_years;
    
    group_padding = angle_step * 0.12;
    bar_width_angle = (angle_step - 2*group_padding) / num_types;

    % --- A. Enhanced Grid System ---
    draw_thesis_grid(inner_r, scale_f, max_val, start_angle, total_angle, years);

    % --- B. Stacked Bar Chart ---
    for y = 1:num_years
        year_ang_start = start_angle - (y-1) * angle_step;
        
        for t = 1:num_types
            theta_s = year_ang_start - group_padding - (t-1)*bar_width_angle;
            theta_e = theta_s - bar_width_angle * 0.88;
            
            current_r = inner_r;
            
            for s = 1:num_sub_sats
                val = Counts(y, t, s);
                
                if val > 0.001
                    h = val * scale_f;
                    draw_thesis_sector(theta_s, theta_e, current_r, current_r + h, ...
                                      sat_colors(s,:), 0.92);
                    current_r = current_r + h;
                end
            end
        end
    end
    
    % --- C. Thesis Legend Layout (Larger, Clearer) ---
    
    % Satellite legend (left side)
    lx = -30; ly = 33;
    text(lx, ly+1.5, 'Satellites', 'FontWeight', 'bold', 'FontSize', 12, ...
          'Color', [0.15 0.15 0.15]);
    
    leg_box_size = 1.0;
    leg_spacing = 1.8;
    
    for s = 1:num_sub_sats
        if s <= 5
            col_offset = 0; 
            row_offset = s;
        else
            col_offset = 11; 
            row_offset = s - 5;
        end
        
        px = lx + col_offset; 
        py = ly - 1.0 - (row_offset-1)*leg_spacing;
        
        % Legend box with border
        rectangle('Position', [px, py-leg_box_size, leg_box_size, leg_box_size], ...
                 'FaceColor', sat_colors(s,:), 'EdgeColor', [0.2 0.2 0.2], ...
                 'LineWidth', 0.8);
        
        % Calculate total for this satellite
        sat_total = sum(Counts(:,:,s), 'all');
        
        text(px+leg_box_size+0.4, py-leg_box_size/2, ...
             sprintf('%s ', sat_names{s}), ...
             'FontSize', 10, 'VerticalAlignment', 'middle');
    end
    
    % Data type legend (right side)
    rx = 21; ry = 33;
    text(rx, ry+1.5, 'Data Types', 'FontWeight', 'bold', 'FontSize', 12, ...
         'Color', [0.15 0.15 0.15]);
    
    % Calculate totals for each type
    type_totals = squeeze(sum(sum(Counts, 1), 3));
    
    for t = 1:num_types
        py = ry - 1.0 - (t-1)*leg_spacing;
        
        % Type indicator bar
        plot([rx, rx+1.0], [py-0.5, py-0.5], '-', 'Color', [0.3 0.3 0.3], ...
             'LineWidth', 4);
        
        text(rx+1.5, py-0.5, sprintf('%s (%.1fM)', type_labels{t}, type_totals(t)), ...
             'FontSize', 10, 'VerticalAlignment', 'middle');
    end
    
    % Center annotation
    text(0, 1.3, 'Data Volume', 'HorizontalAlignment', 'center', ...
         'FontSize', 12, 'FontWeight', 'bold', 'Color', [0.2 0.2 0.2] ...
         );
    text(0, -0.7, '(×10^6 records)', 'HorizontalAlignment', 'center', ...
         'FontSize', 10, 'Color', [0.4 0.4 0.4]);

    % Set view limits
    lim = 33;
    xlim([-lim, lim]); ylim([-lim, lim]);
    
    % Export in high quality formats
    exportgraphics(fig, 'Radial_Data_Thesis.png', 'Resolution', 600);
    exportgraphics(fig, 'Radial_Data_Thesis.pdf', 'Resolution', 600);
    % exportgraphics(fig, 'Radial_Data_Thesis.eps', 'ContentType', 'vector');
    
    fprintf('\nThesis-quality figures saved:\n');
    fprintf('  ✓ Radial_Data_Thesis.png (600 DPI raster)\n');
    fprintf('  ✓ Radial_Data_Thesis.pdf (vector)\n');
    fprintf('  ✓ Radial_Data_Thesis.eps (vector, LaTeX compatible)\n');
end

% ================= Helper Functions =================

function counts = hist_years(t_mjd, target_years)
    counts = zeros(length(target_years), 1);
    if isempty(t_mjd), return; end
    
    % Convert MJD2000 to year
    y_val = 2000 + t_mjd / 365.25;
    y_int = floor(y_val);
    
    % Debug: show year range
    fprintf('          Year range: [%d, %d]\n', min(y_int), max(y_int));
    
    valid_y = y_int(y_int >= min(target_years) & y_int <= max(target_years));
    if isempty(valid_y)
        fprintf('          WARNING: No valid years in range [%d, %d]!\n', ...
                min(target_years), max(target_years));
        return;
    end
    
    % Count occurrences
    tbl = tabulate(valid_y);
    if isempty(tbl), return; end
    
    vals = tbl(:,1);
    freqs = tbl(:,2);
    
    [~, loc] = ismember(vals, target_years);
    valid_locs = loc(loc>0);
    counts(valid_locs) = freqs(loc>0);
    
    fprintf('          Counted %d valid records\n', sum(counts));
end

function draw_thesis_sector(t1, t2, r1, r2, col, alpha_val)
    % High-resolution sector for thesis quality
    t = linspace(t1, t2, 40);
    x = [r1*cos(t), r2*cos(fliplr(t))];
    y = [r1*sin(t), r2*sin(fliplr(t))];
    
    % Draw with subtle edge
    patch(x, y, col, 'EdgeColor', [1 1 1]*0.93, 'LineWidth', 0.4, ...
          'FaceAlpha', alpha_val);
end

function draw_thesis_grid(r0, scale, max_val, start_ang, total_ang, years)
    % Professional grid system for thesis
    
    % Radial grid lines
    levels = [0.5, 1, 2, 5, 10, 20, 50, 100];
    levels = levels(levels <= max_val);
    if isempty(levels)
        levels = linspace(0, max_val, 4); 
        levels(1) = [];
    end
    
    theta = linspace(start_ang, start_ang - total_ang, 500);
    
    for l = levels
        r = r0 + l * scale;
        plot(r*cos(theta), r*sin(theta), '-', 'Color', [0.82 0.82 0.82], ...
             'LineWidth', 0.8);
        
        % Grid labels
        ang_label = start_ang + 0.10;
        text(r*cos(ang_label), r*sin(ang_label), sprintf('%.1f', l), ...
            'FontSize', 9, 'Color', [0.45 0.45 0.45], 'FontName', 'Helvetica', ...
            'HorizontalAlignment', 'left', 'FontWeight', 'bold');
    end
    
    % Year dividers and labels
    n = length(years);
    step = total_ang / n;
    
    for i = 1:n
        ang = start_ang - (i-1)*step;
        r_out = r0 + max_val*scale + 2.0;
        
        % Radial separator lines
        plot([r0*cos(ang), r_out*cos(ang)], [r0*sin(ang), r_out*sin(ang)], ...
             '-', 'Color', [0.88 0.88 0.88], 'LineWidth', 0.7);
         
        % Year labels
        mid = ang - step/2;
        label_r = r_out + 2.0;
        deg = rad2deg(mid);
        rot = deg - 90;
        
        text(label_r*cos(mid), label_r*sin(mid), num2str(years(i)), ...
            'HorizontalAlignment', 'center', 'Rotation', rot, ...
            'FontSize', 11, 'FontWeight', 'bold', ...
            'Color', [0.15 0.15 0.15]);
    end
    
    % Outer boundary circle
    theta_full = linspace(0, 2*pi, 600);
    r_outer = r0 + max_val*scale + 0.8;
    plot(r_outer*cos(theta_full), r_outer*sin(theta_full), '-', ...
         'Color', [0.6 0.6 0.6], 'LineWidth', 1.2);
end