clear; clc; close all;

%% 1. 全局视觉配置
colorMap = containers.Map();
% 高对比度科研配色
colorMap('CHAMP')      = [0.00, 0.27, 0.60]; % 普鲁士蓝
colorMap('SAC-C')      = [0.35, 0.50, 0.70]; % 钢蓝
colorMap('CryoSat')    = [0.90, 0.45, 0.05]; % 安全橙
colorMap('MSS')        = [0.95, 0.75, 0.00]; % 信号黄
colorMap('Grace-FO 1') = [0.00, 0.50, 0.25]; % 森林绿
colorMap('Grace-FO 2') = [0.40, 0.75, 0.35]; % 叶绿
colorMap('Orsted')     = [0.55, 0.25, 0.65]; % 皇家紫
colorMap('Swarm A')    = [0.00, 0.65, 0.85]; % 蔚蓝
colorMap('Swarm B')    = [0.85, 0.15, 0.45]; % 绯红
colorMap('Swarm C')    = [0.20, 0.50, 0.90]; % 钴蓝

% fontName = 'Arial'; 
baseFontSize = 10;
axisLineWidth = 1.0;
RE = 6371.2; 

% === 关键参数：垂直夸张因子 ===
% 这会让卫星轨道看起来离地球更远，从而拉开轨道间的距离
% visual_radius = R_Earth + Altitude * ExaggerationFactor
ExagFactor = 6.0; 

%% 2. 文件列表
fileList = {
    '卫星残差数据/CHAMP_Modeling_Input_Abs.mat', 'CHAMP';
    '卫星残差数据/CryoSat_Input_Original_Weighted.mat', 'CryoSat';
    '卫星残差数据/GraceFO_ACC_Input_Original_Weighted.mat', 'Grace-FO';
    '卫星残差数据/MSS_Input_Original_Weighted.mat', 'MSS';
    '卫星残差数据/Orsted_ACC_Input_Original_Scalar.mat', 'Orsted';
    '卫星残差数据/SACC_ACC_Input_Original_Scalar.mat', 'SAC-C';
    '卫星残差数据/Swarm_ACC_Input_Original_Weighted.mat', 'Swarm'
};

SatData = struct([]);
satCount = 0;

%% 3. 数据处理
fprintf('正在读取并处理数据...\n');

for i = 1:size(fileList, 1)
    filePath = fileList{i, 1};
    missionName = fileList{i, 2};
    if ~isfile(filePath), continue; end
    
    raw = load(filePath);
    dStruct = [];
    if isfield(raw, 'Data_Vector_Orig'), dStruct = raw.Data_Vector_Orig;
    elseif isfield(raw, 'Data_Scalar_Orig'), dStruct = raw.Data_Scalar_Orig;
    elseif isfield(raw, 'Data_Scalar_Abs'), dStruct = raw.Data_Scalar_Abs;
    end
    if isempty(dStruct), continue; end
    
    if isfield(dStruct, 'SatID'), uIDs = unique(dStruct.SatID); else, uIDs = 1; dStruct.SatID = ones(size(dStruct.Time)); end
    
    for k = 1:length(uIDs)
        sid = uIDs(k);
        idx = (dStruct.SatID == sid);
        if sum(idx) < 100, continue; end
        
        t_raw_mjd = dStruct.Time(idx);
        pos_raw = dStruct.Pos(idx, :); 
        alt_raw = pos_raw(:, 1) - RE;
        
        satCount = satCount + 1;
        
        finalName = missionName;
        if strcmp(missionName, 'Swarm')
            subN = {'Swarm A', 'Swarm B', 'Swarm C'}; 
            if sid<=3, finalName = subN{sid}; end
        elseif strcmp(missionName, 'Grace-FO')
            subN = {'Grace-FO 1', 'Grace-FO 2'}; 
            if sid<=2, finalName = subN{sid}; end
        end
        
        if isKey(colorMap, finalName), thisColor = colorMap(finalName); else, thisColor = [0.5 0.5 0.5]; end
        
        t_months = dateshift(datetime(2000,1,1)+days(t_raw_mjd), 'start', 'day');
        [G, t_unique] = findgroups(t_months);
        alt_monthly_mean = splitapply(@mean, alt_raw, G);
        alt_kde = alt_raw(1:20:end);
        
        % 3D 剖面数据准备
        step_3d = 50; 
        p_sub = pos_raw(1:step_3d:end, :);
        phi_rad = deg2rad(p_sub(:, 3));
        theta_rad = deg2rad(p_sub(:, 2)); 
        
        % === 关键步骤：应用垂直夸张 ===
        % 保持角度不变，只修改半径
        real_alt = p_sub(:, 1) - RE;
        vis_R = RE + real_alt * ExagFactor; % 放大高度差
        
        [x, y, z] = sph2cart(phi_rad, pi/2 - theta_rad, vis_R);
        
        % 保存原始球坐标用于插值
        % Col 1: Visual Radius, Col 2: Latitude (rad), Col 3: Real Altitude
        p_sph_vis = [vis_R, pi/2 - theta_rad, real_alt]; 
        
        SatData(satCount).name = finalName;
        SatData(satCount).color = thisColor;
        SatData(satCount).pos3d = [x, y, z];      % 用于判断位置
        SatData(satCount).pos_sph = p_sph_vis;    % 用于绘图
        SatData(satCount).t_month = t_unique;
        SatData(satCount).alt_month = alt_monthly_mean;
        SatData(satCount).alt_kde = alt_kde;
    end
end

% 排序
mean_alts = zeros(1, length(SatData));
for i=1:length(SatData), mean_alts(i) = mean(SatData(i).alt_month); end
[~, sort_idx] = sort(mean_alts, 'ascend');
SatData = SatData(sort_idx);

%% 4. 绘图与可视化
fig = figure('Color', 'w', 'Units', 'centimeters', 'Position', [2, 2, 16.5, 14]); 
tlo = tiledlayout(2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

% =========================================================================
% (a) Schematic Orbital Profile (Schematic + Data)
% =========================================================================
ax1 = nexttile(1, [2, 1]);
hold(ax1, 'on');

% --- 1. 绘制地球内部结构 (Schematic) ---
theta = linspace(-pi/2, pi/2, 300);

% 1.1 地核 (Core) - 深灰色
R_Core = RE * 0.5;
fill(ax1, R_Core*cos(theta), R_Core*sin(theta), [0.85 0.85 0.85], 'EdgeColor', 'none');
text(ax1, 0, 0, 'Core', 'HorizontalAlignment', 'right', 'Color', [0.6 0.6 0.6], 'FontSize', 9);

% 1.2 地幔 (Mantle) - 浅灰色
R_Mantle = RE * 0.95; 
% 构建环形填充
X_mantle = [R_Mantle*cos(theta), fliplr(R_Core*cos(theta))];
Y_mantle = [R_Mantle*sin(theta), fliplr(R_Core*sin(theta))];
fill(ax1, X_mantle, Y_mantle, [0.95 0.95 0.95], 'EdgeColor', [0.8 0.8 0.8]);

% 1.3 海洋层 (Ocean Layer) - 浅蓝色带
R_Ocean = RE; 
X_ocean = [R_Ocean*cos(theta), fliplr(R_Mantle*cos(theta))];
Y_ocean = [R_Ocean*sin(theta), fliplr(R_Mantle*sin(theta))];
fill(ax1, X_ocean, Y_ocean, [0.85 0.92 0.98], 'EdgeColor', [0.2 0.5 0.8]); % 海水蓝

% --- 2. 绘制海洋磁场示意图 (Schematic) ---

% 2.1 绘制洋流 (Currents) - 蓝色箭头
% 在不同纬度画几个箭头表示海水流动
arrow_lats = [-60, -30, 0, 30, 60];
for lat = arrow_lats
    lat_rad = deg2rad(lat);
    % 箭头位置
    ax_x = RE * 0.98 * cos(lat_rad);
    ax_y = RE * 0.98 * sin(lat_rad);
    % 画一个小圆点表示电流流出/流入
    plot(ax1, ax_x, ax_y, 'o', 'Color', [0.1 0.4 0.7], 'MarkerSize', 4, 'MarkerFaceColor', [0.1 0.4 0.7]);
end

% 2.2 绘制感应磁场 (Induced Magnetic Field) - 红色/紫色虚线圈
% 模拟从海洋表面发出的磁力线环
for lat = [-45, 0, 45]
    lat_rad = deg2rad(lat);
    cx = RE * cos(lat_rad);
    cy = RE * sin(lat_rad);
    
    % 画几个椭圆环代表磁力线
    t_loop = linspace(0, pi, 50);
    loop_h = 400 * ExagFactor; % 磁力线高度 (视觉夸张)
    loop_w = 600;              % 磁力线宽度 (km)
    
    % 简单的参数方程模拟磁力线环
    % 这里的数学是为了视觉效果，模拟偶极子形态
    Lx = (RE + loop_h * sin(t_loop)) .* cos(lat_rad + deg2rad(10)*cos(t_loop));
    Ly = (RE + loop_h * sin(t_loop)) .* sin(lat_rad + deg2rad(10)*cos(t_loop));
    
    plot(ax1, Lx, Ly, ':', 'Color', [0.8 0.4 0.4], 'LineWidth', 0.8);
end
text(ax1, RE*0.65, 0, {'Ocean Induced', 'Magnetic Field'}, ...
    'Color', [0.8 0.4 0.4], 'FontSize', 8, 'HorizontalAlignment', 'center');


% --- 3. 绘制参考高度网格线 (尺子) ---
% 使用夸张后的半径
ref_alts = [300, 500, 700];
for ra = ref_alts
    vis_r = RE + ra * ExagFactor;
    plot(ax1, vis_r*cos(theta), vis_r*sin(theta), '--', ...
        'Color', [0.6 0.6 0.6], 'LineWidth', 0.8);
    
    % 标注高度 (加上 "km")
    text(ax1, vis_r*cos(deg2rad(92)), vis_r*sin(deg2rad(90)), sprintf('  %d ', ra), ...
        'FontSize', 8, 'Color', [0.4 0.4 0.4],  'Rotation', 0);
end

% 地轴
plot(ax1, [0 0], [-(RE + 900*ExagFactor), RE + 900*ExagFactor], '-.', ...
    'Color', [0.6 0.6 0.6], 'LineWidth', 1);

% --- 4. 绘制卫星轨道线段 (插值 & 夸张) ---
for i = 1:length(SatData)
    p3 = SatData(i).pos3d;
    p_sph = SatData(i).pos_sph; % [Vis_R, Lat_rad, Real_Alt]
    col = SatData(i).color;
    name = SatData(i).name;
    
    if ~isempty(p3)
        % 切片逻辑
        slice_thickness = 400; 
        idx_keep = (p3(:, 1) > 0) & (abs(p3(:, 2)) < slice_thickness);
        p_sph_cut = p_sph(idx_keep, :);
        
        if size(p_sph_cut, 1) > 5
            % 按纬度排序
            [~, sort_idx] = sort(p_sph_cut(:, 2)); 
            p_sorted = p_sph_cut(sort_idx, :);
            
            % 转回笛卡尔坐标用于绘图 (X=Radius*cos(lat), Y=Radius*sin(lat))
            % 注意：这里用 Vis_R
            X_plot = p_sorted(:, 1) .* cos(p_sorted(:, 2));
            Y_plot = p_sorted(:, 1) .* sin(p_sorted(:, 2));
            
            if contains(name, 'MSS')
                plot(ax1, X_plot, Y_plot, '-', 'Color', col, 'LineWidth', 3.0);
                % 加个光晕点
                scatter(ax1, X_plot(end/2), Y_plot(end/2), 60, col, 'filled', 'MarkerFaceAlpha', 0.5);
            else
                plot(ax1, X_plot, Y_plot, '-', 'Color', [col, 0.7], 'LineWidth', 1.5);
            end
        end
    end
end

axis(ax1, 'equal'); axis(ax1, 'off');
% 调整可视范围：保证能看到夸张后的最外层轨道
max_vis_R = RE + 850 * ExagFactor;
xlim(ax1, [-500, max_vis_R + 1000]); 
ylim(ax1, [-max_vis_R - 500, max_vis_R + 500]);

text(ax1, 0, max_vis_R + 400, 'N', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
text(ax1, 0, -max_vis_R - 400, 'S', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');

title(ax1, {'(a) Schematic Orbital Profile';}, ...
     'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');

% =========================================================================
% (b) PDF
% =========================================================================
ax2 = nexttile(2);
hold(ax2, 'on');

for i = 1:length(SatData)
    alt = SatData(i).alt_kde;
    col = SatData(i).color;
    val = alt(alt > 200 & alt < 1000);
    if length(val) > 500
        [f, xi] = ksdensity(val, 'Bandwidth', 6);
        fill(ax2, xi, f, col, 'FaceAlpha', 0.3, 'EdgeColor', col, 'LineWidth', 1.2);
    end
end

grid(ax2, 'on'); box(ax2, 'on');
ax2.LineWidth = axisLineWidth; ax2.TickDir = 'out';
% ax2.FontName = fontName; 
ax2.FontSize = baseFontSize;
xlabel(ax2, 'Altitude (km)',  'FontWeight', 'bold');
ylabel(ax2, 'PDF',  'FontWeight', 'bold');
xlim(ax2, [250, 900]);
title(ax2, '(b) Altitude Distribution',  'FontSize', 11, 'FontWeight', 'bold');

% =========================================================================
% (c) Evolution with F10.7 背景
% =========================================================================
ax3 = nexttile(4);
hold(ax3, 'on');

% --- 读取并处理 F10.7 数据 ---
F107_time = [];
F107_adj = [];

% 1. 读取新文件 fluxtable_now.txt (2004年之后)
if isfile('fluxtable_now.txt')
    try
        fid = fopen('fluxtable_now.txt', 'r');
        % 跳过头部注释行
        tline = fgetl(fid);
        while ischar(tline) && (contains(tline, 'fluxdate') || contains(tline, '---'))
            tline = fgetl(fid);
        end
        
        % 读取数据
        data_new = [];
        while ischar(tline)
            parts = strsplit(strtrim(tline));
            if length(parts) >= 6
                dateStr = parts{1};  % yyyymmdd
                adjFlux = str2double(parts{6}); % fluxadjflux
                if ~isnan(adjFlux) && adjFlux > 0
                    year = str2double(dateStr(1:4));
                    month = str2double(dateStr(5:6));
                    day = str2double(dateStr(7:8));
                    dt = datetime(year, month, day);
                    data_new = [data_new; datenum(dt), adjFlux];
                end
            end
            tline = fgetl(fid);
        end
        fclose(fid);
        
        if ~isempty(data_new)
            F107_time = [F107_time; data_new(:,1)];
            F107_adj = [F107_adj; data_new(:,2)];
        end
    catch
        warning('无法读取 fluxtable_now.txt');
    end
end

% =========================================================================
% (c) Evolution with F10.7 背景
% =========================================================================
ax3 = nexttile(4);
hold(ax3, 'on');

% --- 读取并处理 F10.7 数据 ---
F107_time = [];
F107_adj = [];

% 1. 读取新文件 fluxtable_now.txt (2004年之后)
if isfile('fluxtable_now.txt')
    try
        fid = fopen('fluxtable_now.txt', 'r');
        % 跳过头部注释行
        tline = fgetl(fid);
        while ischar(tline) && (contains(tline, 'fluxdate') || contains(tline, '---'))
            tline = fgetl(fid);
        end
        
        % 读取数据
        data_new = [];
        while ischar(tline)
            parts = strsplit(strtrim(tline));
            if length(parts) >= 6
                dateStr = parts{1};  % yyyymmdd
                adjFlux = str2double(parts{6}); % fluxadjflux
                if ~isnan(adjFlux) && adjFlux > 0
                    year = str2double(dateStr(1:4));
                    month = str2double(dateStr(5:6));
                    day = str2double(dateStr(7:8));
                    dt = datetime(year, month, day);
                    data_new = [data_new; datenum(dt), adjFlux];
                end
            end
            tline = fgetl(fid);
        end
        fclose(fid);
        
        if ~isempty(data_new)
            F107_time = [F107_time; data_new(:,1)];
            F107_adj = [F107_adj; data_new(:,2)];
        end
    catch
        warning('无法读取 fluxtable_now.txt');
    end
end

% 2. 读取旧文件 flux_old.txt (2004年之前)
if isfile('flux_old.txt')
    try
        fid = fopen('flux_old.txt', 'r');
        tline = fgetl(fid);
        
        while ischar(tline)
            parts = strsplit(strtrim(tline));
            
            if length(parts) >= 2
                % 有日期和数值
                dateStr = parts{1};
                fluxVal = str2double(parts{2});
                
                if length(dateStr) == 8 && ~isnan(fluxVal) && fluxVal > 0
                    year = str2double(dateStr(1:4));
                    month = str2double(dateStr(5:6));
                    day = str2double(dateStr(7:8));
                    
                    try
                        dt = datetime(year, month, day);
                        % 只添加2004年之前的数据，避免重复
                        if dt < datetime(2004, 10, 28)
                            dn = datenum(dt);
                            F107_time = [F107_time; dn];
                            F107_adj = [F107_adj; fluxVal];
                        end
                    catch
                        % 跳过无效日期
                    end
                end
            end
            % 如果只有日期没有数值，直接跳过
            tline = fgetl(fid);
        end
        fclose(fid);
    catch
        warning('无法读取 flux_old.txt');
    end
end

% 3. 合并并排序数据
if ~isempty(F107_time)
    [F107_time, idx] = sort(F107_time);
    F107_adj = F107_adj(idx);
    
    % 转换为 datetime
    F107_datetime = datetime(F107_time, 'ConvertFrom', 'datenum');
    
    % 按月平均
    F107_monthly = retime(timetable(F107_datetime, F107_adj), 'monthly', 'mean');
    
    % 筛选时间范围 (2000-2026)
    time_mask = F107_monthly.F107_datetime >= datetime(2000,1,1) & ...
                F107_monthly.F107_datetime <= datetime(2026,1,1);
    F107_t = F107_monthly.F107_datetime(time_mask);
    F107_v = F107_monthly.F107_adj(time_mask);
    
    % 绘制 F10.7 作为山峦底座（使用右侧坐标轴）
    yyaxis(ax3, 'right');
    % 使用 area 绘制填充区域，透明度较低
    h_area = area(ax3, F107_t, F107_v, 'FaceColor', [0.95, 0.85, 0.7], ...
                  'FaceAlpha', 0.3, 'EdgeColor', [0.8, 0.6, 0.3], ...
                  'LineWidth', 1.2, 'LineStyle', '-');
    ylabel(ax3, 'F_{10.7} Solar Flux (SFU)',  'FontWeight', 'bold');
    ylim(ax3, [50, 250]); % F10.7 典型范围
    ax3.YColor = [0.7, 0.5, 0.2]; % 设置右侧Y轴颜色
end

% --- 绘制卫星高度曲线（使用左侧坐标轴）---
yyaxis(ax3, 'left');
legendHandles = [];

% 为不同卫星设置不同的线型，增强区分度
lineStyles = {'-'};

for i = 1:length(SatData)
    t = SatData(i).t_month;
    alt = SatData(i).alt_month;
    col = SatData(i).color;
    name = SatData(i).name;
    if length(t) > 3
        % 统一调整线宽，科技论文推荐线宽范围
        if contains(name, 'MSS')
            lw = 1.2; % 重点卫星，稍微粗一些
        else
            lw = 0.8; % 其他卫星，统一线宽
        end
        % 循环使用不同线型
        ls_idx = mod(i-1, length(lineStyles)) + 1;
        ls = lineStyles{ls_idx};
        hLine = plot(ax3, t, alt, ls, 'Color', col, 'LineWidth', lw);
        legendHandles = [legendHandles; hLine]; 
    end
end

grid(ax3, 'on'); box(ax3, 'on');
ax3.LineWidth = axisLineWidth; ax3.TickDir = 'out';
% ax3.FontName = fontName; 
ax3.FontSize = baseFontSize;
xlabel(ax3, 'Year', 'FontWeight', 'bold');
ylabel(ax3, 'Altitude (km)', 'FontWeight', 'bold');
xlim(ax3, [datetime(2000,1,1), datetime(2026,1,1)]);
xtickformat('yyyy')
ylim(ax3, [250, 850]);
ax3.YColor = 'k'; % 设置左侧Y轴为黑色
title(ax3, '(c) Altitude Evolution',  'FontSize', 11, 'FontWeight', 'bold');

% Legend
names = {SatData.name};
hL = legend(legendHandles, names, 'Orientation', 'horizontal', 'NumColumns', 5);
hL.Layout.Tile = 'south'; hL.Box = 'off'; 
% hL.FontName = fontName;
hL.FontSize = 9;
exportgraphics(fig, '轨道高度演化.pdf', 'Resolution', 600);
% set(findall(gcf, '-property', 'FontName'));