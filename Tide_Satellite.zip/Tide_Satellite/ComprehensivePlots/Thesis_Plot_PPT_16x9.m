function Thesis_Plot_PPT_16x9()
    % -------------------------------------------------------------------------
    % Purpose: PPT展示版 (16:9宽屏) — 4 Rows × 8 Columns
    % Layout:
    %   Rows:    Br | Bt | Bp | σ
    %   Cols:    CHAMP | Ørsted | SAC-C | GRACE-FO | CryoSat-2 | MSS | Swarm | Forward
    % 正演行(Fwd)第4格(σ)留空
    % -------------------------------------------------------------------------
    clc; clear; close all;

    % =========================== 0. 路径配置 ===========================
    dir_results = '潮汐磁场结果';
    dir_error   = '误差文件';

    fwd_file = '正演模拟结果/KUV_RES_0001.h5';
    fwd_const.a_radius = 6371.2;
    fwd_const.N_max    = 40;

    sat_config = {
        'CHAMP',     'CHAMP_SH_Coefficients_With_Errors.csv',      'CHAMP_Full_Inversion_Result.mat';
        'Ørsted',    'Orsted_SH_Coefficients_With_Errors.csv',     'Orsted_Full_Inversion_Result_Scalar.mat';
        'SAC-C',     'SACC_SH_Coefficients_With_Errors.csv',       'SACC_Full_Inversion_Result_Scalar.mat';
        'GRACE-FO',  'GraceFO_SH_Coefficients_base_ssg_csg.csv',   'GraceFO_Full_Inversion_Result.mat';
        'CryoSat-2', 'CryoSat_SH_Coefficients_With_Errors.csv',    'CryoSat_Full_Inversion_Result.mat';
        'MSS',       'MSS_SH_Coefficients_With_Errors.csv',        'MSS_Full_Inversion_Result.mat';
        'Swarm',     'Swarm_SH_Coefficients_With_Errors.csv',      'Swarm_Full_Inversion_Result.mat';
    };

    num_sats = size(sat_config, 1);
    num_cols = num_sats + 1;   % 8 列: 7卫星 + 正演
    num_rows = 4;              % Br, Bt, Bp, σ
    alt_km = 450;

    % =========================== 预加载所有数据 ===========================
    fprintf('正在加载卫星数据...\n');
    sat_data  = cell(num_sats, 1);
    sat_error = cell(num_sats, 1);
    sat_names = cell(num_sats, 1);

    for i = 1:num_sats
        sat_names{i} = sat_config{i, 1};
        csv_file = fullfile(dir_results, sat_config{i, 2});
        err_file = fullfile(dir_error,   sat_config{i, 3});

        [LON, LAT, Br, Bt, Bp] = synthesize_sh_field_v12(csv_file, alt_km);
        [Map_Error, ~]          = calculate_error_map_fixed(err_file, alt_km);

        if strcmp(sat_names{i}, 'MSS')
            mask = abs(LAT) > 50;
            Br(mask) = NaN; Bt(mask) = NaN; Bp(mask) = NaN; Map_Error(mask) = NaN;
        end

        sat_data{i}  = struct('LON', LON, 'LAT', LAT, 'Br', Br, 'Bt', Bt, 'Bp', Bp);
        sat_error{i} = Map_Error;
    end

    fprintf('正在加载正演模型...\n');
    Dat_Fwd = load_h5_forward_model(fwd_file, fwd_const);
    [LON_fwd, LAT_fwd] = meshgrid(0:2:360, -89:2:89);
    cfg_fwd.a_radius = fwd_const.a_radius;
    cfg_fwd.N_max    = fwd_const.N_max;

    [Br_fwd, ~] = synthesize_complex_map(Dat_Fwd, alt_km, 'Br', LON_fwd, LAT_fwd, cfg_fwd);
    [Bt_fwd, ~] = synthesize_complex_map(Dat_Fwd, alt_km, 'Bt', LON_fwd, LAT_fwd, cfg_fwd);
    [Bp_fwd, ~] = synthesize_complex_map(Dat_Fwd, alt_km, 'Bp', LON_fwd, LAT_fwd, cfg_fwd);

    fwd_comp = {Br_fwd, Bt_fwd, Bp_fwd};
    fwd_clim = {[-2, 2], [-1.5, 1.5], [-1.5, 1.5]};

    % =========================== Figure: 16:9 宽屏 ===========================
    fig1 = figure('Color', 'w', 'Units', 'centimeters', 'Position', [1, 1, 32, 18]);

    % 通过设置 TileSpacing 和 Padding 为 'none'，结合自定义 Position 限制高度，实现紧凑的无缝布局
    t1 = tiledlayout(fig1, num_rows, num_cols, 'TileSpacing', 'none', 'Padding', 'none');
    t1.Units = 'normalized';
    t1.Position = [0.03, 0.12, 0.85, 0.76]; % 适当压缩高度与右侧空间，以匹配罗宾逊投影天然比例并放置右侧色标

    row_labels = {'B_r', 'B_\theta', 'B_\phi', '\sigma'};

    % 用于保存渲染后的坐标轴对象，确保后期色标定位准确
    ax_handles = cell(num_rows, num_cols);
    sigma_ranges = zeros(num_sats, 2);

    % =========================== 逐 tile 绘制 ===========================
    tile_idx = 0;
    for row = 1:num_rows          % 1:Br, 2:Bt, 3:Bp, 4:σ
        for col = 1:num_cols      % 1..7:卫星, 8:正演
            tile_idx = tile_idx + 1;
            ax = nexttile(t1);
            ax_handles{row, col} = ax;

            is_fwd  = (col == num_cols);          % 第8列 = 正演
            is_sigma = (row == 4);

            % ----- 判断内容 -----
            if is_fwd && is_sigma
                % Forward × σ：留空
                axis(ax, 'off');
                continue;
            end

            if is_fwd
                % Forward × (Br|Bt|Bp)
                comp_data = fwd_comp{row};
                cl = fwd_clim{row};
                plot_map_tight(ax, LON_fwd, LAT_fwd, comp_data);
                clim(ax, cl);
                colormap(ax, nclCM('CBR_coldhot'));
            else
                % Satellite × (Br|Bt|Bp|σ)
                sd = sat_data{col};
                switch row
                    case 1, map_data = sd.Br; cl = [-2, 2];
                    case 2, map_data = sd.Bt; cl = [-1.5, 1.5];
                    case 3, map_data = sd.Bp; cl = [-1.5, 1.5];
                    case 4
                        map_data = sat_error{col};
                        vals = map_data(~isnan(map_data));
                        if isempty(vals)
                            cl = [0, 1];
                        else
                            cl = [prctile(vals, 2), prctile(vals, 98)];
                        end
                        sigma_ranges(col, :) = cl;
                end
                
                plot_map_tight(ax, sd.LON, sd.LAT, map_data);
                clim(ax, cl);
                
                % 确保在绘图完成后立即应用对应的 colormap，防止颜色未生效
                if row <= 3
                    colormap(ax, nclCM('CBR_coldhot'));
                else
                    colormap(ax, nclCM('CBR_wet'));
                end
            end

            % ====== 标签 ======
            % 第1行：列标题（卫星名 / Forward）
            if row == 1
                if is_fwd
                    title(ax, 'Forward', 'FontSize', 12, 'FontWeight', 'normal');
                else
                    title(ax, sat_names{col}, 'FontSize', 12, 'FontWeight', 'normal');
                end
            end
            % 第1列：行标题（分量名）
            if col == 1
                ylabel(ax, row_labels{row}, 'FontWeight', 'bold', 'FontSize', 12);
            end
        end
    end

    % 强制刷新图形窗口以确保获取准确的渲染后实际 Position
    drawnow;

    % =========================== 色标系统 ===========================
    
    % ---- (A) 右侧共享色标: Br / Bt / Bp ----
    cb_x = 0.90;  % 右侧色标的起始 X 坐标
    cb_w = 0.012; % 色标宽度
    cb_labels = {'B_r (nT)', 'B_\theta (nT)', 'B_\phi (nT)'};
    cb_lims   = {[-2, 2], [-1.5, 1.5], [-1.5, 1.5]};
    cb_ticks  = {[-2, 0, 2], [-1.5, 0, 1.5], [-1.5, 0, 1.5]};

    for r = 1:3
        % 获取当前行最后一列（正演）的实际渲染位置
        pos = ax_handles{r, num_cols}.Position;
        cb_y = pos(2);
        cb_h = pos(4); % 垂直高度与该行地图高度完全对齐
        
        ax_cb = axes(fig1, 'Position', [cb_x, cb_y, cb_w, cb_h], 'Visible', 'off');
        colormap(ax_cb, nclCM('CBR_coldhot'));
        clim(ax_cb, cb_lims{r});
        c = colorbar(ax_cb, 'Location', 'eastoutside');
        c.Label.String = cb_labels{r};
        c.Label.FontSize = 10;
        c.Label.FontWeight = 'bold';
        c.FontSize = 9;
        c.Ticks = cb_ticks{r};
    end

    % ---- (B) 每列 σ 垂直色标（第4行各子图右边缘内部）----
    for i = 1:num_sats
        pos = ax_handles{4, i}.Position;
        cb_w_s = 0.005;        % 较窄的色标宽度
        cb_h_s = pos(4) * 0.8; % 高度略微小于子图高度，显得精致
        % 放置在当前子图的右边缘内部（罗宾逊两端收窄，不会遮挡主要地图区域）
        cb_x_s = pos(1) + pos(3) - 0.012; 
        cb_y_s = pos(2) + (pos(4) - cb_h_s)/2; % 垂直居中

        ax_cb = axes(fig1, 'Position', [cb_x_s, cb_y_s, cb_w_s, cb_h_s], 'Visible', 'off');
        colormap(ax_cb, nclCM('CBR_wet'));
        clim(ax_cb, sigma_ranges(i, :));
        c = colorbar(ax_cb, 'Location', 'eastoutside');
        c.FontSize = 7;
        c.TickLength = 0.02;
        
        % 只保留最值刻度，防止数值文本相互重叠
        ticks_val = [sigma_ranges(i, 1), sigma_ranges(i, 2)];
        c.Ticks = ticks_val;
        c.TickLabels = arrayfun(@(v) sprintf('%.2f', v), ticks_val, 'UniformOutput', false);

        if i == num_sats
            c.Label.String = '\sigma (nT)';
            c.Label.FontSize = 8;
            c.Label.FontWeight = 'bold';
        end
    end

    % =========================== 导出 ===========================
    out_png = 'Thesis_Fig1_PPT_16x9.png';
    exportgraphics(fig1, out_png, 'Resolution', 300);
    fprintf('✓ 已输出 %s (16:9, 300 DPI, %d×%d 布局)\n', ...
        out_png, num_rows, num_cols);
end

% =========================================================================
%                             辅助函数（保持不变）
% =========================================================================
function plot_map_tight(ax, LON, LAT, Data)
    axes(ax); m_proj('robinson', 'lon', [0 360]);
    if all(isnan(Data(:))), m_grid('box','on','xtick',[],'ytick',[],'linestyle','none'); return; end
    m_pcolor(LON, LAT, Data); shading interp;
    m_coast('color', [0.15 0.15 0.15], 'LineWidth', 0.4);
    m_grid('xtick', [], 'ytick', [], 'linestyle', 'none', 'box', 'on');
end

function [LON, LAT, Br, Bt, Bp] = synthesize_sh_field_v12(csv_path, alt_km)
    [LON, LAT] = meshgrid(0:2:360, -89:2:89);
    Br = nan(size(LON)); Bt = nan(size(LON)); Bp = nan(size(LON));
    if ~exist(csv_path, 'file'), return; end
    try
        T = readtable(csv_path);
        if ismember('Real_Part', T.Properties.VariableNames)
            coeffs = T.Real_Part + 1i*T.Imag_Part;
            n_list = T.Degree_n;
        else
            n_list = T{:,1}; coeffs = T{:,3} + 1i*T{:,4};
        end
        r_ref = 6371.2; r_obs = r_ref + alt_km;
        if exist('build_K_matrix_paper', 'file')
            coords = [r_obs*ones(numel(LON),1), 90-LAT(:), LON(:)];
            [Kr, Kt, Kp] = build_K_matrix_paper(coords, ones(size(coords,1),1), zeros(size(coords,1),1), double(max(n_list)), r_ref);
            Br = real(reshape(Kr(:, 1:2:end)*coeffs, size(LON)));
            Bt = real(reshape(Kt(:, 1:2:end)*coeffs, size(LON)));
            Bp = real(reshape(Kp(:, 1:2:end)*coeffs, size(LON)));
        end
    catch; end
end

function [Map_Error, N_max] = calculate_error_map_fixed(mat_path, alt_km)
    [LON, LAT] = meshgrid(0:2:360, -89:2:89);
    Map_Error = nan(size(LON)); N_max = 0;
    if ~exist(mat_path, 'file'), return; end
    try
        D = load(mat_path);
        if ~isfield(D, 'C_tau'), return; end
        C_tau = double(D.C_tau);
        dim = size(C_tau, 1);
        if isfield(D, 'N_max'), N_max = double(D.N_max);
        else, N_try = sqrt(dim+1)-1;
             if abs(N_try-round(N_try))<1e-4, N_max=round(N_try); else, N_max=round(sqrt(dim)-1); end
        end
        res = 4;
        [LON_E, LAT_E] = meshgrid(0:res:360, -89:res:89);
        r_plot = (6371.2+alt_km)*ones(size(LON_E));
        if exist('build_K_matrix_paper', 'file')
            N_val = double(round(N_max));
            [Kr,~,~] = build_K_matrix_paper([r_plot(:), 90-LAT_E(:), LON_E(:)], ones(numel(LON_E),1), zeros(numel(LON_E),1), N_val, 6371.2);
            num_pts = size(Kr,1); Field_Var = zeros(num_pts,1);
            for b = 1:2000:num_pts
                idx = b:min(b+2000-1, num_pts);
                Field_Var(idx) = real(sum((Kr(idx,:)*C_tau).*Kr(idx,:), 2));
            end
            Map_Low = reshape(sqrt(abs(Field_Var)), size(LON_E));
            Map_Error = interp2(LON_E, LAT_E, Map_Low, LON, LAT, 'spline');
        end
    catch; end
end

function D = load_h5_forward_model(filepath, const)
    if ~isfile(filepath), error('找不到文件: %s', filepath); end
    try
        Re_Ht_r = h5read(filepath, '/Re_Ht_r');
        Im_Ht_r = h5read(filepath, '/Im_Ht_r');
        Theta   = h5read(filepath, '/Theta');
        Phi     = h5read(filepath, '/Phi');
        field_nT = (double(Re_Ht_r) + 1i * double(Im_Ht_r)) * (4 * pi * 100);
    catch ME
        error('H5 读取失败: %s', ME.message);
    end
    coeffs = sha_solver_vectorized(double(Theta(:)), double(Phi(:)), double(field_nT(:)), const.a_radius, const);
    D = coeffs_to_standard_format(coeffs, const.N_max);
end

function D = coeffs_to_standard_format(coeffs, N_max)
    D = []; idx = 1;
    for n = 1:N_max
        num_m = 2*n + 1;
        c_n = coeffs(idx : idx + num_m - 1);
        D = [D; n, 0, real(c_n(1)), imag(c_n(1))];
        for m = 1:n
            D = [D; n,  m, real(c_n(2*m)),   imag(c_n(2*m))];
            D = [D; n, -m, real(c_n(2*m+1)), imag(c_n(2*m+1))];
        end
        idx = idx + num_m;
    end
end

function coeffs = sha_solver_vectorized(colat, lon, data, r_data, const)
    N_max = const.N_max; a = const.a_radius;
    n_pts = length(colat); n_coeffs = N_max * (N_max + 2);
    A = zeros(n_pts, n_coeffs); col_idx = 1;
    rad_ratio = a / r_data; cos_colat = cosd(colat);
    for n = 1:N_max
        radial_term = (n + 1) * (rad_ratio)^(n + 2);
        P = legendre(n, cos_colat', 'sch');
        for m = 0:n
            P_nm = P(m+1, :)';
            term_common = radial_term * P_nm;
            if m == 0
                A(:, col_idx) = term_common; col_idx = col_idx + 1;
            else
                A(:, col_idx) = term_common .* cosd(m * lon); col_idx = col_idx + 1;
                A(:, col_idx) = term_common .* sind(m * lon); col_idx = col_idx + 1;
            end
        end
    end
    coeffs = A \ data;
end

function [Map_Re, Map_Im] = synthesize_complex_map(Coeff_Data, alt_km, comp_name, LON, LAT, cfg)
    r_ref = cfg.a_radius;
    r_obs = r_ref + alt_km;
    coords = [r_obs*ones(numel(LON),1), 90-LAT(:), LON(:)];
    n_max_data = max(Coeff_Data(:,1));
    [Kr, Kt, Kp] = build_K_matrix_paper(coords, ones(size(coords,1),1), zeros(size(coords,1),1), double(n_max_data), r_ref);
    switch comp_name
        case 'Br', K = Kr;
        case 'Bt', K = Kt;
        case 'Bp', K = Kp;
    end
    Field_Complex = K(:, 1:2:end) * (Coeff_Data(:,3) + 1i*Coeff_Data(:,4));
    Map_Re = real(reshape(Field_Complex, size(LON)));
    Map_Im = imag(reshape(Field_Complex, size(LON)));
end