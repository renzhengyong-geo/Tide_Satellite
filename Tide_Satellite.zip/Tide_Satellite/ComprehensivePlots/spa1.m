%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Solar Position Algorithm (SPA) for Solar Radiation Application
%                                         
% Measurement & Instrumentation Team Solar Radiation Research Laboratory
% National Renewable Energy Laboratory 1617 Cole Blvd, Golden, CO 80401
%
% Last modified:   2017/03/19   M. Mahooti
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [] = spa1()
% clc
% clear
% format long g
% 
% spa_const
% 
% % declare the SPA structure
% % enter required input values into SPA structure
% spa1.year          = 2024;
% spa1.month         = 11;
% spa1.day           = 05;
% spa1.hour          = 17;
% spa1.minute        = 00;
% spa1.second        = 10;
% spa1.timezone      = 8;
% spa1.delta_ut1     = 0;
% spa1.delta_t       = 67;
% spa1.longitude     = -10;   %-180-180
% spa1.latitude      = 39;    %-90-90
% spa1.elevation     = 0;
% spa1.pressure      = 820;
% spa1.temperature   = 11;
% spa1.slope         = 30;
% spa1.azm_rotation  = -10;
% spa1.atmos_refract = 0.5667;
% spa1.function      = SPA_ALL;

%call the SPA calculate function and pass the SPA structure
% [result, spa1] = spa_calculate(spa1);
function zenith = spa1(year, month, day, hour, minute, second, longitude, latitude,spa_const_data)
% spa1 - Calculates the solar zenith angle for the given date, time, and location
% INPUTS:
%   year, month, day, hour, minute, second - Date and time information
%   longitude, latitude - Geographical coordinates of the location
% OUTPUT:
%   zenith - Solar zenith angle in degrees

  %  spa_const();  % Load SPA constants
    % Declare the SPA structure and enter required input values
    spa2 = struct();
    spa2.year          = year;
    spa2.month         = month;
    spa2.day           = day;
    spa2.hour          = hour;
    spa2.minute        = minute;
    spa2.second        = second;
    spa2.timezone      = round(longitude/15);  % 计算实际的时区
    spa2.delta_ut1     = spa_const_data.delta_ut1;
    spa2.delta_t       = spa_const_data.delta_t;
    spa2.longitude     = longitude;
    spa2.latitude      = latitude;
    spa2.elevation     = spa_const_data.elevation;
    spa2.pressure      = spa_const_data.pressure;
    spa2.temperature   = spa_const_data.temperature;
    spa2.slope         = spa_const_data.slope;      % Assuming flat surface
    spa2.azm_rotation  = spa_const_data.azm_rotation;      % Assuming azimuth rotation is zero
    spa2.atmos_refract = spa_const_data.atmos_refract; % Default atmospheric refraction
    spa2.function      = spa_const_data.SPA_ZA_INC;

    % Call the SPA calculate function and pass the SPA structure
    [result, spa2] = spa_calculate(spa2);
    
% if (result == 0)  %check for SPA errors
%     %display the results inside the SPA structure
%     % fprintf('Julian Day:    %.6f\n',spa1.jd);
%     % fprintf('L:             %.6e degrees\n',spa1.l);
%     % fprintf('B:             %.6e degrees\n',spa1.b);
%     % fprintf('R:             %.6f AU\n',spa1.r);
%     % fprintf('H:             %.6f degrees\n',spa1.h);
%     % fprintf('Delta Psi:     %.6e degrees\n',spa1.del_psi);
%     % fprintf('Delta Epsilon: %.6e degrees\n',spa1.del_epsilon);
%     % fprintf('Epsilon:       %.6f degrees\n',spa1.epsilon);
%     zenith = spa2.zenith;
%     fprintf('Zenith:        %.6f degrees\n',spa2.zenith);
%     % fprintf('Azimuth:       %.6f degrees\n',spa1.azimuth);
%     % fprintf('Incidence:     %.6f degrees\n',spa1.incidence);
%     min = 60*(spa2.sunrise - floor(spa2.sunrise));
%     sec = 60*(min - floor(min));
%     % fprintf('Sunrise:       %2.2d:%2.2d:%2.2d Local Time\n', ...
%     %        floor(spa1.sunrise), floor(min), floor(sec));
% 
%     min = 60*(spa2.sunset - floor(spa2.sunset));
%     sec = 60*(min - floor(min));
%     % fprintf('Sunset:        %2.2d:%2.2d:%2.2d Local Time\n', ...
%     %         floor(spa1.sunset), floor(min), floor(sec));
% else
%     fprintf('SPA Error Code: %d\n', result);
% 
% end

if (result == 0)  % Check for SPA errors and ensure 'zenith' field exists
    zenith = spa2.zenith;
    % fprintf('zenith: %f degrees\n',zenith);
else
    zenith = NaN;  % Assign NaN if there was an error
    fprintf('SPA Error Code: %d\n', result);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The output of this program should be:
%
%Julian Day:    2452930.312847
%L:             2.401826e+01 degrees
%B:             -1.011219e-04 degrees
%R:             0.996542 AU
%H:             11.105902 degrees
%Delta Psi:     -3.998404e-03 degrees
%Delta Epsilon: 1.666568e-03 degrees
%Epsilon:       23.440465 degrees
%Zenith:        50.111622 degrees
%Azimuth:       194.340241 degrees
%Incidence:     25.187000 degrees
%Sunrise:       06:12:43 Local Time
%Sunset:        17:20:19 Local Time
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function limited = limit_degrees(degrees)

degrees = degrees/360;
limited = 360*(degrees-floor(degrees));

if (limited < 0)
    limited = limited + 360;
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function limited = limit_degrees180pm(degrees)

degrees = degrees/360;
limited = 360*(degrees-floor(degrees));

if(limited < -180)
    limited = limited + 360;
elseif(limited > 180)
    limited = limited - 360;
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function limited = limit_degrees180(degrees)

degrees = degrees/180;
limited = 180*(degrees-floor(degrees));
if (limited < 0)
    limited = limited + 180;
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function limited = limit_zero2one(value)

limited = value - floor(value);
if (limited < 0)
    limited = limited + 1;
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function limited = limit_minutes(minutes)

limited = minutes;

if(limited < -20)
    limited = limited + 1440;
elseif(limited > 20)
    limited = limited - 1440;
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = dayfrac_to_local_hr(dayfrac, timezone)

out = 24*limit_zero2one(dayfrac + timezone/24);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = third_order_polynomial(a, b, c, d, x)

out = ((a*x + b)*x + c)*x + d;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = validate_inputs(spa)

spa_const

if ((spa.year        < -2000) || (spa.year        > 6000))
    out = 1;
    return
end
if ((spa.month       < 1    ) || (spa.month       > 12  ))
    out = 2;
    return
end
if ((spa.day         < 1    ) || (spa.day         > 31  ))
    out = 3;
    return
end
if ((spa.hour        < 0    ) || (spa.hour        > 24  ))
    out = 4;
    return
end
if ((spa.minute      < 0    ) || (spa.minute      > 59  ))
    out = 5;
    return
end
if ((spa.second      < 0    ) || (spa.second      >=60  ))
    out = 6;
    return
end
if ((spa.pressure    < 0    ) || (spa.pressure    > 5000))
    out = 12;
    return
end
if ((spa.temperature <= -273) || (spa.temperature > 6000))
    out = 13;
    return
end
if ((spa.delta_ut1   <= -1  ) || (spa.delta_ut1   >= 1  ))
    out = 17;
    return
end
if ((spa.hour        == 24  ) && (spa.minute      > 0   ))
    out = 5;
    return
end
if ((spa.hour        == 24  ) && (spa.second      > 0   ))
    out = 6;
    return
end

if (abs(spa.delta_t)       > 8000    )
    out = 7;
    return
end
if (abs(spa.timezone)      > 18      )
    out = 8;
    return
end
if (abs(spa.longitude)     > 180     )
    out = 9;
    return
end
if (abs(spa.latitude)      > 90      )
    out = 10;
    return
end
if (abs(spa.atmos_refract) > 5       )
    out = 16;
    return
end
if (    spa.elevation      < -6500000)
    out = 11;
    return
end

if ((spa.function == SPA_ZA_INC) || (spa.function == SPA_ALL))
    if (abs(spa.slope)         > 360)
        out = 14;
        return
    end
    if (abs(spa.azm_rotation)  > 360)
        out = 15;
        return
    end
end

out = 0;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function julian_day = julian_day(year,month,day,hour,minute,second,dut1,tz)

day_decimal = day+(hour-tz+(minute+(second+dut1)/60)/60)/24;

if(month < 3)
    month = month+12;
    year = year-1;
end

julian_day = floor(365.25*(year+4716))+floor(30.6001*(month+1))+...
             day_decimal-1524.5;

if (julian_day > 2299160)
    a = floor(year/100);
    julian_day = julian_day+(2-a+floor(a/4));
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = julian_century(jd)

out = (jd-2451545)/36525;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = julian_ephemeris_day(jd, delta_t)

out = jd+delta_t/86400;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = julian_ephemeris_century(jde)

out = (jde-2451545)/36525;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = julian_ephemeris_millennium(jce)

out = (jce/10);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = earth_periodic_term_summation(terms,count,jme)

spa_const

sum = 0;

for i = 1:count
    sum = sum + (terms(i,TERM_A)*cos(terms(i,TERM_B)+terms(i,TERM_C)*jme));
end

out = sum;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = earth_values(term_sum,count,jme)

sum = 0;

for i = 1:count
    sum = sum + term_sum(i)*(jme^(i-1));
end

sum = sum/1e8;

out = sum;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = earth_heliocentric_longitude(jme)

spa_const

sum = zeros(L_COUNT,1);

for i = 1:L_COUNT
    L_TERM = cell2mat(L_TERMS(i));    
    sum(i) = earth_periodic_term_summation(L_TERM, l_subcount(i), jme);
end

out = limit_degrees(rad2deg(earth_values(sum, L_COUNT, jme)));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = earth_heliocentric_latitude(jme)

spa_const

sum = zeros(B_COUNT,1);

for i = 1:B_COUNT
    B_TERM = cell2mat(B_TERMS(i));
    sum(i) = earth_periodic_term_summation(B_TERM, b_subcount(i), jme);
end

out = rad2deg(earth_values(sum, B_COUNT, jme));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = earth_radius_vector(jme)

spa_const

sum = zeros(R_COUNT,1);

for i = 1:R_COUNT
    R_TERM = cell2mat(R_TERMS(i));
    sum(i) = earth_periodic_term_summation(R_TERM, r_subcount(i), jme);
end

out = earth_values(sum, R_COUNT, jme);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function theta = geocentric_longitude(l)

theta = l+180;

if (theta >= 360)
    theta = theta-360;
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = geocentric_latitude(b)

out = -b;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = mean_elongation_moon_sun(jce)

out = third_order_polynomial(1/189474,-0.0019142,445267.11148,297.85036,jce);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = mean_anomaly_sun(jce)

out = third_order_polynomial(-1/300000,-0.0001603,35999.05034,357.52772,jce);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = mean_anomaly_moon(jce)

out = third_order_polynomial(1/56250,0.0086972,477198.867398,134.96298,jce);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = argument_latitude_moon(jce)

out = third_order_polynomial(1/327270,-0.0036825,483202.017538,93.27191,jce);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = ascending_longitude_moon(jce)

out = third_order_polynomial(1/450000,0.0020708,-1934.136261,125.04452,jce);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function sum = xy_term_summation(i, x)

spa_const

sum=0;

for j = 1:TERM_Y_COUNT
    sum = sum + x(j)*Y_TERMS(i,j);
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [del_psi, del_epsilon] = nutation_longitude_and_obliquity(jce, x)

spa_const

sum_psi = 0;
sum_epsilon = 0;

for i = 1:Y_COUNT
    xy_term_sum = deg2rad(xy_term_summation(i, x));
    sum_psi     = sum_psi + ( (PE_TERMS(i,TERM_PSI_A) + ...
                           jce*PE_TERMS(i,TERM_PSI_B))*sin(xy_term_sum) );
    sum_epsilon = sum_epsilon + ( (PE_TERMS(i,TERM_EPS_C) + ...
                           jce*PE_TERMS(i,TERM_EPS_D))*cos(xy_term_sum) );
end

del_psi     = sum_psi    /36000000;
del_epsilon = sum_epsilon/36000000;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = ecliptic_mean_obliquity(jme)

u = jme/10;

out = 84381.448+u*(-4680.93+u*(-1.55+u*(1999.25+u*(-51.38 + ...
      u*(-249.67+u*(-39.05+u*(7.12+u*(27.87+u*(5.79+u*2.45)))))))));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = ecliptic_true_obliquity(delta_epsilon, epsilon0)

out = delta_epsilon + epsilon0/3600;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = aberration_correction(r)

out = -20.4898/(3600*r);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = apparent_sun_longitude(theta, delta_psi, delta_tau)

out = theta + delta_psi + delta_tau;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = greenwich_mean_sidereal_time (jd, jc)

out = limit_degrees(280.46061837+360.98564736629*(jd-2451545)+ ...
      jc*jc*(0.000387933 - jc/38710000));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = greenwich_sidereal_time (nu0, delta_psi, epsilon)

out = nu0 + delta_psi*cos(deg2rad(epsilon));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = geocentric_right_ascension(lamda, epsilon, beta)

lamda_rad   = deg2rad(lamda);
epsilon_rad = deg2rad(epsilon);

out = limit_degrees(rad2deg(atan2(sin(lamda_rad)*cos(epsilon_rad) - ...
      tan(deg2rad(beta))*sin(epsilon_rad), cos(lamda_rad))));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = geocentric_declination(beta, epsilon, lamda)

beta_rad    = deg2rad(beta);
epsilon_rad = deg2rad(epsilon);

out = rad2deg(asin(sin(beta_rad)*cos(epsilon_rad) + ...
      cos(beta_rad)*sin(epsilon_rad)*sin(deg2rad(lamda))));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = observer_hour_angle(nu, longitude, alpha_deg)

out = limit_degrees(nu + longitude - alpha_deg);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = sun_equatorial_horizontal_parallax(r)

out = 8.794/(3600*r);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [delta_alpha, delta_prime] = ...
right_ascension_parallax_and_topocentric_dec(latitude,elevation,xi,h,delta)

lat_rad   = deg2rad(latitude);
xi_rad    = deg2rad(xi);
h_rad     = deg2rad(h);
delta_rad = deg2rad(delta);
u = atan(0.99664719 * tan(lat_rad));
y = 0.99664719 * sin(u) + elevation*sin(lat_rad)/6378140;
x =              cos(u) + elevation*cos(lat_rad)/6378140;

delta_alpha_rad = atan2(-x*sin(xi_rad)*sin(h_rad), ...
                        cos(delta_rad)-x*sin(xi_rad)*cos(h_rad));

delta_prime = rad2deg(atan2((sin(delta_rad)-y*sin(xi_rad))* ...
            cos(delta_alpha_rad),cos(delta_rad)-x*sin(xi_rad)*cos(h_rad)));

delta_alpha = rad2deg(delta_alpha_rad);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = topocentric_right_ascension(alpha_deg, delta_alpha)

out = alpha_deg + delta_alpha;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = topocentric_local_hour_angle(h, delta_alpha)

out = h - delta_alpha;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = topocentric_elevation_angle(latitude, delta_prime, h_prime)

lat_rad         = deg2rad(latitude);
delta_prime_rad = deg2rad(delta_prime);

out = rad2deg(asin(sin(lat_rad)*sin(delta_prime_rad) + ...
              cos(lat_rad)*cos(delta_prime_rad) * cos(deg2rad(h_prime))));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function del_e = atmospheric_refraction_correction(pressure,temperature,...
	                                                     atmos_refract, e0)
spa_const

del_e = 0;

if(e0 >= -1*(SUN_RADIUS + atmos_refract))
    del_e = (pressure/1010)*(283/(273+temperature))* ...
             1.02/(60*tan(deg2rad(e0+10.3/(e0+5.11))));
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = topocentric_elevation_angle_corrected(e0, delta_e)

out = e0 + delta_e;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = topocentric_zenith_angle(e)

out = 90.0 - e;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = topocentric_azimuth_angle_astro(h_prime, latitude, delta_prime)

h_prime_rad = deg2rad(h_prime);
lat_rad     = deg2rad(latitude);

out = limit_degrees(rad2deg(atan2(sin(h_prime_rad), ...
 cos(h_prime_rad)*sin(lat_rad) - tan(deg2rad(delta_prime))*cos(lat_rad))));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = topocentric_azimuth_angle(azimuth_astro)

out = limit_degrees(azimuth_astro + 180);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = surface_incidence_angle(zenith,azimuth_astro,azm_rotation,slope)

zenith_rad = deg2rad(zenith);
slope_rad  = deg2rad(slope);

out = rad2deg(acos(cos(zenith_rad)*cos(slope_rad) + ...
 sin(slope_rad)*sin(zenith_rad)*cos(deg2rad(azimuth_astro-azm_rotation))));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = sun_mean_longitude(jme)

out = limit_degrees(280.4664567+jme*(360007.6982779+jme*(0.03032028+ ...
                    jme*(1/49931+jme*(-1/15300+jme*(-1/2000000))))));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = eot(m, alpha, del_psi, epsilon)

out = limit_minutes(4*(m-0.0057183-alpha+del_psi*cos(deg2rad(epsilon))));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = approx_sun_transit_time(alpha_zero, longitude, nu)

out = (alpha_zero-longitude-nu)/360;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function h0 = sun_hour_angle_at_rise_set(latitude, delta_zero, h0_prime)

h0             = -99999;
latitude_rad   = deg2rad(latitude);
delta_zero_rad = deg2rad(delta_zero);
argument       = (sin(deg2rad(h0_prime))-sin(latitude_rad)* ...
              sin(delta_zero_rad))/(cos(latitude_rad)*cos(delta_zero_rad));
if (abs(argument) <= 1)
    h0 = limit_degrees180(rad2deg(acos(argument)));
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function m_rts = approx_sun_rise_and_set(m_rts, h0)

spa_const

h0_dfrac = h0/360;

m_rts(SUN_RISE)    = limit_zero2one(m_rts(SUN_TRANSIT) - h0_dfrac);
m_rts(SUN_SET)     = limit_zero2one(m_rts(SUN_TRANSIT) + h0_dfrac);
m_rts(SUN_TRANSIT) = limit_zero2one(m_rts(SUN_TRANSIT));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = rts_alpha_delta_prime(ad, n)

spa_const

a = ad(JD_ZERO) - ad(JD_MINUS);
b = ad(JD_PLUS) - ad(JD_ZERO);

if (abs(a) >= 2)
    a = limit_zero2one(a);
end
if (abs(b) >= 2)
    b = limit_zero2one(b);
end

out = ad(JD_ZERO) + n * (a + b + (b-a)*n)/2;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = rts_sun_altitude(latitude, delta_prime, h_prime)

latitude_rad    = deg2rad(latitude);
delta_prime_rad = deg2rad(delta_prime);

out = rad2deg(asin(sin(latitude_rad)*sin(delta_prime_rad) + ...
            cos(latitude_rad)*cos(delta_prime_rad)*cos(deg2rad(h_prime))));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out = sun_rise_and_set(m_rts, h_rts, delta_prime, latitude, ...
                                h_prime, h0_prime, sun)

out = m_rts(sun)+(h_rts(sun)-h0_prime)/(360*cos(deg2rad(delta_prime(sun)))...
                *cos(deg2rad(latitude))*sin(deg2rad(h_prime(sun))));

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate required SPA parameters to get the right ascension (alpha) and
% declination (delta) Note: JD must be already calculated and in structure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function spa1 = calculate_geocentric_sun_right_ascension_and_declination(spa1)

spa_const

x = zeros(TERM_X_COUNT,1);

spa1.jc = julian_century(spa1.jd);

spa1.jde = julian_ephemeris_day(spa1.jd, spa1.delta_t);
spa1.jce = julian_ephemeris_century(spa1.jde);
spa1.jme = julian_ephemeris_millennium(spa1.jce);

spa1.l = earth_heliocentric_longitude(spa1.jme);
spa1.b = earth_heliocentric_latitude(spa1.jme);
spa1.r = earth_radius_vector(spa1.jme);

spa1.theta = geocentric_longitude(spa1.l);
spa1.beta  = geocentric_latitude(spa1.b);

spa1.x0 = mean_elongation_moon_sun(spa1.jce);
x(TERM_X0) = spa1.x0;
spa1.x1 = mean_anomaly_sun(spa1.jce);
x(TERM_X1) = spa1.x1;
spa1.x2 = mean_anomaly_moon(spa1.jce);
x(TERM_X2) = spa1.x2;
spa1.x3 = argument_latitude_moon(spa1.jce);
x(TERM_X3) = spa1.x3;
spa1.x4 = ascending_longitude_moon(spa1.jce);
x(TERM_X4) = spa1.x4;

[spa1.del_psi,spa1.del_epsilon] = nutation_longitude_and_obliquity(spa1.jce,x);

spa1.epsilon0 = ecliptic_mean_obliquity(spa1.jme);
spa1.epsilon  = ecliptic_true_obliquity(spa1.del_epsilon, spa1.epsilon0);

spa1.del_tau = aberration_correction(spa1.r);
spa1.lamda   = apparent_sun_longitude(spa1.theta, spa1.del_psi,spa1.del_tau);
spa1.nu0     = greenwich_mean_sidereal_time (spa1.jd, spa1.jc);
spa1.nu      = greenwich_sidereal_time (spa1.nu0, spa1.del_psi,spa1.epsilon);

spa1.alpha = geocentric_right_ascension(spa1.lamda, spa1.epsilon,spa1.beta);
spa1.delta = geocentric_declination(spa1.beta, spa1.epsilon, spa1.lamda);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate Equation of Time (EOT) and Sun Rise, Transit, & Set (RTS)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function spa1 = calculate_eot_and_sun_rise_transit_set(spa1)

spa_const

alpha = zeros(JD_COUNT,1);
delta = zeros(JD_COUNT,1);
m_rts = zeros(SUN_COUNT,1);
nu_rts = zeros(SUN_COUNT,1);
h_rts = zeros(SUN_COUNT,1);
alpha_prime = zeros(SUN_COUNT,1);
delta_prime = zeros(SUN_COUNT,1);
h_prime = zeros(SUN_COUNT,1);
h0_prime = -1*(SUN_RADIUS + spa1.atmos_refract);

sun_rts = spa1;
m       = sun_mean_longitude(spa1.jme);
spa1.eot = eot(m, spa1.alpha, spa1.del_psi, spa1.epsilon);
sun_rts.hour = 0;
sun_rts.minute = 0;
sun_rts.second = 0;
sun_rts.delta_ut1 = 0;
sun_rts.timezone = 0;

sun_rts.jd = julian_day(sun_rts.year,sun_rts.month,sun_rts.day,sun_rts.hour, ...
         sun_rts.minute,sun_rts.second,sun_rts.delta_ut1,sun_rts.timezone);

sun_rts = calculate_geocentric_sun_right_ascension_and_declination(sun_rts);
nu = sun_rts.nu;

sun_rts.delta_t = 0;
sun_rts.jd = sun_rts.jd-1;
for i = 1:JD_COUNT
    sun_rts = calculate_geocentric_sun_right_ascension_and_declination(sun_rts);
    alpha(i) = sun_rts.alpha;
    delta(i) = sun_rts.delta;
    sun_rts.jd = sun_rts.jd+1;
end

m_rts(SUN_TRANSIT) = approx_sun_transit_time(alpha(JD_ZERO),spa1.longitude,nu);
h0 = sun_hour_angle_at_rise_set(spa1.latitude,delta(JD_ZERO),h0_prime);

if (h0 >= 0)
    m_rts = approx_sun_rise_and_set(m_rts, h0);
    for i = 1:SUN_COUNT
        nu_rts(i)      = nu + 360.985647*m_rts(i);
        n              = m_rts(i) + spa1.delta_t/86400;
        alpha_prime(i) = rts_alpha_delta_prime(alpha,n);
        delta_prime(i) = rts_alpha_delta_prime(delta,n);
        h_prime(i)     = limit_degrees180pm(nu_rts(i)+spa1.longitude-alpha_prime(i));
        h_rts(i)       = rts_sun_altitude(spa1.latitude,delta_prime(i),h_prime(i));
    end
    
    spa1.srha = h_prime(SUN_RISE);
    spa1.ssha = h_prime(SUN_SET);
    spa1.sta  = h_rts(SUN_TRANSIT);
    
    spa1.suntransit = dayfrac_to_local_hr(m_rts(SUN_TRANSIT)- ...
                                    h_prime(SUN_TRANSIT)/360,spa1.timezone);
    
    spa1.sunrise = dayfrac_to_local_hr(sun_rise_and_set(m_rts,h_rts, ...
         delta_prime,spa1.latitude,h_prime,h0_prime,SUN_RISE),spa1.timezone);
    
    spa1.sunset = dayfrac_to_local_hr(sun_rise_and_set(m_rts,h_rts, ...
          delta_prime,spa1.latitude,h_prime,h0_prime,SUN_SET),spa1.timezone);
    
else
    spa1.srha = -99999;
    spa1.ssha = -99999;
    spa1.sta = -99999;
    spa1.suntransit = -99999;
    spa1.sunrise = -99999;
    spa1.sunset = -99999;
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate all SPA parameters and put into structure
% Note: All inputs values (listed in header file) must already be in structure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [result, spa1] = spa_calculate(spa1)

spa_const

result = validate_inputs(spa1);

if (result == 0)
    spa1.jd = julian_day(spa1.year,spa1.month,spa1.day,spa1.hour,spa1.minute, ...
                                  spa1.second, spa1.delta_ut1, spa1.timezone);
    
    spa1 = calculate_geocentric_sun_right_ascension_and_declination(spa1);
    
    spa1.h  = observer_hour_angle(spa1.nu, spa1.longitude, spa1.alpha);
    spa1.xi = sun_equatorial_horizontal_parallax(spa1.r);

    [spa1.del_alpha, spa1.delta_prime] = ...
    right_ascension_parallax_and_topocentric_dec(spa1.latitude, ...
                                     spa1.elevation,spa1.xi,spa1.h,spa1.delta);

    spa1.alpha_prime = topocentric_right_ascension(spa1.alpha, spa1.del_alpha);
    spa1.h_prime     = topocentric_local_hour_angle(spa1.h, spa1.del_alpha);

    spa1.e0    = topocentric_elevation_angle(spa1.latitude, spa1.delta_prime, spa1.h_prime);
    spa1.del_e = atmospheric_refraction_correction(spa1.pressure, ...
                                spa1.temperature,spa1.atmos_refract, spa1.e0);
    spa1.e     = topocentric_elevation_angle_corrected(spa1.e0, spa1.del_e);

    spa1.zenith        = topocentric_zenith_angle(spa1.e);
    spa1.azimuth_astro = topocentric_azimuth_angle_astro(spa1.h_prime, ...
                                             spa1.latitude,spa1.delta_prime);
    spa1.azimuth       = topocentric_azimuth_angle(spa1.azimuth_astro);

    if ((spa1.function == SPA_ZA_INC) || (spa1.function == SPA_ALL))
        spa1.incidence  = surface_incidence_angle(spa1.zenith, ...
                             spa1.azimuth_astro,spa1.azm_rotation,spa1.slope);
    end
    if ((spa1.function == SPA_ZA_RTS) || (spa1.function == SPA_ALL))
        spa1 = calculate_eot_and_sun_rise_transit_set(spa1);
    end
end

end

