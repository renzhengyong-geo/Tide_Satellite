function Thesis_Plot_Final_v11_A4_Standard()
    % -------------------------------------------------------------------------
    % Purpose: 学位论文最终版 v13 - 统一色标位置
    % Layout: 7 Rows x 4 Columns (Br, Bt, Bp, Sigma)
    % 修改：右侧误差色标与底部三个色标位置完全统一
    % -------------------------------------------------------------------------
    clc; clear; close all;

    % =========================== 0. 路径配置 ===========================
    dir_results = '潮汐磁场结果';   
    dir_error   = '误差文件';       

    sat_config = {
        'CHAMP',     'CHAMP_SH_Coefficients_With_Errors.csv',      'CHAMP_Full_Inversion_Result.mat'; 
        'Ørsted',    'Orsted_SH_Coefficients_With_Errors.csv',     'Orsted_Full_Inversion_Result_Scalar.mat'; 
        'SAC-C',     'SACC_SH_Coefficients_With_Errors.csv',       'SACC_Full_Inversion_Result_Scalar.mat'; 
        'GRACE-FO',  'GraceFO_SH_Coefficients_base_ssg_csg.csv',   'GraceFO_Full_Inversion_Result.mat'; 
        'CryoSat-2', 'CryoSat_SH_Coefficients_With_Errors.csv',    'CryoSat_Full_Inversion_Result.mat'; 
        'MSS',       'MSS_SH_Coefficients_With_Errors.csv',        'MSS_Full_Inversion_Result.mat'; 
        'Swarm',     'Swarm_SH_Coefficients_With_Errors.csv',      'Swarm_Full_Inversion_Result.mat'; 
    };  
    
    num_sats = size(sat_config, 1);
    alt_km = 450;

    % =========================== Figure 1: 空间分布 ===========================
    % 宽度 16.5cm, 高度压缩至 21.5cm 以强制减小行间距
    fig1 = figure('Color', 'w', 'Units', 'centimeters', 'Position', [1, 1, 16.5, 21.5]); 
    
    % 使用 Padding 'compact' 和 TileSpacing 'none' 实现最紧凑布局
    t1 = tiledlayout(fig1, num_sats, 4, 'TileSpacing', 'none', 'Padding', 'compact');

    % 用于存储第4列子图的位置信息（用于统一色标位置）
    col4_positions = zeros(num_sats, 4);
    error_ranges = zeros(num_sats, 2);  % 存储每行的误差范围
    
    for i = 1:num_sats
        name = sat_config{i, 1};
        csv_file = fullfile(dir_results, sat_config{i, 2});
        err_file = fullfile(dir_error, sat_config{i, 3});
        
        [LON, LAT, Br, Bt, Bp] = synthesize_sh_field_v12(csv_file, alt_km);
        [Map_Error, ~]         = calculate_error_map_fixed(err_file, alt_km);
        
        if strcmp(name, 'MSS')
            mask = abs(LAT) > 50;
            Br(mask)=NaN; Bt(mask)=NaN; Bp(mask)=NaN; Map_Error(mask)=NaN;
        end
        
        data_list = {Br, Bt, Bp, Map_Error};
        titles = {'B_r', 'B_\theta', 'B_\phi', '\sigma'};
        
        for col = 1:4
            ax = nexttile(t1);
            plot_map_tight(ax, LON, LAT, data_list{col});
            
            if col == 1
                clim(ax, [-2, 2]); colormap(ax, nclCM('CBR_coldhot'));
            elseif col == 2 || col == 3
                clim(ax, [-1.5, 1.5]); colormap(ax, nclCM('CBR_coldhot'));
            else
                colormap(ax, nclCM('CBR_wet'));
                vals = Map_Error(~isnan(Map_Error));
                if isempty(vals), cmin=0; cmax=1; else, cmin=prctile(vals,2); cmax=prctile(vals,98); end
                clim(ax, [cmin, cmax]);
                
                % 保存第4列子图位置和误差范围
                col4_positions(i, :) = ax.Position;
                error_ranges(i, :) = [cmin, cmax];
            end
            
            if i == 1, title(ax, titles{col}, 'FontSize', 11, 'FontWeight', 'normal'); end
            if col == 1, ylabel(ax, name, 'FontWeight', 'bold', 'FontSize', 8); end
        end
    end

    % =========================== 底部色标位置优化 ===========================
    % cb_y 从 0.05 提高到 0.085，紧贴地图底部
    cb_y = 0.085; cb_w = 0.15; cb_h = 0.01;
    
    % Br 色标
    ax_cb1 = axes(fig1, 'Position', [0.1, cb_y, cb_w, cb_h], 'Visible', 'off');
    colormap(ax_cb1, nclCM('CBR_coldhot')); clim(ax_cb1, [-2, 2]);
    c1 = colorbar(ax_cb1, 'Location', 'southoutside'); 
    c1.Label.String = 'B_r (nT)'; c1.FontSize = 7; c1.Ticks = [-2, 0, 2];

    % Bt 色标
    ax_cb2 = axes(fig1, 'Position', [0.32, cb_y, cb_w, cb_h], 'Visible', 'off');
    colormap(ax_cb2, nclCM('CBR_coldhot')); clim(ax_cb2, [-1.5, 1.5]);
    c2 = colorbar(ax_cb2, 'Location', 'southoutside'); 
    c2.Label.String = 'B_\theta (nT)'; c2.FontSize = 7; c2.Ticks = [-1.5, 0, 1.5];

    % Bp 色标
    ax_cb3 = axes(fig1, 'Position', [0.54, cb_y, cb_w, cb_h], 'Visible', 'off');
    colormap(ax_cb3, nclCM('CBR_coldhot')); clim(ax_cb3, [-1.5, 1.5]);
    c3 = colorbar(ax_cb3, 'Location', 'southoutside'); 
    c3.Label.String = 'B_\phi (nT)'; c3.FontSize = 7; c3.Ticks = [-1.5, 0, 1.5];

    % =========================== 右侧误差色标（每行单独，紧贴各自子图）===========================
    % 为每个卫星创建误差色标，位置在该行第4列子图正下方
    for i = 1:num_sats
        % 获取第i行第4列子图的位置
        pos_col4 = col4_positions(i, :);  % [x, y, width, height]
        
        % 计算色标X位置：在第4列子图下方居中
        cb_x_sigma = pos_col4(1) + (pos_col4(3) - cb_w)/2;
        
        % 计算色标Y位置：紧贴该行子图底部（而不是统一在figure底部）
        % 色标放在子图下方，距离子图底边约0.005的间距
        cb_y_row = pos_col4(2) - cb_h + 0.025;
        
        % 创建独立的色标axes
        ax_cb_err = axes(fig1, 'Position', [cb_x_sigma, cb_y_row, cb_w, cb_h], 'Visible', 'off');
        colormap(ax_cb_err, nclCM('CBR_wet')); 
        clim(ax_cb_err, error_ranges(i, :));
        cb_err = colorbar(ax_cb_err, 'Location', 'southoutside');
        cb_err.FontSize = 7;
        
        % 只在第一行显示标签
        if i == 7
            cb_err.Label.String = '\sigma (nT)';
        end
    end

    % 导出
    exportgraphics(fig1, 'Thesis_Fig1_Unified_Colorbar.png', 'Resolution', 600);
    exportgraphics(fig1, 'Thesis_Fig1_Unified_Colorbar.pdf', 'Resolution', 600);
end

% =========================================================================
%                             辅助函数
% =========================================================================
function plot_map_tight(ax, LON, LAT, Data)
    axes(ax); m_proj('robinson', 'lon', [0 360]);
    if all(isnan(Data(:))), m_grid('box','on','xtick',[],'ytick',[],'linestyle','none'); return; end
    m_pcolor(LON, LAT, Data); shading interp;
    m_coast('color', [0.15 0.15 0.15], 'LineWidth', 0.4);
    m_grid('xtick', [], 'ytick', [], 'linestyle', 'none', 'box', 'on');
end

function [LON, LAT, Br, Bt, Bp] = synthesize_sh_field_v12(csv_path, alt_km)
    [LON, LAT] = meshgrid(0:2:360, -89:2:89);
    Br = nan(size(LON)); Bt = nan(size(LON)); Bp = nan(size(LON));
    if ~exist(csv_path, 'file'), return; end
    try
        T = readtable(csv_path);
        if ismember('Real_Part', T.Properties.VariableNames)
            coeffs = T.Real_Part + 1i*T.Imag_Part;
            n_list = T.Degree_n;
        else
            n_list = T{:,1}; coeffs = T{:,3} + 1i*T{:,4};
        end
        r_ref = 6371.2; r_obs = r_ref + alt_km;
        if exist('build_K_matrix_paper', 'file')
            coords = [r_obs*ones(numel(LON),1), 90-LAT(:), LON(:)];
            [Kr, Kt, Kp] = build_K_matrix_paper(coords, ones(size(coords,1),1), zeros(size(coords,1),1), double(max(n_list)), r_ref);
            Br = real(reshape(Kr(:, 1:2:end)*coeffs, size(LON)));
            Bt = real(reshape(Kt(:, 1:2:end)*coeffs, size(LON)));
            Bp = real(reshape(Kp(:, 1:2:end)*coeffs, size(LON)));
        end
    catch; end
end

function [Map_Error, N_max] = calculate_error_map_fixed(mat_path, alt_km)
    [LON, LAT] = meshgrid(0:2:360, -89:2:89);
    Map_Error = nan(size(LON)); N_max = 0;
    if ~exist(mat_path, 'file'), return; end
    try
        D = load(mat_path);
        if ~isfield(D, 'C_tau'), return; end
        C_tau = double(D.C_tau);
        dim = size(C_tau, 1);
        if isfield(D, 'N_max'), N_max = double(D.N_max);
        else, N_try = sqrt(dim+1)-1; 
             if abs(N_try-round(N_try))<1e-4, N_max=round(N_try); else, N_max=round(sqrt(dim)-1); end
        end
        res = 4;
        [LON_E, LAT_E] = meshgrid(0:res:360, -89:res:89);
        r_plot = (6371.2+alt_km)*ones(size(LON_E));
        if exist('build_K_matrix_paper', 'file')
            N_val = double(round(N_max));
            [Kr,~,~] = build_K_matrix_paper([r_plot(:), 90-LAT_E(:), LON_E(:)], ones(numel(LON_E),1), zeros(numel(LON_E),1), N_val, 6371.2);
            num_pts = size(Kr,1); Field_Var = zeros(num_pts,1);
            for b = 1:2000:num_pts
                idx = b:min(b+2000-1, num_pts);
                Field_Var(idx) = real(sum((Kr(idx,:)*C_tau).*Kr(idx,:), 2));
            end
            Map_Low = reshape(sqrt(abs(Field_Var)), size(LON_E));
            Map_Error = interp2(LON_E, LAT_E, Map_Low, LON, LAT, 'spline');
        end
    catch, end
end