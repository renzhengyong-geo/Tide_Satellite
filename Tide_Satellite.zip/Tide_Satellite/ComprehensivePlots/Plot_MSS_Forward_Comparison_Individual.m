function Plot_MSS_Forward_Comparison_Individual()
% -------------------------------------------------------------------------
% Purpose: MSS-1A 与正演对比图 (极简紧凑美观版)
% -------------------------------------------------------------------------
clc; clear; close all;

%% ========= 1. 参数与路径配置 (保持一致) =========
cfg.file_mss = '潮汐磁场结果/MSS_SH_Coefficients_With_Errors.csv';
cfg.file_fwd = '正演模拟结果/KUV_RES_0001.h5';
cfg.alt_km   = 430;
cfg.a_radius = 6371.2;
cfg.N_max    = 40;
cfg.res      = 1.5; % 提高一点点分辨率让边缘更平滑

components = {'Br', 'Bt', 'Bp'};
comp_titles = {'B_r', 'B_\theta', 'B_\phi'};

%% ========= 2. 数据准备 (预先读取) =========
Dat_MSS = load_coeffs_robust(cfg.file_mss, 'MSS', 1);
const.a_radius = cfg.a_radius; const.N_max = cfg.N_max;
Dat_Fwd = load_h5_forward_model(cfg.file_fwd, const);
[LON, LAT] = meshgrid(0:cfg.res:360, -89:cfg.res:89);

%% ========= 3. 循环绘制分量 =========
for c_idx = 1:3
    comp_name = components{c_idx};
    
    % --- 设置画布: A4 比例，略宽以便容纳地图 ---
    % 宽度 16cm (标准栏宽), 高度 11cm
    fig = figure('Color', 'w', 'Units', 'centimeters', 'Position', [2, 2, 16, 11]);
    
    % 使用 tiledlayout 并将间距压缩到极致
    t = tiledlayout(2, 2, 'TileSpacing', 'none', 'Padding', 'compact');
    
    if strcmp(comp_name, 'Br'), clim_val = [-1.5, 1.5]; else, clim_val = [-1.0, 1.0]; end
    
    % 计算数据
    [M_Obs_Re, M_Obs_Im] = synthesize_complex_map(Dat_MSS, cfg.alt_km, comp_name, LON, LAT, cfg);
    [M_Fwd_Re, M_Fwd_Im] = synthesize_complex_map(Dat_Fwd, cfg.alt_km, comp_name, LON, LAT, cfg);
    
    data_cells = {M_Obs_Re, M_Obs_Im; M_Fwd_Re, M_Fwd_Im};
    row_labels = {'Observation', 'Forward'};
    col_labels = {'Real Part', 'Imaginary Part'};

    for row = 1:2
        for col = 1:2
            ax = nexttile(t);
            plot_map_minimal(ax, LON, LAT, data_cells{row, col}, clim_val);
            
            % 第一行添加列标题
            if row == 1
                title(col_labels{col}, 'FontSize', 11, 'FontWeight', 'normal');
            end
            % 第一列添加行标题
            if col == 1
                ylabel(row_labels{row}, 'FontSize', 11, 'FontWeight', 'bold');
            end
        end
    end

    % --- 统一底部横向色标 ---
    cb = colorbar;
    cb.Layout.Tile = 'south'; % 放在底部
    cb.Orientation = 'horizontal';
    cb.Label.String = sprintf('%s (nT)', comp_titles{c_idx});
    cb.Label.FontSize = 10;
    cb.TickDirection = 'out';
    
    % 稍微拉开一点点底部距离，防止色标遮挡坐标轴
    t.Padding = 'compact'; 

    % 导出
    f_name = sprintf('MSS_Comparison_Compact_%s', comp_name);
    exportgraphics(fig, [f_name, '.pdf'], 'Resolution', 600);
    % exportgraphics(fig, [f_name, '.pdf'], 'ContentType', 'vector');
end
end

%% =========================================================================
%                             极简绘图辅助函数
% =========================================================================
function plot_map_minimal(ax, LON, LAT, Data, clims)
    axes(ax);
    m_proj('robinson', 'lon', [0 360]);
    
    % 绘制填色图
    m_pcolor(LON, LAT, Data); shading interp;
    hold on;
    
    % 绘制海岸线 (淡灰色，不抢主信号)
    m_coast('color', [0.3 0.3 0.3], 'LineWidth', 0.5);
    
    % 绘制边框 (Grid 设置为 none 隐藏经纬线，box on 保留外框)
    m_grid('xtick', [], 'ytick', [], 'linestyle', 'none', 'box', 'on', 'linewidth', 1);
    
    colormap(ax, nclCM('CBR_coldhot'));
    clim(clims);
    
    % 强制背景白色
    set(ax, 'Color', 'none');
end
%% =========================================================================
%                             辅助计算函数
% =========================================================================

function [Map_Re, Map_Im] = synthesize_complex_map(Coeff_Data, alt_km, comp_name, LON, LAT, cfg)
    % 基于球谐系数合成复数磁场地图
    r_ref = cfg.a_radius;
    r_obs = r_ref + alt_km;
    
    % 准备坐标
    coords = [r_obs*ones(numel(LON),1), 90-LAT(:), LON(:)];
    n_max_data = max(Coeff_Data(:,1));
    
    % 构建系数向量 (Real and Imag)
    % 注意：synthesis 需要 complex coeffs
    coeffs_complex = Coeff_Data(:,3) + 1i * Coeff_Data(:,4);
    
    % 调用 K 矩阵合成函数 (假设 build_K_matrix_paper 在路径中)
    [Kr, Kt, Kp] = build_K_matrix_paper(coords, ones(size(coords,1),1), zeros(size(coords,1),1), double(n_max_data), r_ref);
    
    switch comp_name
        case 'Br', K = Kr;
        case 'Bt', K = Kt;
        case 'Bp', K = Kp;
    end
    
    % 这里的 K 是实数几何矩阵，field = K * coeffs
    % 使用 1:2:end 是因为 build_K 通常输出 [g10, h10, g11, h11...] 对应的基函数
    % 如果您的 coeffs 格式是 [n, m, Re, Im]，需要根据 build_K 的内部映射来对应
    % 以下逻辑兼容 standard format [n,m,Re,Im]
    
    Field_Complex = K(:, 1:2:end) * (Coeff_Data(:,3) + 1i*Coeff_Data(:,4));
    
    Map_Re = real(reshape(Field_Complex, size(LON)));
    Map_Im = imag(reshape(Field_Complex, size(LON)));
    
    % MSS 掩模处理 (只展示低纬度)
    mask = abs(LAT) > 50;
    Map_Re(mask) = NaN;
    Map_Im(mask) = NaN;
end

function plot_single_map(ax, LON, LAT, Data, clims, cfg)
    % 绘制单个 Robinson 投影地图
    axes(ax);
    m_proj('robinson', 'lon', [0 360]);
    m_pcolor(LON, LAT, Data); shading interp;
    m_coast('color', [0.15 0.15 0.15], 'LineWidth', 0.4);
    m_grid('xtick', [], 'ytick', [], 'linestyle', 'none', 'box', 'on');
    colormap(ax, cfg.cmap);
    clim(ax, clims);
end

%% ========================================================================
%                      以下为您提供的核心读取函数 (复用)
%% ========================================================================

function D = load_h5_forward_model(filepath, const)
    if ~isfile(filepath), error('找不到文件: %s', filepath); end
    try
        Re_Ht_r = h5read(filepath, '/Re_Ht_r');
        Im_Ht_r = h5read(filepath, '/Im_Ht_r');
        Theta   = h5read(filepath, '/Theta');
        Phi     = h5read(filepath, '/Phi');
        field_nT = (double(Re_Ht_r) + 1i * double(Im_Ht_r)) * (4 * pi * 100);
    catch ME
        error('H5 读取失败: %s', ME.message);
    end
    coeffs = sha_solver_vectorized(double(Theta(:)), double(Phi(:)), double(field_nT(:)), const.a_radius, const);
    D = coeffs_to_standard_format(coeffs, const.N_max);
end

function D = coeffs_to_standard_format(coeffs, N_max)
    D = []; idx = 1;
    for n = 1:N_max
        num_m = 2*n + 1;
        c_n = coeffs(idx : idx + num_m - 1);
        D = [D; n, 0, real(c_n(1)), imag(c_n(1))]; % m=0
        for m = 1:n
            D = [D; n, m, real(c_n(2*m)), imag(c_n(2*m))];     % cos
            D = [D; n, -m, real(c_n(2*m+1)), imag(c_n(2*m+1))]; % sin
        end
        idx = idx + num_m;
    end
end

function coeffs = sha_solver_vectorized(colat, lon, data, r_data, const)
    N_max = const.N_max; a = const.a_radius;
    n_pts = length(colat); n_coeffs = N_max * (N_max + 2);
    A = zeros(n_pts, n_coeffs); col_idx = 1;
    rad_ratio = a / r_data; cos_colat = cosd(colat);
    for n = 1:N_max
        radial_term = (n + 1) * (rad_ratio)^(n + 2);
        P = legendre(n, cos_colat', 'sch');
        for m = 0:n
            P_nm = P(m+1, :)';
            term_common = radial_term * P_nm;
            if m == 0
                A(:, col_idx) = term_common; col_idx = col_idx + 1;
            else
                A(:, col_idx) = term_common .* cosd(m * lon); col_idx = col_idx + 1;
                A(:, col_idx) = term_common .* sind(m * lon); col_idx = col_idx + 1;
            end
        end
    end
    coeffs = A \ data;
end

function D = load_coeffs_robust(fname, label, nskip)
    if ~isfile(fname), warning('找不到: %s', fname); D = []; return; end
    try
        if contains(fname, '.csv')
            T = readtable(fname);
            vars = T.Properties.VariableNames;
            idx_n = find(strcmpi(vars,'n')|strcmpi(vars,'Degree')|strcmpi(vars,'Degree_n'),1);
            idx_m = find(strcmpi(vars,'m')|strcmpi(vars,'Order')|strcmpi(vars,'Order_m'),1);
            idx_re = find(strcmpi(vars,'Real')|strcmpi(vars,'Real_Part'),1);
            idx_im = find(strcmpi(vars,'Imag')|strcmpi(vars,'Imag_Part'),1);
            D = [T{:, idx_n}, T{:, idx_m}, T{:, idx_re}, T{:, idx_im}];
        else
            raw = readmatrix(fname, 'NumHeaderLines', nskip);
            D = raw(:, 1:4);
        end
    catch ME
        warning('%s 读取失败', label); D = [];
    end
end