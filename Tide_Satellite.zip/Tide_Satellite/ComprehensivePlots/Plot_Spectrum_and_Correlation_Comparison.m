function Plot_Spectrum_and_Correlation_Comparison()
    % -------------------------------------------------------------------------
    % Purpose: 比较 Ours (New), Ours (Old), HRM2, CM6, Kalman, GO19 与 正演模型
    %          1. 左图: 功率谱对比 (Power Spectrum)
    %          2. 右图: 阶相关系数对比 (Correlation vs Forward)
    % -------------------------------------------------------------------------
    clc; close all;

    %% ========= 1. 参数与文件配置 =========
    % 物理常数 (用于H5文件球谐分析)
    const.a_radius = 6371.2;  % 地球半径 (km)
    const.N_max    = 40;      % 最大球谐阶数
    
    % 模型文件定义 {文件名, 标签, 表头行数, 线条颜色, 标记符号}
    models = {
        % --- 新添加的优化结果 (红色, 星号) ---
        '潮汐磁场结果/MultiSat_Result_HighVol_Strict.csv',      'Ours', 1,  [0.90, 0.10, 0.10], '-*'; 
        
        % --- 原有结果 ---
        % '潮汐磁场结果/SH_coefficients_M2_28_all.txt',           'Ours (Old)', 0,  [0.85, 0.33, 0.10], '-o'; % 橙红
        'Grayver_result/HRM2.txt',                              'HRM2',     10, [0.00, 0.45, 0.74], '-^'; % 蓝
        'CM6/M2.txt',                                           'CM6',      7,  [0.47, 0.67, 0.19], '-s'; % 绿
        'Kalman_result/M2/Model/TIDALM2_MEAN_Radius_6371.2.txt','Kalman',   0,  [0.49, 0.18, 0.56], '-d'; % 紫
        'GO19/M2.txt',                                          'GO19',     10, [0.93, 0.69, 0.13], '-p'; % 黄/金
    };

    % 正演参考模型 (Reference) - H5格式
    file_Fwd = '正演模拟结果/KUV_RES_0001.h5'; 
    is_Fwd_H5 = true;  % 标记正演模型是否为H5格式
    %% 
    c_Fwd    = [0.2, 0.2, 0.2]; % 深灰

    % 截断阶数
    Max_N = 36;
    
    %% ========= 2. 数据读取 =========
    fprintf('正在读取所有模型数据...\n');
    
    % 读取参考模型 (H5格式)
    if is_Fwd_H5
        fprintf('  - Loading Forward (H5 format)...\n');
        Dat_Fwd = load_h5_forward_model(file_Fwd, const);
    else
        Dat_Fwd = load_coeffs_robust(file_Fwd, 'Forward', 0);
    end
    
    % 检查正演模型数据完整性
    if ~isempty(Dat_Fwd)
        fprintf('  Forward model: %d coefficients loaded\n', size(Dat_Fwd, 1));
        check_coefficient_completeness(Dat_Fwd, Max_N, 'Forward');
    end
    
    % 读取待评估模型
    num_models = size(models, 1);
    Model_Data = cell(num_models, 1);
    
    for i = 1:num_models
        fname = models{i, 1};
        label = models{i, 2};
        nskip = models{i, 3};
        fprintf('  - Loading %s ...\n', label);
        Model_Data{i} = load_coeffs_robust(fname, label, nskip);
        
        % 检查模型数据完整性
        if ~isempty(Model_Data{i})
            check_coefficient_completeness(Model_Data{i}, Max_N, label);
        end
    end

    %% ========= 3. 计算指标 =========
    fprintf('正在计算功率谱和相关系数...\n');
    
    % 计算 Reference 的功率谱
    [Rn_Fwd, n_vec] = compute_Rn_matrix(Dat_Fwd, Max_N);
    
    % 存储结果结构体
    Results = struct('Rn', {}, 'rho', {}, 'label', {}, 'color', {}, 'marker', {});
    
    for i = 1:num_models
        dat = Model_Data{i};
        
        % 1. 功率谱
        [rn, ~] = compute_Rn_matrix(dat, Max_N);
        
        % 2. 相关系数 (vs Forward)
        rho = compute_rho_n_aligned(dat, Dat_Fwd, Max_N);
        
        Results(i).Rn = rn;
        Results(i).rho = rho;
        Results(i).label = models{i, 2};
        Results(i).color = models{i, 4};
        Results(i).marker = models{i, 5};
    end

    %% ========= 4. 绘图 =========
    fig = figure('Units', 'centimeters', 'Position', [5, 5, 17, 9.5], 'Color', 'w');
    t = tiledlayout(1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

    % --- Left Subplot: Power Spectrum ---
    ax1 = nexttile;
    hold(ax1, 'on'); box(ax1, 'on'); grid(ax1, 'on');
    
    % 绘制 Reference
    plot(n_vec, Rn_Fwd, '-', 'Color', c_Fwd, 'LineWidth', 2.5, 'DisplayName', 'Forward');
    
    % 绘制 Models
    for i = 1:num_models
        R = Results(i);
        plot(n_vec, R.Rn, R.marker, 'Color', R.color, 'LineWidth', 1.2, ...
             'MarkerSize', 5, 'MarkerFaceColor', 'w', 'DisplayName', R.label);
    end

    set(ax1, 'YScale', 'log');
    xlim(ax1, [1, Max_N]); xticks(ax1, 1:2:Max_N);
    xlabel(ax1, 'Degree {\itn}', 'FontWeight', 'bold');
    ylabel(ax1, 'Power Spectrum {\itR}_{\itn} (nT^2)', 'FontWeight', 'bold');
    title(ax1, '(a) Power Spectra', 'FontWeight', 'bold');
    legend(ax1, 'Location', 'southwest', 'FontSize', 7, 'Box', 'off', 'NumColumns', 2);

    % --- Right Subplot: Correlation ---
    ax2 = nexttile;
    hold(ax2, 'on'); box(ax2, 'on'); grid(ax2, 'on');
    
    % 绘制 Correlations
    for i = 1:num_models
        R = Results(i);
        plot(n_vec, R.rho, R.marker, 'Color', R.color, 'LineWidth', 1.2, ...
             'MarkerSize', 5, 'MarkerFaceColor', 'w', 'DisplayName', R.label);
    end

    xlim(ax2, [1, Max_N]); xticks(ax2, 1:2:Max_N);
    ylim(ax2, [0, 1.05]);
    xlabel(ax2, 'Degree {\itn}', 'FontWeight', 'bold');
    ylabel(ax2, 'Correlation \rho_{\itn}', 'FontWeight', 'bold');
    title(ax2, '(b) Correlation w.r.t Forward', 'FontWeight', 'bold');
    
    % 简单的 Reference 线 (y=1)
    yline(ax2, 1, '-', 'Color', [0.5 0.5 0.5], 'HandleVisibility', 'off');
    
    legend(ax2, 'Location', 'best', 'FontSize', 7, 'Box', 'off', 'NumColumns', 2);

    % 导出
    exportgraphics(fig, 'Spectrum_Corr_Comparison_New.png', 'Resolution', 600);
    fprintf('绘图完成，已保存为 Spectrum_Corr_Comparison_New.pdf\n');
end

%% ========================================================================
%                               H5正演模型读取
%% ========================================================================
function D = load_h5_forward_model(filepath, const)
    % 读取H5格式的正演模型，并转换为球谐系数 [n, m, Re, Im] 格式
    if ~isfile(filepath)
        error('找不到文件: %s', filepath);
    end
    
    try
        Re_Ht_r = h5read(filepath, '/Re_Ht_r');
        Im_Ht_r = h5read(filepath, '/Im_Ht_r');
        Theta   = h5read(filepath, '/Theta');
        Phi     = h5read(filepath, '/Phi');
        
        field_val = double(Re_Ht_r) + 1i * double(Im_Ht_r);
        % 单位转换 (A/m -> nT)
        unit_factor = 4 * pi * 100;
        field_nT = field_val * unit_factor;
    catch ME
        error('H5 读取失败: %s', ME.message);
    end
    
    Theta = double(Theta(:));
    Phi = double(Phi(:));
    Data = double(field_nT(:));
    
    % 确定半径
    if contains(filepath, '450Km')
        r_data = const.a_radius + 450;
    elseif contains(filepath, '200Km')
        r_data = const.a_radius + 200;
    else
        r_data = const.a_radius;
    end
    
    % 球谐分析
    coeffs = sha_solver_vectorized(Theta, Phi, Data, r_data, const);
    
    % 将系数转换为 [n, m, Re, Im] 格式
    D = coeffs_to_standard_format(coeffs, const.N_max);
end

function coeffs = sha_solver_vectorized(colat, lon, data, r_data, const)
    % 向量化的球谐分析求解器
    N_max = const.N_max;
    a = const.a_radius;
    n_pts = length(colat);
    n_coeffs = N_max * (N_max + 2);
    A = zeros(n_pts, n_coeffs);
    col_idx = 1;
    rad_ratio = a / r_data;
    cos_colat = cosd(colat);
    
    for n = 1:N_max
        radial_term = (n + 1) * (rad_ratio)^(n + 2);
        P = legendre(n, cos_colat', 'sch');
        for m = 0:n
            P_nm = P(m+1, :)';
            term_common = radial_term * P_nm;
            if m == 0
                A(:, col_idx) = term_common;
                col_idx = col_idx + 1;
            else
                A(:, col_idx) = term_common .* cosd(m * lon);
                col_idx = col_idx + 1;
                A(:, col_idx) = term_common .* sind(m * lon);
                col_idx = col_idx + 1;
            end
        end
    end
    coeffs = A \ data;
end

function D = coeffs_to_standard_format(coeffs, N_max)
    % 将球谐系数向量转换为 [n, m, Re, Im] 标准格式
    % 注意：此格式与 compute_Rn_matrix 兼容
    D = [];
    idx = 1;
    for n = 1:N_max
        num_m = 2*n + 1;
        c_n = coeffs(idx : idx + num_m - 1);
        
        % m = 0 (第一个系数)
        D = [D; n, 0, real(c_n(1)), imag(c_n(1))];
        
        % m = 1 to n (正负m交替)
        for m = 1:n
            % 正m (余弦项系数)
            D = [D; n, m, real(c_n(2*m)), imag(c_n(2*m))];
            % 负m (正弦项系数)
            D = [D; n, -m, real(c_n(2*m+1)), imag(c_n(2*m+1))];
        end
        idx = idx + num_m;
    end
end

function D = load_coeffs_robust(fname, label, nskip)
    if ~isfile(fname), warning('找不到: %s', fname); D = []; return; end
    
    try
        if contains(fname, '.csv')
            T = readtable(fname);
            % 自动识别列名 (兼容 n/Degree, m/Order, Real/Real_Part, Imag/Imag_Part)
            vars = T.Properties.VariableNames;
            
            idx_n = find(strcmpi(vars, 'n') | strcmpi(vars, 'Degree') | strcmpi(vars, 'Degree_n'), 1);
            idx_m = find(strcmpi(vars, 'm') | strcmpi(vars, 'Order')  | strcmpi(vars, 'Order_m'), 1);
            idx_re = find(strcmpi(vars, 'Real') | strcmpi(vars, 'Real_Part'), 1);
            idx_im = find(strcmpi(vars, 'Imag') | strcmpi(vars, 'Imag_Part'), 1);
            
            if isempty(idx_n) || isempty(idx_m)
                % 如果没有列名，按前四列默认读取
                D = T{:, 1:4};
            else
                D = [T{:, idx_n}, T{:, idx_m}, T{:, idx_re}, T{:, idx_im}];
            end
            
        elseif contains(label, 'Kalman')
            raw = readmatrix(fname);
            D = reconstruct_kalman_structure(raw);
        else
            % 标准文本格式读取
            raw = readmatrix(fname, 'NumHeaderLines', nskip);
            D = raw(:, 1:4);
        end
    catch ME
        warning('%s 读取失败: %s', label, ME.message);
        D = [];
    end
end

function D = reconstruct_kalman_structure(raw)
    % 将 Kalman 的 flat 列表转换为 [n, m, Re, Im]
    n_rows = size(raw, 1);
    re_vals = raw(:, 1);
    im_vals = raw(:, 2);
    D = [];
    current_idx = 1;
    n = 1;
    while current_idx <= n_rows
        num_coeffs = 2*n + 1;
        if current_idx + num_coeffs - 1 > n_rows, break; end
        
        block_re = re_vals(current_idx : current_idx + num_coeffs - 1);
        block_im = im_vals(current_idx : current_idx + num_coeffs - 1);
        
        m_list = zeros(num_coeffs, 1);
        m_list(1) = 0;
        ptr = 2;
        for k = 1:n
            m_list(ptr) = k; m_list(ptr+1) = -k; ptr = ptr + 2;
        end
        
        n_col = repmat(n, num_coeffs, 1);
        chunk = [n_col, m_list, block_re, block_im];
        D = [D; chunk]; %#ok<AGROW>
        current_idx = current_idx + num_coeffs;
        n = n + 1;
    end
end

%% ========================================================================
%                               计算函数
% ========================================================================
function [Rn, n_list] = compute_Rn_matrix(Data, max_n)
    if isempty(Data), Rn=[]; n_list=[]; return; end
    n_list = (1:max_n)';
    Rn = zeros(max_n, 1);
    
    for k = 1:max_n
        n = n_list(k);
        idx = (Data(:,1) == n);
        if ~any(idx), continue; end
        
        Re = Data(idx, 3);
        Im = Data(idx, 4);
        
        sum_sq = sum(Re.^2 + Im.^2);
        % 使用与 Analysis_Power_Spectrum_Layers.m 中 calculate_spectrum 相同的公式
        % Rn = (n + 1) * sum(|c_n|^2)
        Rn(k) = (n + 1) * sum_sq;
    end
end

function rho = compute_rho_n_aligned(E, R, nmax)
    % ========================================================================
    % 优化后的阶相关系数计算 (支持复数相位对齐)
    % E: 估计模型 [n, m, Re, Im]
    % R: 参考模型 [n, m, Re, Im]
    % ========================================================================
    if isempty(E) || isempty(R)
        rho = nan(nmax,1); return;
    end

    rho = zeros(nmax,1);

    for n = 1:nmax
        % 提取该阶数下所有的 m (-n 到 n)
        Em = []; Rm = [];
        
        for m = -n:n
            % 获取复数系数 c_nm = Re + i*Im
            ze = get_iota(E, n, m);
            zr = get_iota(R, n, m);
            Em = [Em; ze];
            Rm = [Rm; zr];
        end

        % 计算能量
        Pe = sum(abs(Em).^2);
        Pr = sum(abs(Rm).^2);

        if Pe < 1e-15 || Pr < 1e-15
            rho(n) = 0;
            continue;
        end

        % --- 关键公式：复数内积的归一化模 ---
        % 这等效于：在计算相关性前，先旋转模型 E 的相位使其与 R 最匹配
        % rho = |<E, R>| / (||E|| * ||R||)
        dot_product = sum(Em .* conj(Rm));
        rho(n) = abs(dot_product) / sqrt(Pe * Pr);
    end
end


function z = get_iota(Data, n, m)
    % 从数据矩阵中提取指定(n,m)的复数球谐系数
    % Data格式: [n, m, Re, Im]
    idx = find(Data(:,1)==n & Data(:,2)==m, 1);
    if isempty(idx)
        z = 0;  % 如果找不到系数，返回0（相当于该系数缺失）
    else
        z = Data(idx, 3) + 1i * Data(idx, 4);
    end
end

function check_coefficient_completeness(Data, max_n, label)
    % 检查球谐系数数据的完整性
    % 对于每个阶数n，检查是否包含所有m值（-n到n）
    
    fprintf('    Checking %s coefficient completeness...\n', label);
    
    total_expected = 0;
    total_found = 0;
    
    for n = 1:max_n
        expected = 2*n + 1;  % m = -n, -n+1, ..., 0, ..., n-1, n
        found = 0;
        
        for m = -n:n
            idx = find(Data(:,1)==n & Data(:,2)==m, 1);
            if ~isempty(idx)
                found = found + 1;
            end
        end
        
        total_expected = total_expected + expected;
        total_found = total_found + found;
        
        if found < expected
            fprintf('      n=%d: %d/%d coefficients found (missing %d)\n', ...
                n, found, expected, expected - found);
        end
    end
    
    fprintf('    Total: %d/%d coefficients (%.1f%%)\n', ...
        total_found, total_expected, 100*total_found/total_expected);
end