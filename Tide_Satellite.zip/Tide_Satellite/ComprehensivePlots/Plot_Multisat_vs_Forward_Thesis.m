function Plot_Multisat_vs_Forward_Thesis()
% -------------------------------------------------------------------------
% Purpose: 多星联合反演结果 vs 正演模型对比图（毕业论文版）
% Layout:  4行 × 3列
%          列：Br / Bt / Bp 三分量
%          行：实部-反演 | 实部-正演 | 虚部-反演 | 虚部-正演
%          实部与实部、虚部与虚部上下紧邻，便于目视对比
% 图幅：16.5cm × 18cm，适合论文单栏排版
% -------------------------------------------------------------------------

clc; clear; close all;

%% ========================= 1. 参数配置 =========================
% --- 反演结果文件 ---
csv_file = '潮汐磁场结果/MultiSat_Result_HighVol_Strict.csv';

% --- 正演模型文件 ---
fwd_file = '正演模拟结果/KUV_RES_0001.h5';
fwd_const.a_radius = 6371.2;
fwd_const.N_max    = 40;

% --- 通用参数 ---
a      = 6371.2;    % 地球半径 (km)
alt_km = 450;       % 绘图高度 (km)
res_deg = 1.5;      % 网格分辨率 (度)，适当降低以加快计算
N_max_inv = 32;     % 反演球谐阶数

%% ========================= 2. 读取反演结果 =========================
fprintf('1. 读取反演系数: %s ...\n', csv_file);
if ~isfile(csv_file), error('未找到文件: %s', csv_file); end

T = readtable(csv_file);
U_est = zeros(2 * height(T), 1);
U_est(1:2:end) = T.Real;
U_est(2:2:end) = T.Imag;
coeffs_inv = U_est(1:2:end) + 1i * U_est(2:2:end);

%% ========================= 3. 读取正演模型 =========================
fprintf('2. 读取正演模型: %s ...\n', fwd_file);
Dat_Fwd = load_h5_forward_model(fwd_file, fwd_const);
coeffs_fwd_complex = Dat_Fwd(:,3) + 1i * Dat_Fwd(:,4);

%% ========================= 4. 构建网格与 K 矩阵 =========================
fprintf('3. 构建坐标网格 (Res: %.1f deg)...\n', res_deg);

lon_vec = 0:res_deg:360;
lat_vec = -89:res_deg:89;
[LON, LAT] = meshgrid(lon_vec, lat_vec);

r_plot  = (a + alt_km) * ones(size(LON));
coords  = [r_plot(:), 90-LAT(:), LON(:)];

fprintf('4. 构建 K 矩阵（共3个分量，稍等）...\n');
[Kr, Kt, Kp] = build_K_matrix_paper(coords, ...
    ones(numel(LON),1), zeros(numel(LON),1), N_max_inv, a);

% --- 正演 K 矩阵（若阶数不同则单独构建）---
N_max_fwd = max(Dat_Fwd(:,1));
if N_max_fwd ~= N_max_inv
    fprintf('   正演阶数 (%d) 与反演不同，单独构建正演 K 矩阵...\n', N_max_fwd);
    [Kr_f, Kt_f, Kp_f] = build_K_matrix_paper(coords, ...
        ones(numel(LON),1), zeros(numel(LON),1), N_max_fwd, a);
else
    Kr_f = Kr; Kt_f = Kt; Kp_f = Kp;
end

%% ========================= 5. 合成磁场 =========================
fprintf('5. 合成三分量磁场...\n');

% 反演结果（实部/虚部均来自复数系数）
Br_inv = reshape(Kr(:,1:2:end) * coeffs_inv,  size(LON));
Bt_inv = reshape(Kt(:,1:2:end) * coeffs_inv,  size(LON));
Bp_inv = reshape(Kp(:,1:2:end) * coeffs_inv,  size(LON));

% 正演结果
Br_fwd = reshape(Kr_f(:,1:2:end) * coeffs_fwd_complex, size(LON));
Bt_fwd = reshape(Kt_f(:,1:2:end) * coeffs_fwd_complex, size(LON));
Bp_fwd = reshape(Kp_f(:,1:2:end) * coeffs_fwd_complex, size(LON));

%% ========================= 6. 绘图 =========================
fprintf('6. 绘制对比图...\n');

% -------------------------------------------------------------------------
% 新布局：4行 × 3列
%
%   列：    B_r          B_θ          B_φ
%  ─────────────────────────────────────────
%  行1 实部  Inv Real  |  Inv Real  |  Inv Real    ← 实部组（Inversion）
%  行2 实部  Fwd Real  |  Fwd Real  |  Fwd Real    ← 实部组（Forward）
%  ─────────────────────────────────────────（水平分隔线）
%  行3 虚部  Inv Imag  |  Inv Imag  |  Inv Imag    ← 虚部组（Inversion）
%  行4 虚部  Fwd Imag  |  Fwd Imag  |  Fwd Imag    ← 虚部组（Forward）
%
% 优点：实部与实部、虚部与虚部在垂直方向紧邻，便于目视比较空间结构。
% 图幅：16.5cm × 18cm，适合论文单栏排版。
% -------------------------------------------------------------------------

% --- 图幅 ---
fig = figure('Color', 'w', 'Units', 'centimeters', 'Position', [2, 2, 16.5, 14.5]);

% 4行 × 3列，行间距略微打开以便插入分组标注
t = tiledlayout(fig, 4, 3, 'TileSpacing', 'none', 'Padding', 'compact');

% --- 色标范围（同一分量实虚部共用，确保对比公平）---
clim_Br = [-1.5, 1.5];
clim_Bt = [-1.0, 1.0];
clim_Bp = [-1.0, 1.0];
comp_clims = {clim_Br, clim_Bt, clim_Bp};   % 按列索引

% --- 数据组织：4行 × 3列
%   row 1: 反演实部  (Inv Real)
%   row 2: 正演实部  (Fwd Real)
%   row 3: 反演虚部  (Inv Imag)
%   row 4: 正演虚部  (Fwd Imag)
%   col 1: Br  |  col 2: Bt  |  col 3: Bp
data_grid = {
    real(Br_inv), real(Bt_inv), real(Bp_inv);   % row 1
    real(Br_fwd), real(Bt_fwd), real(Bp_fwd);   % row 2
    imag(Br_inv), imag(Bt_inv), imag(Bp_inv);   % row 3
    imag(Br_fwd), imag(Bt_fwd), imag(Bp_fwd);   % row 4
};

% --- 行左侧标注 ---
row_labels = {'Inv.', 'Fwd.', 'Inv.', 'Fwd.'};

% --- 列顶部标注（第1行显示分量名）---
col_titles = {'B_r', 'B_\theta', 'B_\phi'};

% --- 颜色方案 ---
try
    cmap = nclCM('CBR_coldhot');
catch
    cmap = custom_bluewhitered(256);
end

% ---- 逐格绘制 ----
for row = 1:4
    for col = 1:3
        ax = nexttile(t);

        Data  = data_grid{row, col};
        clims = comp_clims{col};

        plot_map_robinson(ax, LON, LAT, Data, clims, cmap);

        % 列标题（仅第1行）
        if row == 1
            title(ax, col_titles{col}, 'FontSize', 10, 'FontWeight', 'bold');
        end

        % 行标（仅第1列）
        if col == 1
            ylabel(ax, row_labels{row}, ...
                'FontSize', 9, 'FontWeight', 'bold', ...
                'Rotation', 0, 'HorizontalAlignment', 'right', ...
                'VerticalAlignment', 'middle');
        end
    end
end

% ---- 分组大标注：利用 annotation 在归一化坐标标注 Real / Imaginary ----
% 需要先 drawnow 以确保 tiledlayout 完成渲染，获取准确位置
drawnow;

% 获取第1行第1格和第3格的位置，计算"Real Part"标注的 x/y 范围
ax_r1c1 = t.Children(end);          % nexttile 顺序：最后添加的在 Children(1)
% 用固定归一化坐标近似（可根据实际输出微调）
% Real Part 组：覆盖第1-2行
annotation(fig, 'textbox', [0.01, 0.955, 0.06, 0.03], ...
    'String', 'Real', ...
    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
    'FontSize', 9, 'FontWeight', 'bold', 'FontAngle', 'italic', ...
    'EdgeColor', 'none', 'BackgroundColor', 'none', 'Color', [0.15 0.35 0.60]);

% Imaginary Part 组：覆盖第3-4行
annotation(fig, 'textbox', [0.01, 0.465, 0.06, 0.03], ...
    'String', 'Imag', ...
    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
    'FontSize', 9, 'FontWeight', 'bold', 'FontAngle', 'italic', ...
    'EdgeColor', 'none', 'BackgroundColor', 'none', 'Color', [0.60 0.15 0.15]);

% 实部/虚部之间加一条水平分隔线（在第2行与第3行之间，约 y=0.50）
annotation(fig, 'line', [0.08, 0.98], [0.50, 0.50], ...
    'LineStyle', '--', 'Color', [0.55 0.55 0.55], 'LineWidth', 0.8);

% ---- 底部统一色标（3个，每列一个，与列对齐）----
cb_y  = 0.1;
cb_h  = 0.016;
cb_w  = 0.16;
cb_xs = [0.1412, 0.43, 0.72];   % 3列对应的色标 x 起点

comp_cb_info = {
    clim_Br, 'B_r (nT)',       [-1.5, 0, 1.5];
    clim_Bt, 'B_\theta (nT)',  [-1.0, 0, 1.0];
    clim_Bp, 'B_\phi (nT)',    [-1.0, 0, 1.0];
};

for k = 1:3
    ax_cb = axes(fig, 'Position', [cb_xs(k), cb_y, cb_w, cb_h], 'Visible', 'off');
    colormap(ax_cb, cmap);
    clim(ax_cb, comp_cb_info{k,1});
    cb = colorbar(ax_cb, 'Location', 'southoutside');
    cb.FontSize   = 8;
    cb.Ticks      = comp_cb_info{k,3};
    cb.Label.String = comp_cb_info{k,2};
    cb.Label.FontSize = 8;
    cb.TickDirection  = 'out';
end

%% ========================= 7. 导出 =========================
out_png = 'Multisat_vs_Forward_Comparison.png';
out_pdf = 'Multisat_vs_Forward_Comparison.pdf';
exportgraphics(fig, out_png, 'Resolution', 600);
exportgraphics(fig, out_pdf, 'Resolution', 600);
fprintf('图表已保存: %s / %s\n', out_png, out_pdf);

end

%% =========================================================================
%                         绘图辅助函数
%% =========================================================================
function plot_map_robinson(ax, LON, LAT, Data, clims, cmap)
    axes(ax);
    m_proj('robinson', 'lon', [0 360]);
    if all(isnan(Data(:)))
        m_grid('box','on','xtick',[],'ytick',[],'linestyle','none');
        return;
    end
    m_pcolor(LON, LAT, Data);
    shading interp;
    m_coast('color', [0.2 0.2 0.2], 'LineWidth', 0.4);
    m_grid('xtick', [], 'ytick', [], 'linestyle', 'none', 'box', 'on');
    colormap(ax, cmap);
    clim(ax, clims);
end

%% =========================================================================
%                    正演模型读取函数（复用自对比脚本）
%% =========================================================================
function D = load_h5_forward_model(filepath, const)
    if ~isfile(filepath), error('找不到文件: %s', filepath); end
    try
        Re_Ht_r = h5read(filepath, '/Re_Ht_r');
        Im_Ht_r = h5read(filepath, '/Im_Ht_r');
        Theta   = h5read(filepath, '/Theta');
        Phi     = h5read(filepath, '/Phi');
        field_nT = (double(Re_Ht_r) + 1i * double(Im_Ht_r)) * (4 * pi * 100);
    catch ME
        error('H5 读取失败: %s', ME.message);
    end
    coeffs = sha_solver_vectorized(double(Theta(:)), double(Phi(:)), ...
                                   double(field_nT(:)), const.a_radius, const);
    D = coeffs_to_standard_format(coeffs, const.N_max);
end

function D = coeffs_to_standard_format(coeffs, N_max)
    D = []; idx = 1;
    for n = 1:N_max
        num_m = 2*n + 1;
        c_n   = coeffs(idx : idx + num_m - 1);
        D = [D; n, 0, real(c_n(1)), imag(c_n(1))];
        for m = 1:n
            D = [D; n,  m, real(c_n(2*m)),   imag(c_n(2*m))];
            D = [D; n, -m, real(c_n(2*m+1)), imag(c_n(2*m+1))];
        end
        idx = idx + num_m;
    end
end

function coeffs = sha_solver_vectorized(colat, lon, data, r_data, const)
    N_max = const.N_max; a = const.a_radius;
    n_pts    = length(colat);
    n_coeffs = N_max * (N_max + 2);
    A        = zeros(n_pts, n_coeffs);
    col_idx  = 1;
    rad_ratio  = a / r_data;
    cos_colat  = cosd(colat);
    for n = 1:N_max
        radial_term = (n + 1) * (rad_ratio)^(n + 2);
        P = legendre(n, cos_colat', 'sch');
        for m = 0:n
            P_nm        = P(m+1, :)';
            term_common = radial_term * P_nm;
            if m == 0
                A(:, col_idx) = term_common; col_idx = col_idx + 1;
            else
                A(:, col_idx) = term_common .* cosd(m * lon); col_idx = col_idx + 1;
                A(:, col_idx) = term_common .* sind(m * lon); col_idx = col_idx + 1;
            end
        end
    end
    coeffs = A \ data;
end

%% =========================================================================
%                         备用色标函数
%% =========================================================================
function cmap = custom_bluewhitered(m)
    if nargin < 1, m = 256; end
    bottom = [0.230, 0.299, 0.754];
    middle = [0.960, 0.960, 0.960];
    top    = [0.706, 0.016, 0.150];
    half = floor(m/2);
    r = [linspace(bottom(1), middle(1), half)'; linspace(middle(1), top(1), m-half)'];
    g = [linspace(bottom(2), middle(2), half)'; linspace(middle(2), top(2), m-half)'];
    b = [linspace(bottom(3), middle(3), half)'; linspace(middle(3), top(3), m-half)'];
    cmap = [r, g, b];
end