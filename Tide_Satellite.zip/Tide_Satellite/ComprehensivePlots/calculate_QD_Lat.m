function QD_Lat = calculate_QD_Lat(B_vec, r_sat, Re)
% CALCULATE_QD_LAT 计算本地偶极子纬度 (Local Dipole Latitude)
% 
% 修改说明:
%   移除了 L-shell 映射到地表的步骤。
%   之前的版本计算的是磁力线足点纬度，导致卫星高度处无法对应赤道(0度)的磁力线，
%   从而在 +/- 16度之间产生数据空缺。
%   此版本返回卫星所在位置的等效偶极子纬度，赤道处为 0。

    % --- 1. 参数检查 ---
    if nargin < 3
        Re = 6371.2; 
    end
    
    % --- 2. 提取分量 ---
    Br = B_vec(:, 1);
    Bt = B_vec(:, 2);
    Bp = B_vec(:, 3);
    
    % --- 3. 计算水平分量 H 和总强度 F ---
    H = sqrt(Bt.^2 + Bp.^2);
    F = sqrt(Br.^2 + H.^2);
    
    % --- 4. 计算磁倾角的余弦平方 (cos^2 I) ---
    cos2_I = (H ./ F).^2;
    
    % --- 5. 计算本地磁余纬 (Local Dip Co-latitude) ---
    % sin^2(theta) = 4*cos^2(I) / (1 + 3*cos^2(I))
    sin2_theta_d = (4 * cos2_I) ./ (1 + 3 * cos2_I);
    
    % --- [修改点] 6. 不进行高度映射 ---
    % 我们直接使用卫星处的 theta，确保赤道处 (I=0) 对应纬度 0
    sin2_theta_QD = sin2_theta_d; 
    
    % --- 7. 解算纬度幅值 ---
    theta_QD_rad = asin(sqrt(sin2_theta_QD));
    lat_mag_abs = 90 - rad2deg(theta_QD_rad);
    
    % --- 8. 恢复正负号 ---
    sign_factor = -sign(Br);
    sign_factor(sign_factor == 0) = 1; 
    
    QD_Lat = lat_mag_abs .* sign_factor;

end