function [K_r, K_t, K_p] = build_K_matrix_paper(Pos, cos_t, sin_t, N_max, a)
    % �ϸ��Ӧ���Ĺ�ʽ 2-15 ~ 2-17
    % �Ż���: ֱ�ӹ�����ʵ���� (Dense Matrix)���Ƴ�ϡ��������
    
    n_pts = size(Pos, 1);
    r = Pos(:,1); 
    theta = Pos(:,2); 
    phi = Pos(:,3);
    
    % ���Ǻ���Ԥ����
    sin_th = sind(theta); 
    cos_th = cosd(theta);
    
    % ���㱣��
    pole_mask = abs(sin_th) < 1e-10;
    sin_th_safe = sin_th; 
    sin_th_safe(pole_mask) = 1e-10;
    inv_sin_th = 1 ./ sin_th_safe;
    
    % ����������
    total_coeffs = N_max * (N_max + 2);
    cols = total_coeffs * 2; % ʵ��(cos) + �鲿(sin)
    
    % ���ؼ��޸ġ�ֱ��Ԥ����ȫ�����ڴ� (Dense Matrix)
    K_r = zeros(n_pts, cols);
    K_t = zeros(n_pts, cols);
    K_p = zeros(n_pts, cols);
    
    col_cnt = 1; % �м�����
    
    % ��ֵ΢�ֲ���
    delta_deg = 1e-4;
    div_delta = 1 / (2 * deg2rad(delta_deg));
    theta_p = theta + delta_deg;
    theta_m = theta - delta_deg;
    
    for n = 1:N_max
        ratio_ar = (a ./ r).^(n+2);
        
        % ���Ĺ�ʽϵ��
        fac_r = (n+1) .* ratio_ar; 
        fac_t = -1    .* ratio_ar;
        fac_p = -1    .* ratio_ar;
        
        % Legendre ����������
        P_all = legendre(n, cos_th, 'sch');
        P_p = legendre(n, cosd(theta_p), 'sch');
        P_m = legendre(n, cosd(theta_m), 'sch');
        dP_all = (P_p - P_m) .* div_delta;
        
        for m = 0:n
            P_nm = P_all(m+1, :)'; 
            dP_nm = dP_all(m+1, :)';
            
            cos_mp = cosd(m * phi); 
            sin_mp = sind(m * phi);
            
            % ------------------------------------------------------------
            % 1. g_nm ���� (��Ӧ A_nm, C_nm)
            % ------------------------------------------------------------
            % �ռ���
            Sr = fac_r .* P_nm .* cos_mp;
            St = fac_t .* dP_nm .* cos_mp;
            % Bp: fac_p * inv_sin * P * (-m * sin)
            Sp = fac_p .* inv_sin_th .* P_nm .* (-m .* sin_mp);
            Sp(pole_mask) = 0; % ��������
            
            % --- ������� (Real Part: cos wt) ---
            K_r(:, col_cnt) = Sr .* cos_t;
            K_t(:, col_cnt) = St .* cos_t;
            K_p(:, col_cnt) = Sp .* cos_t;
            col_cnt = col_cnt + 1;
            
            % --- ������� (Imag Part: sin wt) ---
            K_r(:, col_cnt) = Sr .* sin_t;
            K_t(:, col_cnt) = St .* sin_t;
            K_p(:, col_cnt) = Sp .* sin_t;
            col_cnt = col_cnt + 1;
            
            % ------------------------------------------------------------
            % 2. h_nm ���� (��Ӧ B_nm, D_nm) - ���� m > 0
            % ------------------------------------------------------------
            if m > 0
                % �ռ���
                Sr = fac_r .* P_nm .* sin_mp;
                St = fac_t .* dP_nm .* sin_mp;
                % Bp: fac_p * inv_sin * P * (m * cos)
                Sp = fac_p .* inv_sin_th .* P_nm .* (m .* cos_mp);
                Sp(pole_mask) = 0;
                
                % --- ������� (Real Part: cos wt) ---
                K_r(:, col_cnt) = Sr .* cos_t;
                K_t(:, col_cnt) = St .* cos_t;
                K_p(:, col_cnt) = Sp .* cos_t;
                col_cnt = col_cnt + 1;
                
                % --- ������� (Imag Part: sin wt) ---
                K_r(:, col_cnt) = Sr .* sin_t;
                K_t(:, col_cnt) = St .* sin_t;
                K_p(:, col_cnt) = Sp .* sin_t;
                col_cnt = col_cnt + 1;
            end
        end
    end
end