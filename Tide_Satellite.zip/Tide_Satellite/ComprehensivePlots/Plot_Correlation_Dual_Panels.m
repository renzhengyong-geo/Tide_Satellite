function Plot_Correlation_Dual_Panels()
    % -------------------------------------------------------------------------
    % Purpose: 1行2列对比图
    %          左图：单星单模型计算结果 vs Model
    %          右图：综合结果Ours vs 外部模型 vs Model
    % -------------------------------------------------------------------------
    clc; clear; close all;

    % ================= 1. 参数与所有模型配置 =================
    const.a_radius = 6371.2;  
    const.N_max    = 30; 
    
    % 定义所有可能出现的模型
    full_config = {
        'CSV',    'Ørsted',     '潮汐磁场结果/Orsted_SH_Coefficients_With_Errors.csv',   0;
        'CSV',    'SAC-C',      '潮汐磁场结果/SACC_SH_Coefficients_With_Errors.csv',     0;
        'CSV',    'CHAMP',      '潮汐磁场结果/CHAMP_SH_Coefficients_With_Errors.csv',    0;
        'CSV',    'Swarm',      '潮汐磁场结果/Swarm_SH_Coefficients_With_Errors.csv',    0;
        'CSV',    'CryoSat-2',  '潮汐磁场结果/CryoSat_SH_Coefficients_With_Errors.csv',  0;
        'CSV',    'GRACE-FO',   '潮汐磁场结果/GraceFO_SH_Coefficients_base_ssg_csg.csv', 0;
        'CSV',    'MSS-1A',     '潮汐磁场结果/MSS_SH_Coefficients_With_Errors.csv',      0;
        'TXT_D',  'CM6',        'CM6/M2.txt',                                            7;
        'Kalman', 'Kalman',     'Kalman_result/M2/Model/TIDALM2_MEAN_Radius_6371.2.txt', 0;
        'TXT_D',  'GO19',       'GO19/M2.txt',                                           10;
        'TXT_D',  'HRM2',       'Grayver_result/HRM2.txt',                               10;
        'CSV',    'Ours',       '潮汐磁场结果/MultiSat_Result_HighVol_Strict.csv',       0;
        'H5',     'Model',      '正演模拟结果/KUV_RES_0001.h5',                          0;
    };

    % ================= 2. 预加载所有数据 =================
    fprintf('正在预加载所有模型数据...\n');
    all_data = struct();
    for k = 1:size(full_config, 1)
        fmt = full_config{k, 1}; name = full_config{k, 2}; fname = full_config{k, 3}; nskip = full_config{k, 4};
        try
            c = [];
            if strcmp(fmt, 'H5'),           c = get_forward_coeffs_h5(fname, const);
            elseif strcmp(fmt, 'CSV'),      c = get_csv_coeffs_real(fname);
            elseif strcmp(fmt, 'TXT_D'),    raw = readmatrix(fname, 'NumHeaderLines', nskip); 
                                            c = extract_1d_from_D(raw(:, 1:4));
            elseif strcmp(fmt, 'Kalman'),   raw = readmatrix(fname); 
                                            c = extract_1d_from_D(reconstruct_kalman_structure(raw));
            end
            if ~isempty(c)
                % 将非字母数字字符替换掉以作为结构体字段名
                clean_name = regexprep(name, '[^a-zA-Z0-9]', '_');
                all_data.(clean_name).vec = c(:);
                all_data.(clean_name).label = name;
            end
        catch
            fprintf('  [跳过] %s 加载失败\n', name);
        end
    end

    % ================= 3. 定义子图分组 =================
    % 左图：仅单星 + Model
    groupA = {'_rsted', 'SAC_C', 'CHAMP', 'Swarm', 'CryoSat_2', 'GRACE_FO', 'MSS_1A', 'Model'};
    
    % 右图：综合对比 Ours + 外部 + Model
    groupB = {'CM6', 'Kalman', 'GO19', 'HRM2', 'Ours', 'Model'};

    % ================= 4. 绘图 =================
    fig = figure('Color', 'w', 'Units', 'centimeters', 'Position', [2, 2, 32, 14]);
    tlo = tiledlayout(1, 2, 'TileSpacing', 'Loose', 'Padding', 'Compact');

    % --- 左子图：Single Satellites ---
    nexttile(tlo);
    plot_sub_heatmap(all_data, groupA, '(a) Single Satellite Models vs. Forward Model');

    % --- 右子图：Comparison ---
    nexttile(tlo);
    plot_sub_heatmap(all_data, groupB, '(b) Combined Result (Ours) vs. Research Models');

    % 导出
    exportgraphics(fig, 'Correlation_Dual_Panels.png', 'Resolution', 600);
    fprintf('绘图完成。\n');
end

% =========================================================================
%                               辅助绘图函数
% =========================================================================
function plot_sub_heatmap(all_data, group_keys, sub_title)
    % 提取子集数据
    valid_keys = {};
    for i = 1:length(group_keys)
        if isfield(all_data, group_keys{i})
            valid_keys{end+1} = group_keys{i}; %#ok<AGROW>
        end
    end
    
    num_vars = length(valid_keys);
    corr_mat = eye(num_vars);
    display_labels = cell(1, num_vars);
    
    % 计算两两相关性
    for i = 1:num_vars
        display_labels{i} = all_data.(valid_keys{i}).label;
        for j = i+1:num_vars
            v1 = all_data.(valid_keys{i}).vec;
            v2 = all_data.(valid_keys{j}).vec;
            min_len = min(length(v1), length(v2));
            if min_len > 1
                r = corrcoef(v1(1:min_len), v2(1:min_len));
                corr_mat(i, j) = r(1, 2);
                corr_mat(j, i) = r(1, 2);
            end
        end
    end

    % 绘制热力图
    h = heatmap(display_labels, display_labels, corr_mat);
    h.Colormap = nclCM('MPL_Greens');
    h.ColorLimits = [0.5, 1.1]; % 稍微收缩上限让颜色更深
    h.CellLabelFormat = '%.2f';
    h.FontSize = 10;
    h.Title = sub_title;
    h.ColorbarVisible = 'off';
end

% =========================================================================
%                               数据读取核心函数 (保留原有)
% =========================================================================
function c = get_forward_coeffs_h5(filepath, const)
    Re_Ht_r = h5read(filepath, '/Re_Ht_r');
    Im_Ht_r = h5read(filepath, '/Im_Ht_r');
    Theta   = h5read(filepath, '/Theta');
    Phi     = h5read(filepath, '/Phi');
    field_nT = (double(Re_Ht_r) + 1i * double(Im_Ht_r)) * (4 * pi * 100);
    r_data = const.a_radius; 
    if contains(filepath, '450Km'), r_data = r_data + 450; end
    coeffs = sha_solver_vectorized(double(Theta(:)), double(Phi(:)), field_nT(:), r_data, const);
    c = real(coeffs); 
end

function coeffs = sha_solver_vectorized(colat, lon, data, r_data, const)
    N_max = const.N_max; a = const.a_radius;
    A = zeros(length(colat), N_max * (N_max + 2));
    col_idx = 1; rad_ratio = a / r_data; cos_colat = cosd(colat);
    for n = 1:N_max
        radial_term = (n + 1) * (rad_ratio)^(n + 2);
        P = legendre(n, cos_colat', 'sch');
        for m = 0:n
            P_nm = P(m+1, :)'; term_common = radial_term * P_nm;
            if m == 0
                A(:, col_idx) = term_common; col_idx = col_idx + 1;
            else
                A(:, col_idx) = term_common .* cosd(m * lon); col_idx = col_idx + 1;
                A(:, col_idx) = term_common .* sind(m * lon); col_idx = col_idx + 1;
            end
        end
    end
    coeffs = A \ data;
end

function c = get_csv_coeffs_real(f)
    if ~isfile(f), c=[]; return; end
    T = readtable(f); v = T.Properties.VariableNames;
    if ismember('Real',v), c=T.Real; elseif ismember('Real_Part',v), c=T.Real_Part;
    elseif width(T)>=4, c=T{:,3}; else, c=[]; end
    if ~isempty(c), c(isnan(c))=0; end
end

function D = reconstruct_kalman_structure(raw)
    n_rows = size(raw, 1); re_vals = raw(:, 1); im_vals = raw(:, 2);
    D =[]; current_idx = 1; n = 1;
    while current_idx <= n_rows
        num_coeffs = 2*n + 1;
        if current_idx + num_coeffs - 1 > n_rows, break; end
        m_list = [0, reshape([1:n; -(1:n)], 1, [])];
        n_col = repmat(n, num_coeffs, 1);
        D = [D;[n_col, m_list, re_vals(current_idx:current_idx+num_coeffs-1), im_vals(current_idx:current_idx+num_coeffs-1)]];
        current_idx = current_idx + num_coeffs; n = n + 1;
    end
end

function vec = extract_1d_from_D(D)
    if isempty(D), vec =[]; return; end
    max_n = max(D(:,1)); vec =[];
    for n = 1:max_n
        idx0 = find(D(:,1)==n & D(:,2)==0, 1);
        if ~isempty(idx0), vec(end+1, 1) = D(idx0, 3); else, vec(end+1, 1) = 0; end
        for m = 1:n
            idx_pos = find(D(:,1)==n & D(:,2)==m, 1);
            if ~isempty(idx_pos), vec(end+1, 1) = D(idx_pos, 3); else, vec(end+1, 1) = 0; end
            idx_neg = find(D(:,1)==n & D(:,2)==-m, 1);
            if ~isempty(idx_neg), vec(end+1, 1) = D(idx_neg, 3); 
            elseif ~isempty(idx_pos) && size(D, 2) >= 4, vec(end+1, 1) = D(idx_pos, 4);
            else, vec(end+1, 1) = 0; end
        end
    end
end