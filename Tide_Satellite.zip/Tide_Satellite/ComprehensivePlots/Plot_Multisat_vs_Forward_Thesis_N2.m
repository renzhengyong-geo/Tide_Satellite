function Plot_Multisat_vs_Forward_Thesis_N2()
% -------------------------------------------------------------------------
% Purpose: 多星联合反演结果 (MAT) vs 正演模型 (DAT) 对比图（N2分潮）
% Layout:  4行 × 3列 (Br, Bt, Bp)
%          实部-反演 | 实部-正演 | 虚部-反演 | 虚部-正演
% -------------------------------------------------------------------------

clc; clear; close all;

%% ========================= 1. 参数配置 =========================
% --- 文件路径 ---
inv_file = '潮汐磁场结果/Joint_SwarmA_MSS1_EP_Result_N2.mat';
fwd_file = '正演模拟结果/n2/B_surface.dat';

% --- 物理与绘图参数 ---
const.a_radius = 6371.2;
const.N_max    = 15;        % 统一截断阶数
alt_km         = 450;       % 绘图高度 (km)
res_deg        = 1.5;       % 网格分辨率

%% ========================= 2. 读取数据 =========================
fprintf('1. 读取数据中...\n');

% --- A. 读取反演结果 (MAT格式) ---
fprintf('   - 加载反演模型: %s\n', inv_file);
D_inv = load_ours_mat_result(inv_file, const.N_max);

% --- B. 读取正演模型 (DAT格式) ---
fprintf('   - 加载正演模型并执行SHA: %s\n', fwd_file);
D_fwd = load_dat_forward_model(fwd_file, const);

% --- C. 转换为复数系数向量 (供 K 矩阵使用) ---
% 这里的顺序必须与 build_K_matrix_paper 内部生成的列顺序一致
coeffs_inv_complex = convert_to_complex_vector(D_inv, const.N_max);
coeffs_fwd_complex = convert_to_complex_vector(D_fwd, const.N_max);

%% ========================= 3. 构建网格与 K 矩阵 =========================
fprintf('2. 构建坐标网格与算子 (Res: %.1f deg)...\n', res_deg);

lon_vec = 0:res_deg:360;
lat_vec = -89:res_deg:89;
[LON, LAT] = meshgrid(lon_vec, lat_vec);

r_plot  = (const.a_radius + alt_km) * ones(size(LON));
coords  = [r_plot(:), 90-LAT(:), LON(:)];

% 构建 K 矩阵 (假设函数 build_K_matrix_paper 在路径中)
[Kr, Kt, Kp] = build_K_matrix_paper(coords, ...
    ones(numel(LON),1), zeros(numel(LON),1), const.N_max, const.a_radius);

%% ========================= 4. 合成磁场 =========================
fprintf('3. 合成三分量磁场...\n');

% 矩阵乘法合成 (coeffs 已经是复数，结果也是复数)
Br_inv_all = reshape(Kr(:,1:2:end) * coeffs_inv_complex, size(LON));
Bt_inv_all = reshape(Kt(:,1:2:end) * coeffs_inv_complex, size(LON));
Bp_inv_all = reshape(Kp(:,1:2:end) * coeffs_inv_complex, size(LON));

Br_fwd_all = reshape(Kr(:,1:2:end) * coeffs_fwd_complex, size(LON));
Bt_fwd_all = reshape(Kt(:,1:2:end) * coeffs_fwd_complex, size(LON));
Bp_fwd_all = reshape(Kp(:,1:2:end) * coeffs_fwd_complex, size(LON));

%% ========================= 5. 绘图布局 =========================
fprintf('4. 绘制对比图...\n');

fig = figure('Color', 'w', 'Units', 'centimeters', 'Position', [2, 2, 16.5, 14.5]);
t = tiledlayout(fig, 4, 3, 'TileSpacing', 'none', 'Padding', 'compact');

% 色标范围
clim_Br = [-0.5, 0.5]; clim_Bt = [-0.3, 0.3]; clim_Bp = [-0.3, 0.3];
comp_clims = {clim_Br, clim_Bt, clim_Bp};

% 数据矩阵: 4行(Inv_Re, Fwd_Re, Inv_Im, Fwd_Im) x 3列(Br, Bt, Bp)
data_grid = {
    real(Br_inv_all), real(Bt_inv_all), real(Bp_inv_all); % Row 1
    real(Br_fwd_all), real(Bt_fwd_all), real(Bp_fwd_all); % Row 2
    imag(Br_inv_all), imag(Bt_inv_all), imag(Bp_inv_all); % Row 3
    imag(Br_fwd_all), imag(Bt_fwd_all), imag(Bp_fwd_all); % Row 4
};

row_labels = {'Inv.', 'Fwd.', 'Inv.', 'Fwd.'};
col_titles = {'B_r', 'B_\theta', 'B_\phi'};
cmap = nclCM('CBR_coldhot');

for row = 1:4
    for col = 1:3
        ax = nexttile(t);
        plot_map_robinson(ax, LON, LAT, data_grid{row, col}, comp_clims{col}, cmap);
        
        if row == 1, title(ax, col_titles{col}, 'FontSize', 10, 'FontWeight', 'bold'); end
        if col == 1
            ylabel(ax, row_labels{row}, 'FontSize', 9, 'FontWeight', 'bold', ...
                'Rotation', 0, 'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle');
        end
    end
end

% --- 装饰标注与色标 (保留原代码逻辑) ---
drawnow;
annotation(fig, 'textbox', [0.01, 0.955, 0.06, 0.03], 'String', 'Real', ...
    'HorizontalAlignment', 'center', 'EdgeColor', 'none', 'FontWeight', 'bold', 'Color', [0.15 0.35 0.60]);
annotation(fig, 'textbox', [0.01, 0.465, 0.06, 0.03], 'String', 'Imag', ...
    'HorizontalAlignment', 'center', 'EdgeColor', 'none', 'FontWeight', 'bold', 'Color', [0.60 0.15 0.15]);
annotation(fig, 'line', [0.08, 0.98], [0.50, 0.50], 'LineStyle', '--', 'Color', [0.5 0.5 0.5]);

cb_xs = [0.1412, 0.43, 0.72];
comp_cb_info = {clim_Br, 'B_r (nT)', [-0.5, 0, 0.5]; clim_Bt, 'B_\theta (nT)', [-0.3, 0, 0.3]; clim_Bp, 'B_\phi (nT)', [-0.3, 0, 0.3]};
for k = 1:3
    ax_cb = axes(fig, 'Position', [cb_xs(k), 0.1, 0.16, 0.016], 'Visible', 'off');
    colormap(ax_cb, cmap); clim(ax_cb, comp_cb_info{k,1});
    cb = colorbar(ax_cb, 'Location', 'southoutside');
    cb.Ticks = comp_cb_info{k,3}; cb.Label.String = comp_cb_info{k,2}; cb.FontSize = 8;
end

% --- 导出 ---
exportgraphics(fig, 'N2_Inversion_vs_Forward_Map.pdf', 'Resolution', 600);
fprintf('绘图完成并保存为 PDF。\n');

end

%% =========================================================================
%                         数据处理辅助函数
%% =========================================================================

function D = load_ours_mat_result(fname, max_n)
    % 读取 .mat 文件并转换为 [n, m, Re, Im] 格式
    data = load(fname);
    % 假设结构为 Result_N2.Coeffs
    if isfield(data, 'Result_N2')
        coeffs_vec = data.Result_N2.Coeffs;
    else
        % 兼容不同变量名
        fields = fieldnames(data);
        coeffs_vec = data.(fields{1}).Coeffs;
    end
    
    D = []; ptr = 1;
    for n = 1:max_n
        % m 顺序: 0, 1, -1, 2, -2...
        m_list = [0, reshape([1:n; -(1:n)], 1, [])];
        for m = m_list
            re_val = coeffs_vec(ptr);     % 奇数位
            im_val = coeffs_vec(ptr + 1); % 偶数位
            D = [D; n, m, re_val, im_val];
            ptr = ptr + 2;
        end
    end
end

function D = load_dat_forward_model(filepath, const)
    % 读取 .dat 网格并执行 SHA 转换为系数
    raw_data = readmatrix(filepath);
    lon = raw_data(:, 1); 
    lat = raw_data(:, 2);
    field_complex = double(raw_data(:, 3)) + 1i * double(raw_data(:, 4));
    
    % 执行 SHA 分解
    coeffs = sha_solver_vectorized(90-lat, lon, field_complex, const.a_radius, const);
    D = coeffs_to_standard_format(coeffs, const.N_max);
end

function vec = convert_to_complex_vector(D, max_n)
    % 将 [n, m, Re, Im] 转换为 build_K_matrix 期望的顺序:
    % (n=1,m=0), (n=1,m=1,cos), (n=1,m=1,sin), ...
    vec = [];
    for n = 1:max_n
        % m=0
        vec = [vec; get_val(D, n, 0)];
        % m>0
        for m = 1:n
            vec = [vec; get_val(D, n, m)];  % cos项 (m > 0)
            vec = [vec; get_val(D, n, -m)]; % sin项 (m < 0)
        end
    end
end

function z = get_val(D, n, m)
    idx = (D(:,1) == n & D(:,2) == m);
    if any(idx)
        z = D(idx, 3) + 1i * D(idx, 4);
    else
        z = 0;
    end
end

%% =========================================================================
%                         SHA 与 绘图基础函数
%% =========================================================================

function coeffs = sha_solver_vectorized(colat, lon, data, r_data, const)
    N_max = const.N_max; a = const.a_radius;
    n_pts = length(colat); n_coeffs = N_max * (N_max + 2);
    A = zeros(n_pts, n_coeffs); col_idx = 1;
    rad_ratio = a / r_data; cos_colat = cosd(colat);
    for n = 1:N_max
        radial_term = (n + 1) * (rad_ratio)^(n + 2);
        P = legendre(n, cos_colat', 'sch');
        for m = 0:n
            P_nm = P(m+1, :)';
            if m == 0
                A(:, col_idx) = radial_term * P_nm; col_idx = col_idx + 1;
            else
                A(:, col_idx) = radial_term * P_nm .* cosd(m * lon); col_idx = col_idx + 1;
                A(:, col_idx) = radial_term * P_nm .* sind(m * lon); col_idx = col_idx + 1;
            end
        end
    end
    coeffs = A \ data;
end

function D = coeffs_to_standard_format(coeffs, N_max)
    D = []; idx = 1;
    for n = 1:N_max
        num_m = 2*n + 1;
        c_n = coeffs(idx : idx + num_m - 1);
        D = [D; n, 0, real(c_n(1)), imag(c_n(1))];
        for m = 1:n
            D = [D; n, m, real(c_n(2*m)), imag(c_n(2*m))];
            D = [D; n, -m, real(c_n(2*m+1)), imag(c_n(2*m+1))];
        end
        idx = idx + num_m;
    end
end

function plot_map_robinson(ax, LON, LAT, Data, clims, cmap)
    axes(ax);
    m_proj('robinson', 'lon', [0 360]);
    m_pcolor(LON, LAT, Data); shading interp;
    m_coast('color', [0.2 0.2 0.2], 'LineWidth', 0.4);
    m_grid('xtick', [], 'ytick', [], 'linestyle', 'none', 'box', 'on');
    colormap(ax, cmap); clim(ax, clims);
end

function cmap = custom_bluewhitered(m)
    bottom = [0.230, 0.299, 0.754]; middle = [0.960, 0.960, 0.960]; top = [0.706, 0.016, 0.150];
    half = floor(m/2);
    r = [linspace(bottom(1), middle(1), half)'; linspace(middle(1), top(1), m-half)'];
    g = [linspace(bottom(2), middle(2), half)'; linspace(middle(2), top(2), m-half)'];
    b = [linspace(bottom(3), middle(3), half)'; linspace(middle(3), top(3), m-half)'];
    cmap = [r, g, b];
end