function Plot_All_Satellites_Full_Diagnostics()
    % -------------------------------------------------------------------------
    % Purpose: 卫星残差诊断图 (矢量/标量完全分离版)
    % Fixes:   1. 强制区分 Vector 和 Scalar 数据 (绘图与统计不合并)
    %          2. 保持 Morandi 配色，利用深浅区分 Vec/Sca
    %          3. 包含之前的 Dimension 修复和 Time 修复
    % -------------------------------------------------------------------------
    clc; close all;

    % ================= 1. 全局配置 =================
    dir_results = '卫星残差数据'; 
    sat_list = {'CHAMP', 'CryoSat-2', 'GRACE-FO', 'MSS', 'Ørsted', 'SAC-C', 'Swarm'};
    
    % --- 配色 (Morandi): 深色给 Vector，浅色给 Scalar ---
    % 绝对残差 (Blue)
    cols.abs_vec  = [74, 101, 114] / 255;   % 深蓝 (Vector)
    cols.abs_sca  = [158, 179, 194] / 255;  % 浅蓝 (Scalar)
    
    % 梯度残差 (Green)
    cols.grad_vec = [84, 106, 89] / 255;    % 深绿 (Vector)
    cols.grad_sca = [163, 190, 140] / 255;  % 浅绿 (Scalar)
    
    % 星间梯度 (Red) - 通常只有一种，但预留深浅
    cols.cross_vec = [196, 78, 82] / 255;   % 深红
    cols.cross_sca = [228, 156, 159] / 255; % 浅红

    style.txt  = [30, 30, 30] / 255;
    style.grid = [240, 240, 240] / 255;
    % style.font = 'Arial';
    
    % ================= 2. 循环处理 =================
    for i = 1:length(sat_list)
        sat_name = sat_list{i};
        fprintf('Processing: %s ...\n', sat_name);
        
        files = get_file_config(dir_results, sat_name);
        plot_single_sat_page(sat_name, files, cols, style);
    end
    fprintf('所有卫星绘图完成。\n');
end

%% ================== 单星绘图主逻辑 ==================
function plot_single_sat_page(name, files, cols, style)
    % 创建不可见画布
    fig = figure('Name', [name ' Diagnostics'], 'Color', 'w', ...
                 'Units', 'centimeters', 'Position', [2, 2, 26, 18], 'Visible', 'off');
    
    t = tiledlayout(2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    % title(t, [name, ' Data Residuals Diagnostics'], 'FontSize', 14, 'FontWeight', 'bold');

    % 数据容器 (用于最后画 PDF 直方图)
    hist_pool = struct('abs', [], 'grad', [], 'cross', []);
    % 时间轴容器 (用于画堆叠柱状图)
    timeline_list = [];

    % --- 1. 左上: Absolute Residuals (Orig) ---
    ax_abs = nexttile(1); hold(ax_abs, 'on');
    
    % 分别处理 Vector 和 Scalar
    [d_ov, t_ov] = process_and_plot_layer(ax_abs, name, files.abs, 'Vector', 'Orig', ...
                                          cols.abs_vec, 's', 'Vector');
    [d_os, t_os] = process_and_plot_layer(ax_abs, name, files.abs, 'Scalar', 'Orig', ...
                                          cols.abs_sca, 'o', 'Scalar');
                                      
    hist_pool.abs = [d_ov; d_os]; % 合并用于计算RMS和Limits
    timeline_list = [timeline_list, t_ov, t_os]; % 记录到时间轴
    
    setup_axis_style(ax_abs, 'a) Absolute Residuals', hist_pool.abs, style, 30);
    
    % --- 2. 右上: Gradient Residuals (Grad + Cross) ---
    ax_grad = nexttile(2); hold(ax_grad, 'on');
    
    % 层级策略: Cross(红) -> Scalar(浅绿) -> Vector(深绿)
    
    % A. Cross-Sat (如果有)
    d_cross_all = [];
    if isfield(files, 'cross') && ~isempty(files.cross)
        % 尝试读取 Cross Vector 和 Cross Scalar (虽然通常只有一个)
        [d_cv, t_cv] = process_and_plot_layer(ax_grad, name, files.cross, 'Vector', 'Cross', ...
                                              cols.cross_vec, '^', 'Cross Vec');
        [d_cs, t_cs] = process_and_plot_layer(ax_grad, name, files.cross, 'Scalar', 'Cross', ...
                                              cols.cross_sca, 'v', 'Cross Sca');
        d_cross_all = [d_cv; d_cs];
        timeline_list = [timeline_list, t_cv, t_cs];
    end
    hist_pool.cross = d_cross_all;

    % B. Gradient (Separated)
    [d_gv, t_gv] = process_and_plot_layer(ax_grad, name, files.grad, 'Vector', 'Grad', ...
                                          cols.grad_vec, 's', 'Grad Vec');
    [d_gs, t_gs] = process_and_plot_layer(ax_grad, name, files.grad, 'Scalar', 'Grad', ...
                                          cols.grad_sca, 'o', 'Grad Sca');
    
    hist_pool.grad = [d_gv; d_gs];
    timeline_list = [timeline_list, t_gv, t_gs];

    all_grad_display = [hist_pool.grad; hist_pool.cross];
    setup_axis_style(ax_grad, 'b) Gradients (Along-Track & Cross-Sat)', all_grad_display, style, 5);
    
    % 手动图例 (显示存在的类别)
    lgd_h = []; lgd_s = {};
    if ~isempty(d_gv), h=scatter(ax_grad,NaN,NaN,20,cols.grad_vec,'filled','s'); lgd_h=[lgd_h,h]; lgd_s{end+1}='Along-Track'; end
    if ~isempty(d_cross_all), h=scatter(ax_grad,NaN,NaN,20,cols.cross_vec,'filled','^'); lgd_h=[lgd_h,h]; lgd_s{end+1}='Cross-Sat'; end
    if ~isempty(lgd_h), legend(lgd_h, lgd_s, 'Location', 'northeast', 'Box', 'off'); end

    % --- 3. 左下: Timeline (分离显示 Vec/Sca) ---
    ax_time = nexttile(3);
    plot_timeline_smart(ax_time, timeline_list, style);

    % --- 4. 右下: Histogram ---
    ax_hist = nexttile(4); hold(ax_hist, 'on');
    plot_pdf_curve(ax_hist, hist_pool.abs, cols.abs_vec, '-', 'Absolute');
    plot_pdf_curve(ax_hist, hist_pool.grad, cols.grad_vec, '--', 'Along-Track');
    if ~isempty(hist_pool.cross)
        plot_pdf_curve(ax_hist, hist_pool.cross, cols.cross_vec, '-.', 'Cross-Sat');
    end
    setup_hist_axis(ax_hist, 'd) Residual Distribution', style);

    % --- 导出 ---
    exportgraphics(fig, sprintf('Diagnostics_Sep_%s.pdf', name), 'Resolution', 600);
    close(fig);
end

%% ================== 核心处理函数 (单层数据处理) ==================
function [data_out, time_struct] = process_and_plot_layer(ax, sat_name, fname, data_type, prefix, color, marker, legend_label)
    % data_type: 'Vector' or 'Scalar'
    % prefix: 'Orig', 'Grad', 'Cross'
    
    data_out = [];
    time_struct = []; % 空结构体
    
    if isempty(fname) || ~isfile(fname), return; end
    
    try
        S = load(fname);
        
        % 构造变量名 (例如 Data_Vector_Orig)
        var_name = ['Data_' data_type '_' prefix];
        
        if isfield(S, var_name)
            D = S.(var_name);
            
            % 1. 提取数值 (兼容不同字段名)
            val = [];
            if isfield(D, 'B_res'), val = D.B_res(:);
            elseif isfield(D, 'dF'), val = D.dF(:);
            elseif isfield(D, 'd_grad'), val = D.d_grad(:);
            end
            
            % 2. 提取纬度
            lat = [];
            if isfield(D, 'QD_Lat'), lat = D.QD_Lat(:); end
            
            % 3. 提取时间
            t_raw = [];
            if isfield(D, 'Time'), t_raw = D.Time(:);
            elseif isfield(D, 'Time1'), t_raw = D.Time1(:);
            end
            
            % 4. 维度安全对齐 (防止 scatter 报错)
            if ~isempty(val) && ~isempty(lat)
                n_v = numel(val);
                n_l = numel(lat);
                
                if n_v > n_l && mod(n_v, n_l) == 0
                    % 矢量数据通常是 Lat 的 3 倍
                    lat = repmat(lat, n_v/n_l, 1);
                elseif n_v ~= n_l
                    % 异常情况：强制截断到最小值
                    mn = min(n_v, n_l);
                    val = val(1:mn);
                    lat = lat(1:mn);
                end
                
                % 5. 绘图 (降采样)
                max_pts = 30000; % 每个层级少画点，避免文件过大
                idx = 1:length(val);
                if length(val) > max_pts, idx = randsample(length(val), max_pts); end
                
                scatter(ax, lat(idx), val(idx), 4, color, 'filled', marker, ...
                    'MarkerFaceAlpha', 0.15, 'MarkerEdgeColor', 'none');
                
                data_out = val;
                
                % 6. 准备时间轴数据
                if ~isempty(t_raw)
                    t_dt = convert_time_robust(t_raw);
                    if ~isempty(t_dt)
                        % 构建单个时间结构体
                        ts.time = t_dt;
                        ts.color = color;
                        % Label 例如: "Orig Vec" 或 "Grad Sca"
                        ts.label = [prefix ' ' (data_type(1:3))]; 
                        time_struct = ts;
                    end
                end
            end
        end
    catch ME
        % warning('Load error %s: %s', var_name, ME.message);
    end
end

%% ================== 通用辅助函数 ==================

% --- 智能时间转换 ---
function t_dt = convert_time_robust(t_raw)
    if isempty(t_raw), t_dt = []; return; end
    t_mean = mean(t_raw, 'omitnan');
    
    if t_mean > 700000 % MATLAB datenum
        t_dt = datetime(t_raw, 'ConvertFrom', 'datenum');
    elseif t_mean < 50000 % MJD2000
        t_dt = datetime(2000, 1, 1) + days(t_raw);
    else % Fallback
        t_dt = datetime(1858, 11, 17) + days(t_raw);
    end
    % 过滤无效年份
    if ~isempty(t_dt)
        yrs = year(t_dt);
        t_dt = t_dt(yrs > 1990 & yrs < 2030);
    end
end

% --- 智能时间轴绘制 ---
function plot_timeline_smart(ax, timeline_list, style)
    if isempty(timeline_list)
        title(ax, 'No Time Data'); return;
    end
    
    % 计算总时间范围
    all_t = vertcat(timeline_list.time);
    if isempty(all_t), return; end
    
    t_min = min(all_t);
    t_max = max(all_t);
    span = years(t_max - t_min);
    
    % 决定 Bin 策略
    if span < 3
        t_start = dateshift(t_min, 'start', 'month');
        t_end   = dateshift(t_max, 'end', 'month');
        edges   = t_start : calmonths(1) : (t_end + calmonths(1));
        time_mode = 'Monthly';
        fmt_str = 'MM-yyyy';
    else
        t_start = dateshift(t_min, 'start', 'year');
        t_end   = dateshift(t_max, 'end', 'year');
        edges   = t_start : calmonths(3) : (t_end + calyears(1));
        time_mode = 'Quarterly';
        fmt_str = 'yyyy';
    end
    
    % 统计 Histogram
    num_series = length(timeline_list);
    counts = zeros(length(edges)-1, num_series);
    
    hold(ax, 'on');
    labels = {};
    for i = 1:num_series
        counts(:, i) = histcounts(timeline_list(i).time, edges);
        labels{i} = timeline_list(i).label;
    end
    
    % 绘制堆叠柱状图
    x_centers = edges(1:end-1) + (edges(2)-edges(1))/2;
    b = bar(ax, x_centers, counts, 0.95, 'stacked', 'EdgeColor', 'none');
    
    for i = 1:num_series
        b(i).FaceColor = timeline_list(i).color;
        b(i).FaceAlpha = 0.85;
    end
    
    set(ax, 'GridColor', style.grid, 'GridLineStyle', '--', 'LineWidth', 0.8, 'TickDir', 'out', 'FontSize', 9);
    title(ax, ['c) Data Availability Timeline (' time_mode ')'], 'FontSize', 10, 'FontWeight', 'bold');
    ylabel(ax, 'Count', 'FontSize', 9); 
    xtickformat(ax, fmt_str);
    
    if strcmp(time_mode, 'Monthly')
        xlim(ax, [edges(1), edges(end)]);
    end
    
    grid on; box on;
    % 动态调整图例列数
    n_cols = 2; if num_series > 4, n_cols = 3; end
    legend(ax, labels, 'Location', 'northwest', 'Box', 'off', 'FontSize', 7, 'NumColumns', n_cols);
end

% --- 坐标轴与直方图样式 ---
function setup_axis_style(ax, title_str, val, style, def_lim)
    set(ax, 'GridColor', style.grid, 'GridLineStyle', '--', 'LineWidth', 0.8, 'TickDir', 'out', 'FontSize', 9);
    grid on; box on; xlim(ax, [-90 90]);
    title(ax, title_str, 'FontSize', 10, 'FontWeight', 'bold', 'Color', style.txt);
    ylabel(ax, 'nT', 'FontSize', 9); xlabel(ax, 'QD Lat (deg)', 'FontSize', 9);
    if ~isempty(val)
        y_bound = prctile(abs(val), 99.8);
        if isnan(y_bound) || y_bound == 0, y_bound = def_lim; end
        ylim(ax, [-y_bound, y_bound]);
        stats = sprintf('N=%d\nRMS=%.2f', length(val), rms(val, 'omitnan'));
        text(ax, 0.03, 0.9, stats, 'Units', 'normalized', 'FontSize', 8, 'BackgroundColor', [1 1 1 0.6]);
    end
end

function plot_pdf_curve(ax, val, col, ls, name)
    if isempty(val), return; end
    val = val(abs(val) < 1000); 
    if isempty(val), return; end
    histogram(ax, val, 100, 'DisplayStyle', 'stairs', 'EdgeColor', col, ...
            'LineStyle', ls, 'LineWidth', 1.5, 'Normalization', 'pdf', 'DisplayName', name);
end

function setup_hist_axis(ax, title_str, style)
    set(ax, 'GridColor', style.grid, 'GridLineStyle', '--', 'LineWidth', 0.8, 'TickDir', 'out', 'FontSize', 9);
    grid on; box on; xlim(ax, [-20, 20]);
    title(ax, title_str, 'FontSize', 10, 'FontWeight', 'bold', 'Color', style.txt);
    xlabel(ax, 'Residual (nT)', 'FontSize', 9); ylabel(ax, 'Density', 'FontSize', 9);
    legend(ax, 'Location', 'northeast', 'Box', 'off');
end

function files = get_file_config(base_dir, sat_name)
    files = struct('abs', '', 'grad', '', 'cross', '');
    switch sat_name
        case 'CHAMP'
            files.abs  = fullfile(base_dir, 'CHAMP_Modeling_Input_Abs.mat');
            files.grad = fullfile(base_dir, 'CHAMP_Modeling_Input_Grad.mat');
        case 'CryoSat-2'
            files.abs  = fullfile(base_dir, 'CryoSat_Input_Original_Weighted.mat');
            files.grad = fullfile(base_dir, 'CryoSat_Input_Gradient_Weighted.mat');
        case 'GRACE-FO'
            files.abs  = fullfile(base_dir, 'GraceFO_ACC_Input_Original_Weighted.mat');
            files.grad = fullfile(base_dir, 'GraceFO_ACC_Input_Gradient_Weighted.mat');
            files.cross= fullfile(base_dir, 'GraceFO_CrossSat_Gradient_Weighted.mat');
        case 'MSS'
            files.abs  = fullfile(base_dir, 'MSS_Input_Original_Weighted.mat');
            files.grad = fullfile(base_dir, 'MSS_Input_Gradient_Weighted.mat');
        case 'Ørsted'
            files.abs  = fullfile(base_dir, 'Orsted_ACC_Input_Original_Scalar.mat');
            files.grad = fullfile(base_dir, 'Orsted_ACC_Input_Gradient_Scalar.mat');
        case 'SAC-C'
            files.abs  = fullfile(base_dir, 'SACC_ACC_Input_Original_Scalar.mat');
            files.grad = fullfile(base_dir, 'SACC_ACC_Input_Gradient_Scalar.mat');
        case 'Swarm'
            files.abs  = fullfile(base_dir, 'Swarm_ACC_Input_Original_Weighted.mat');
            files.grad = fullfile(base_dir, 'Swarm_ACC_Input_Gradient_Weighted.mat');
            files.cross= fullfile(base_dir, 'Swarm_CrossSat_Gradient_Weighted.mat');
    end
end