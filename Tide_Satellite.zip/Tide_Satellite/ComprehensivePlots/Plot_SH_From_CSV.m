function Plot_SH_From_CSV()
    % -------------------------------------------------------------------------
    % Purpose: 读取CSV球谐系数并绘图 (太平洋中心视角 / Pacific Centered)
    % Change:  将经度范围改为 [0, 360]，解决日界线分割问题
    % -------------------------------------------------------------------------
    
    clc; clear; close all;
    
    % ================= 1. 配置参数 =================
    csv_file = '潮汐磁场结果/MultiSat_Result_HighVol_Strict_N2.csv';
    
    a = 6371.2;             % 地球半径 (km)
    alt_km = 450;           % 轨道/绘图高度 (km)
    res_deg = 1.0;          % 绘图网格分辨率
    
    font_name = 'Arial';
    font_size = 11;
    
    % ================= 2. 读取数据 =================
    if ~isfile(csv_file)
        error('未找到文件: %s', csv_file);
    end
    fprintf('1. 读取系数文件: %s ...\n', csv_file);
    
    T = readtable(csv_file);
    N_max = 8;
    
    num_rows = height(T);
    U_est = zeros(2 * num_rows, 1);
    U_est(1:2:end) = T.Real;
    U_est(2:2:end) = T.Imag;
    
    % ================= 3. 构建矩阵与场合成  =================
    fprintf('2. 构建坐标网格 [0, 360] (Res: %.1f deg)...\n', res_deg);
    
    % 这样 180 度就在正中间，0/360 度在两侧边缘
    lon_vec = 0:res_deg:360; 
    lat_vec = -89.5:res_deg:89.5; 
    
    [LON, LAT] = meshgrid(lon_vec, lat_vec);
    
    r_plot = (a + alt_km) * ones(size(LON));
    input_coords = [r_plot(:), 90-LAT(:), LON(:)];
    
    fprintf('3. 调用 build_K_matrix_paper 进行合成...\n');
    try
        [K_space, ~, ~] = build_K_matrix_paper(input_coords, ...
            ones(numel(LON),1), zeros(numel(LON),1), N_max, a);
        
        coeffs_complex = U_est(1:2:end) + 1i * U_est(2:2:end);
        
        if size(K_space, 2) == length(U_est)
             B_complex_vec = K_space(:, 1:2:end) * coeffs_complex;
        elseif size(K_space, 2) == length(coeffs_complex)
             B_complex_vec = K_space * coeffs_complex;
        else
             error('K矩阵维度不匹配');
        end
        B_complex = reshape(B_complex_vec, size(LON));
        
    catch ME
        error('调用 build_K_matrix_paper 失败。\n错误信息: %s', ME.message);
    end
    
    % ================= 4. 可视化绘图 (太平洋视角) =================
    fprintf('4. 绘制出版级图表 (Pacific View)...\n');
    
    figure('Color', 'w', 'Position', [50, 50, 1100, 550]);
    t = tiledlayout(2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    
    % 数据准备
    maps = {real(B_complex), imag(B_complex), abs(B_complex), angle(B_complex)*180/pi};
    titles = {'a) Real Part', 'b) Imaginary Part', 'c) Amplitude', 'd) Phase (deg)'};
    
    % --- 配置范围 (CLim) ---
    fixed_lim = [-0.5, 0.5]; % 实部虚部固定范围
    clim_amp = [0, prctile(abs(B_complex(:)), 99)]; 
    clim_phase = [-180, 180];
    
    clims = {fixed_lim, fixed_lim, clim_amp, clim_phase};
    
    % --- 配置配色 ---
    try cmap_div = nclCM('MPL_PuOr');cmap_div = flipud(cmap_div); catch, cmap_div = custom_bluewhitered(256); end
    cmap_amp = nclCM('WhiteBlueGreenYellowRed'); 
    cmap_phase = hsv(256); % 相位使用 HSV 循环色
    
    cmaps = {cmap_div, cmap_div, cmap_amp, cmap_phase};
    
    for k = 1:4
        nexttile;
        
        % 这会将 180度(太平洋) 放在正中间，0度(格林威治) 放在两侧切割
        m_proj('robinson', 'lon', [0 360]);
        
        m_pcolor(LON, LAT, maps{k}); 
        shading flat; 
        
        % 边框与网格
        m_coast('color', [0.2 0.2 0.2], 'LineWidth', 0.8);
        
        % 网格线设置: 30度或60度一格
        m_grid('linestyle', ':', 'linewidth', 0.5, 'tickdir', 'out', ...
               'fontsize', 9, 'color', [0.5 0.5 0.5], 'xtick', 6);
           
        colormap(gca, cmaps{k});
        clim(clims{k});
        
        title(titles{k}, 'FontName', font_name, 'FontSize', font_size+2, 'FontWeight', 'bold');
        set(gca, 'FontName', font_name, 'FontSize', font_size);
        
        cb = colorbar;
        cb.Label.FontName = font_name;
        cb.FontSize = 9;
        
        if k < 3
            cb.Label.String = 'nT';
        elseif k == 3
            cb.Label.String = 'Amplitude (nT)';
        else
            cb.Label.String = 'Degree';
            cb.Ticks = [-180, -90, 0, 90, 180];
            cb.TickLabels = {'-180','-90','0','90','180'};
        end
    end
    
    % ================= 5. 保存结果 =================
    out_filename = 'GraceFO_Result_Pacific_View.png';
    fprintf('5. 保存图片: %s\n', out_filename);
    exportgraphics(gcf, out_filename, 'Resolution', 300);
    fprintf('   完成。\n');
end

% -------------------------------------------------------------------------
% 辅助函数
% -------------------------------------------------------------------------
function cmap = custom_bluewhitered(m)
    if nargin < 1, m = 256; end
    bottom = [0.230, 0.299, 0.754];
    middle = [0.960, 0.960, 0.960]; 
    top    = [0.706, 0.016, 0.150]; 
    half = floor(m/2);
    r = [linspace(bottom(1), middle(1), half)'; linspace(middle(1), top(1), m-half)'];
    g = [linspace(bottom(2), middle(2), half)'; linspace(middle(2), top(2), m-half)'];
    b = [linspace(bottom(3), middle(3), half)'; linspace(middle(3), top(3), m-half)'];
    cmap = [r, g, b];
end
