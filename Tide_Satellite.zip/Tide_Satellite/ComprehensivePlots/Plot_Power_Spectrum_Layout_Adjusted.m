function Plot_Power_Spectrum_Layout_Adjusted()
    % -------------------------------------------------------------------------
    % Purpose: 绘制功率谱对比图 + 局部放大图
    % Layout Change: 
    %   1. Inset (放大图) -> 右下角 (Bottom-Right)
    %   2. Legend (图例)  -> 右上角 (Top-Right)
    % -------------------------------------------------------------------------
    clc; close all;

    % ================= 1. 配置文件与参数 =================
    dir_results = '潮汐磁场结果';
    
    % 卫星配置
    sat_config = {
       % 'Combined (Old)',     'SH_coefficients_M2_28_all.txt',              [0.5, 0.5, 0.5],    'none';
        'Swarm',              'Swarm_SH_Coefficients_With_Errors.csv',      [0.00, 0.45, 0.74], 'o';
     %   'ALL',                'MultiSat_Result_HighVol_Strict.csv',         [0.00, 0.45, 0.74], '<';
        'GRACE-FO',           'GraceFO_SH_Coefficients_base_ssg_csg.csv',   [0.85, 0.33, 0.10], 's';
        'CHAMP',              'CHAMP_SH_Coefficients_With_Errors.csv',      [0.47, 0.67, 0.19], '^';
        'CryoSat-2',          'CryoSat_SH_Coefficients_With_Errors.csv',    [0.93, 0.69, 0.13], 'd';
        'Ørsted',             'Orsted_SH_Coefficients_With_Errors.csv',     [0.49, 0.18, 0.56], 'v';
        'SAC-C',              'SACC_SH_Coefficients_With_Errors.csv',       [0.64, 0.08, 0.18], 'p';
        'MSS-1A',             '../../MSS相关/MSS_Tidal_Result_Aligned.csv',        [0.30, 0.75, 0.93], 'h';
    };

    forward_file = 'B_surface.dat'; 
    a_radius = 6371.2; 
    
    plot_data = struct('rn', {}, 'deg', {}, 'name', {}, 'color', {}, ...
                       'style', {}, 'lw', {}, 'marker', {}, 'msize', {});

    % ================= 2. 数据读取 =================
    fprintf('正在处理数据...\n');
    for k = 1:size(sat_config, 1)
        name = sat_config{k, 1};
        fname = fullfile(dir_results, sat_config{k, 2});
        color = sat_config{k, 3};
        marker = sat_config{k, 4};
        
        if contains(name, 'Combined')
            lw = 2.2; style = '--'; msize = 0;
        else
            lw = 1.9; style = '-'; msize = 8; 
        end
        
        if isfile(fname)
            try
                T = readtable(fname);
                [rn, deg] = compute_Rn_from_table(T, 1.0);
                add_to_plot(rn, deg, name, color, style, lw, marker, msize);
            catch, end
        end
    end

    if isfile(forward_file)
        [rn_fwd, deg_fwd] = solve_sha_from_spatial_file(forward_file, 32, a_radius, a_radius);
        if ~isempty(rn_fwd)
            add_to_plot(rn_fwd, deg_fwd, 'Model', [0.3, 0.3, 0.3], '--', 2.5, 'none', 0); 
        end
    end

    function add_to_plot(rn, deg, name, color, style, lw, marker, msize)
        idx = length(plot_data) + 1;
        plot_data(idx).rn = rn; 
        plot_data(idx).deg = deg;
        plot_data(idx).name = name; 
        plot_data(idx).color = color;
        plot_data(idx).style = style;
        plot_data(idx).lw = lw;
        plot_data(idx).marker = marker;
        plot_data(idx).msize = msize;
    end

    % ================= 3. 绘图 =================
    fprintf('正在绘图...\n');
    
    fig = figure('Color', 'w', 'Units', 'centimeters', 'Position', [3, 3, 24, 18]);
    
    % --- Step 3.1: 主图 (Main Plot) ---
    ax_main = axes(fig, 'Box', 'on', 'LineWidth', 1.2, 'Position', [0.10, 0.12, 0.85, 0.82]);
    hold(ax_main, 'on');
    
    draw_all_lines(ax_main, plot_data, false); 

    set(ax_main, 'YScale', 'log', 'XScale', 'linear');
    grid(ax_main, 'on'); 
    set(ax_main, 'FontSize', 14, 'LineWidth', 1.2);
    xlabel(ax_main, 'Spherical Harmonic Degree, {\itn}', 'FontSize', 16, 'FontWeight', 'bold');
    ylabel(ax_main, 'Power Spectrum, {\itR}_{\itn} (nT^2)', 'FontSize', 16, 'FontWeight', 'bold');
    xlim(ax_main, [0.5, 30]); xticks(ax_main, 0:5:30);
    
    % 动态调整主图 Y 轴
    all_rn = vertcat(plot_data.rn);
    if ~isempty(all_rn)
        y_min_main = 10^floor(log10(min(all_rn(all_rn>1e-12))));
        y_max_main = 10^ceil(log10(max(all_rn)));
        ylim(ax_main, [y_min_main, y_max_main * 5]); % 留出空间给右上角的图例
    end

    % --- Step 3.2: 局部放大图 (Inset Plot) ---
    % 位置调整：[left, bottom, width, height]
    % 放在右下角，避免遮挡左侧的高能量信号和右上角的图例
    ax_inset = axes(fig, 'Position', [0.54, 0.18, 0.36, 0.32], 'Box', 'on', 'LineWidth', 1.0);
    hold(ax_inset, 'on');
    
    draw_all_lines(ax_inset, plot_data, true); 
    
    set(ax_inset, 'YScale', 'log', 'XScale', 'linear');
    grid(ax_inset, 'on');
    set(ax_inset, 'FontSize', 11);
    set(ax_inset, 'Color', [1 1 1]); % 白色背景
    
    % 聚焦 4-7 阶
    xlim(ax_inset, [3.5, 7.5]); 
    xticks(ax_inset, 4:1:7);
    
    % Inset Y 轴自动范围
    inset_rn_vals = [];
    for k = 1:length(plot_data)
        mask = plot_data(k).deg >= 4 & plot_data(k).deg <= 7;
        inset_rn_vals = [inset_rn_vals; plot_data(k).rn(mask)];
    end
    if ~isempty(inset_rn_vals)
        y_min_ins = min(inset_rn_vals) * 0.6;
        y_max_ins = max(inset_rn_vals) * 1.4;
        ylim(ax_inset, [y_min_ins, y_max_ins]);
    end

    % --- Step 3.3: 图例 (右上角) ---
    lines_main = findobj(ax_main, 'Type', 'line');
    legend_labels = get(lines_main, 'DisplayName');
    
    desired_order = {'Model', 'Combined (Old)', ...
                     'Swarm','New result', 'GRACE-FO', 'CHAMP', 'CryoSat-2', ...
                     'Ørsted', 'SAC-C', 'MSS-1A'};
    reordered_handles = []; reordered_labels = {};
    for k = 1:length(desired_order)
        idx = find(strcmp(legend_labels, desired_order{k}));
        if ~isempty(idx)
            reordered_handles(end+1) = lines_main(idx(1));
            reordered_labels{end+1} = desired_order{k};
        end
    end
    
    % 图例位置改为 'northeast' (右上角)
    leg = legend(ax_main, reordered_handles, reordered_labels, ...
        'Location', 'best', 'Box', 'on', ...
        'FontSize', 10, 'NumColumns', 3);
    leg.ItemTokenSize = [25, 18];

    % ================= 4. 导出 =================
    % exportgraphics(fig, 'Power_Spectrum_Final_Layout.png', 'Resolution', 600);
    exportgraphics(fig, 'Power_Spectrum_Final_Layout.pdf', 'Resolution', 600);
    fprintf('完成! 贴图移至右下角，图例移至右上角。\n');
end

% --- 绘图封装 ---
function draw_all_lines(ax, plot_data, is_inset)
    idx_fwd = find(strcmp({plot_data.name}, 'Model'));
    idx_comb = find(contains({plot_data.name}, 'Combined'));
    
    % 底层参考线
    if ~isempty(idx_fwd)
        P = plot_data(idx_fwd);
        plot(ax, P.deg, P.rn, 'LineStyle', P.style, ...
             'Color', [P.color, 0.6], 'LineWidth', P.lw, 'DisplayName', P.name);
    end
    if ~isempty(idx_comb)
        P = plot_data(idx_comb);
        plot(ax, P.deg, P.rn, 'LineStyle', P.style, ...
             'Color', [P.color, 0.6], 'LineWidth', P.lw, 'DisplayName', P.name);
    end
    
    % 顶层卫星数据
    for i = 1:length(plot_data)
        if ismember(i, [idx_fwd, idx_comb]), continue; end
        P = plot_data(i);
        
        if is_inset
            mk_indices = 1:1:length(P.deg);
            ms = P.msize * 0.85; 
            lw = P.lw * 0.9;
        else
            mk_indices = 1:2:length(P.deg);
            ms = P.msize;
            lw = P.lw;
        end
        
        plot(ax, P.deg, P.rn, ...
            'LineStyle', P.style, 'Color', P.color, 'LineWidth', lw, ...
            'Marker', P.marker, 'MarkerSize', ms, ...
            'MarkerFaceColor', 'w', 'MarkerEdgeColor', P.color, 'LineWidth', 1.5, ...
            'MarkerIndices', mk_indices, 'DisplayName', P.name);
    end
end

% ================= 辅助函数 =================
function [Rn, n_list] = compute_Rn_from_table(T, r_ratio)
    vars = T.Properties.VariableNames;
    if ismember('Real', vars) && ismember('Imag', vars)
        if ismember('n', vars), n_vec = T.n; else, n_vec = T{:, 1}; end
        if ismember('m', vars), m_vec = T.m; else, m_vec = T{:, 2}; end
        coeffs = T.Real + 1i * T.Imag;
    elseif ismember('Real_Part', vars)
        n_vec = T.Degree_n; m_vec = T.Order_m;
        coeffs = T.Real_Part + 1i * T.Imag_Part;
    elseif width(T) >= 4
        if width(T) >= 6 && mean(abs(T{:,4})) < 100
             n_vec = T{:,2}; m_vec = T{:,3}; coeffs = T{:,4} + 1i * T{:,6};
        else
             n_vec = T{:,1}; m_vec = T{:,2}; coeffs = T{:,3} + 1i * T{:,4};
        end
    else
        error('无法识别数据表格式');
    end
    n_list = unique(n_vec); Rn = zeros(length(n_list), 1);
    for i = 1:length(n_list)
        n = n_list(i); idx = (n_vec == n); c_n = coeffs(idx); 
        sum_sq = sum(abs(c_n).^2); factor = (n + 1) * (2 * n + 1) / (4 * pi);
        Rn(i) = factor * (r_ratio)^(2 * n + 4) * sum_sq;
    end
end

function [Rn, n_list] = solve_sha_from_spatial_file(fname, n_max, a, r_eval)
    try
        data = readmatrix(fname);
        br_complex = data(:, 3) + 1i*data(:, 4);
        colat = 90 - data(:, 2); lon = data(:, 1);
        n_pts = length(br_complex); n_coeffs = n_max * (n_max + 2);
        A = zeros(n_pts, n_coeffs); col_idx = 1;
        for n = 1:n_max
            P = legendre(n, cosd(colat), 'sch');
            radial_factor = (n + 1) * (a / a)^(n + 2);
            for m = 0:n
                Leg = P(m+1, :)';
                if m == 0, A(:, col_idx) = radial_factor * Leg; col_idx=col_idx+1;
                else, A(:, col_idx) = radial_factor * Leg .* cosd(m*lon); col_idx=col_idx+1;
                      A(:, col_idx) = radial_factor * Leg .* sind(m*lon); col_idx=col_idx+1;
                end
            end
        end
        coeffs_all = A \ br_complex; 
        Rn = zeros(n_max, 1); n_list = (1:n_max)'; curr_idx = 1;
        for n = 1:n_max
            n_m_terms = 2*n + 1;
            c_n = coeffs_all(curr_idx : curr_idx + n_m_terms - 1);
            sum_sq_m = sum(abs(c_n).^2);
            Rn(n) = ((n+1)*(2*n+1)/(4*pi)) * sum_sq_m;
            curr_idx = curr_idx + n_m_terms;
        end
    catch, Rn=[]; n_list=[]; end
end