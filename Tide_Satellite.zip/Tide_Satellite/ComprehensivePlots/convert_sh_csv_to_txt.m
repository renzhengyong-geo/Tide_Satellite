function convert_sh_csv_to_txt()
% =========================================================================
% 功能: 读取球谐系数 CSV → 调用 build_K_matrix_paper 合成磁场
%       → 导出规则网格 TXT → 绘图验证
%
% 输出 TXT 格式 (空格分隔, 共6列, 最后一列已删去):
%     M2  0  余纬度(deg)  经度(0-360)(deg)  实部(nT)  虚部(nT)
% =========================================================================

clc; clear; close all;

% ========================= 1. 配置参数 ==========================
csv_file  = '潮汐磁场结果/MultiSat_Result_HighVol_Strict.csv';
txt_file  = 'M2_tidal_SH.txt';

a         = 6371.2;   % 参考半径 (km)
alt_km    = 430;      % 合成高度 (km)
res_deg   = 3.0;      % 网格分辨率 (度)
N_max     = 32;       % 最高阶次 (与 CSV 系数阶数一致)

font_name = 'Arial';
font_size = 11;

% ========================= 2. 读取球谐系数 ======================
fprintf('1. 读取球谐系数: %s\n', csv_file);
if ~isfile(csv_file)
    error('找不到文件: %s', csv_file);
end

T = readtable(csv_file);
T.Properties.VariableNames = lower(strtrim(T.Properties.VariableNames));
fprintf('   %d 行系数，列名: %s\n', height(T), ...
    strjoin(T.Properties.VariableNames, ', '));

% 按照原始代码的方式组装 U_est (实部虚部交替排列)
num_rows = height(T);
U_est = zeros(2 * num_rows, 1);
U_est(1:2:end) = T.real;
U_est(2:2:end) = T.imag;

% ========================= 3. 构建计算网格 ======================
fprintf('2. 构建坐标网格 (%.1f 度分辨率) ...\n', res_deg);

% 格点中心: 余纬 0.5->179.5, 经度 0.5->359.5
cola_vec = (0.5 : res_deg : 179.5)';   % 余纬度 (度)
lon_vec  = (0.5 : res_deg : 359.5)';   % 经度 (度)
[LON, COLA] = meshgrid(lon_vec, cola_vec);  % n_lat x n_lon

n_lat = numel(cola_vec);
n_lon = numel(lon_vec);
N_pts = n_lat * n_lon;
fprintf('   网格: %d(lat) x %d(lon) = %d 格点\n', n_lat, n_lon, N_pts);

r_plot = (a + alt_km) * ones(N_pts, 1);

% build_K_matrix_paper 输入坐标格式: [r, 余纬度(deg), 经度(deg)]
input_coords = [r_plot, COLA(:), LON(:)];

% ========================= 4. 调用 build_K_matrix_paper 合成 ====
fprintf('3. 调用 build_K_matrix_paper 合成磁场 ...\n');

[K_space, ~, ~] = build_K_matrix_paper(input_coords, ...
    ones(N_pts, 1), zeros(N_pts, 1), N_max, a);

% 复数系数向量
coeffs_complex = U_est(1:2:end) + 1i * U_est(2:2:end);

% K 矩阵与系数相乘得到复数磁场
if size(K_space, 2) == length(U_est)
    B_complex_vec = K_space(:, 1:2:end) * coeffs_complex;
elseif size(K_space, 2) == length(coeffs_complex)
    B_complex_vec = K_space * coeffs_complex;
else
    error('K 矩阵列数 (%d) 与系数长度不匹配', size(K_space, 2));
end

fprintf('   合成完毕。\n');

% ========================= 5. 导出 TXT ==========================
fprintf('4. 写出 TXT: %s ...\n', txt_file);

fid = fopen(txt_file, 'w');
if fid == -1, error('无法创建文件: %s', txt_file); end

cola_flat = COLA(:);
lon_flat  = LON(:);
B_real    = real(B_complex_vec);
B_imag    = imag(B_complex_vec);

for i = 1 : N_pts
    fprintf(fid, 'M2 0 %.1f %.1f %.8e %.8e\n', ...
        cola_flat(i), lon_flat(i), B_real(i), B_imag(i));
end
fclose(fid);
fprintf('   完成，共 %d 行。\n', N_pts);

% ========================= 6. 绘图验证 ==========================
fprintf('5. 绘图验证 ...\n');

B_complex_2D = reshape(B_complex_vec, n_lat, n_lon);
maps  = {real(B_complex_2D), imag(B_complex_2D), ...
         abs(B_complex_2D),  angle(B_complex_2D)*180/pi};
titls = {'a) Real Part', 'b) Imaginary Part', 'c) Amplitude', 'd) Phase (deg)'};
cblabs= {'nT', 'nT', 'Amplitude (nT)', 'Degree'};

fixed_lim = [-2, 2];
clim_amp  = [0, prctile(abs(B_complex_2D(:)), 99)];
clims     = {fixed_lim, fixed_lim, clim_amp, [-180, 180]};

% 配色
try, cmap_div = flipud(nclCM('MPL_PuOr')); catch, cmap_div = bluewhitered(256); end
try, cmap_amp = nclCM('WhiteBlueGreenYellowRed'); catch, cmap_amp = parula(256); end
cmap_phs = hsv(256);
cmaps    = {cmap_div, cmap_div, cmap_amp, cmap_phs};

figure('Color','w','Position',[50 50 1200 580]);
tl = tiledlayout(2, 2, 'TileSpacing','compact','Padding','compact');
title(tl, sprintf('M2 Tidal Magnetic Field  |  Alt = %d km  |  Pacific-Centered', alt_km), ...
      'FontSize',13,'FontWeight','bold','FontName',font_name);

for k = 1:4
    nexttile;
    m_proj('robinson','lon',[0 360]);
    m_pcolor(LON, 90 - COLA, maps{k});
    shading flat;
    m_coast('color',[0.2 0.2 0.2],'linewidth',0.8);
    m_grid('linestyle',':','linewidth',0.5,'tickdir','out',...
           'fontsize',8,'color',[0.5 0.5 0.5],'xtick',6);
    colormap(gca, cmaps{k});
    clim(clims{k});
    title(titls{k},'FontName',font_name,'FontSize',font_size+1,'FontWeight','bold');
    cb = colorbar;
    cb.Label.String   = cblabs{k};
    cb.Label.FontName = font_name;
    cb.FontSize = 8;
    if k == 4
        cb.Ticks      = [-180 -90 0 90 180];
        cb.TickLabels = {'-180','-90','0','90','180'};
    end
end

out_png = strrep(txt_file, '.txt', '_plot.png');
exportgraphics(gcf, out_png, 'Resolution', 200);
fprintf('   图片已保存: %s\n', out_png);
fprintf('\n  全部完成。  TXT: %s\n', txt_file);
end


% =========================================================================
%  备用色表: 蓝-白-红 (nclCM 不可用时)
% =========================================================================
function cmap = bluewhitered(m)
if nargin < 1, m = 256; end
bot = [0.230, 0.299, 0.754];
mid = [0.960, 0.960, 0.960];
top = [0.706, 0.016, 0.150];
h   = floor(m/2);
r   = [linspace(bot(1),mid(1),h), linspace(mid(1),top(1),m-h)]';
g   = [linspace(bot(2),mid(2),h), linspace(mid(2),top(2),m-h)]';
b   = [linspace(bot(3),mid(3),h), linspace(mid(3),top(3),m-h)]';
cmap = [r, g, b];
end