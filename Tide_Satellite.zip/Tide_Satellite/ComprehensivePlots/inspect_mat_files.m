function inspect_mat_files()
    % -------------------------------------------------------------------------
    % Purpose: 批量检查 MAT 文件内部结构
    % 功能：列出变量名、维度、以及结构体内部的字段名
    % -------------------------------------------------------------------------
    clc; clear;
    
    % 设置目标文件夹
    target_dir = '卫星残差数据'; 
    
    % 检查文件夹是否存在
    if ~isfolder(target_dir)
        fprintf(2, '错误: 找不到文件夹 "%s"。请确认路径是否正确。\n', target_dir);
        return;
    end
    
    % 获取所有 .mat 文件
    file_list = dir(fullfile(target_dir, '*.mat'));
    
    if isempty(file_list)
        fprintf('警告: 在 "%s" 中没有找到 .mat 文件。\n', target_dir);
        return;
    end
    
    fprintf('=======================================================\n');
    fprintf('正在检查 "%s" 中的 %d 个文件...\n', target_dir, length(file_list));
    fprintf('=======================================================\n\n');
    
    for i = 1:length(file_list)
        fname = file_list(i).name;
        full_path = fullfile(target_dir, fname);
        
        fprintf('[文件 %d]: %s\n', i, fname);
        
        try
            % 加载文件内容
            S = load(full_path);
            vars = fieldnames(S);
            
            if isempty(vars)
                fprintf('    (空文件 - 无变量)\n');
                continue;
            end
            
            % 遍历文件中的每个变量
            for k = 1:length(vars)
                var_name = vars{k};
                val = S.(var_name);
                
                % 打印变量基本信息
                sz_str = strjoin(string(size(val)), 'x');
                fprintf('    -> 变量名: %-25s | 类型: %-8s | 维度: [%s]\n', ...
                    var_name, class(val), sz_str);
                
                % 如果是结构体，深入打印字段名
                if isstruct(val)
                    fields = fieldnames(val);
                    % 将字段名拼接成字符串，过长则截断
                    f_str = strjoin(fields, ', ');
                    if strlength(f_str) > 100
                        f_str = [char(f_str(1:100)), ' ...'];
                    end
                    fprintf('       [包含字段]: %s\n', f_str);
                    
                    % 关键字段检查 (检查是否包含画图所需的 Pos/Time)
                    has_pos = any(contains(fields, 'Pos'));
                    has_time = any(contains(fields, 'Time'));
                    has_data = any(contains(fields, {'d_obs', 'd_grad', 'B_res'}));
                    
                    if has_pos && has_time && has_data
                        fprintf('       [状态]: \033[32mOK (可以直接用于画图)\033[0m\n'); % 绿色文字(如果支持)
                    else
                        fprintf('       [状态]: \033[33m警告 (缺少 Pos/Time/Data 字段，可能需要特殊处理)\033[0m\n');
                    end
                end
            end
            
        catch ME
            fprintf(2, '    读取失败: %s\n', ME.message);
        end
        fprintf('-------------------------------------------------------\n');
    end
end