function Thesis_Plot_Final_v8_LayoutOptimized()
    % -------------------------------------------------------------------------
    % Purpose: 学位论文最终版 v8 - 布局优化版
    % 
    % Figure 1: 空间分布 (7行2列)
    %   - 纯净展示，移除 ROI 框，避免遮挡磁场细节。
    %
    % Figure 2: 频谱分析 (4行2列)
    %   - Tile 1 (左上角): 专门绘制 ROI 区域示意图 (Map + Rectangles)。
    %   - Tile 2-8: 依次展示 7 颗卫星的频谱。
    %   - 数据源策略保持不变 (MSS=Scalar, GRACE=Grad, Others=Vector)。
    % -------------------------------------------------------------------------
    clc; clear; close all;

    % =========================== 0. 配置 ===========================
    dir_results = '潮汐磁场结果';   
    dir_data    = '卫星残差数据';
    dir_error   = '误差文件';       

    if ~isfolder(dir_results), warning('文件夹 "%s" 不存在', dir_results); end

    % 卫星配置
    sat_config = {
        % Name,       CSV,                                        Resid MAT,                                  Error MAT,                                  Color
        'CHAMP',     'CHAMP_SH_Coefficients_With_Errors.csv',      'CHAMP_Modeling_Input_Abs.mat',           'CHAMP_Full_Inversion_Result.mat',          [0.85, 0.33, 0.10]; 
        'Ørsted',    'Orsted_SH_Coefficients_With_Errors.csv',     'Orsted_ACC_Input_Original_Scalar.mat',   'Orsted_Full_Inversion_Result_Scalar.mat',  [0.55, 0.25, 0.60]; 
        'SAC-C',     'SACC_SH_Coefficients_With_Errors.csv',       'SACC_ACC_Input_Original_Scalar.mat',     'SACC_Full_Inversion_Result_Scalar.mat',    [0.95, 0.70, 0.10]; 
        'GRACE-FO',  'GraceFO_SH_Coefficients_base_ssg_csg.csv',   'GraceFO_CrossSat_Gradient_Weighted.mat', 'GraceFO_Full_Inversion_Result.mat',        [0.40, 0.70, 0.20]; 
        'CryoSat-2', 'CryoSat_SH_Coefficients_With_Errors.csv',    'CryoSat_Input_Original_Weighted.mat',    'CryoSat_Full_Inversion_Result.mat',        [0.00, 0.65, 0.70]; 
        'MSS',       'MSS_SH_Coefficients_With_Errors.csv',        'MSS_Input_Original_Weighted.mat',        'MSS_Full_Inversion_Result.mat',            [0.75, 0.10, 0.20]; 
        'Swarm',     'Swarm_SH_Coefficients_With_Errors.csv',      'Swarm_ACC_Input_Original_Weighted.mat',  'Swarm_Full_Inversion_Result.mat',          [0.00, 0.45, 0.80]; 
    };  
    
    num_sats = size(sat_config, 1);
    alt_km = 450;
    
    % ROI 定义
    roi_broad  = [77.5, 90.5, -40.0, -20.0]; 
    roi_narrow = [77.5, 90.5, -30.5, -25.5]; 

    % 配色准备
    try
        cmap_field = flipud(nclCM('MPL_PuOr')); 
        cmap_error = nclCM('WhiteBlue');        
    catch
        cmap_field = custom_PuOr();
        cmap_error = custom_WhiteBlue();
    end

    % =========================== Figure 1: 空间分布 ===========================
    fprintf('>>> Generating Figure 1 (Spatial Maps - Clean)...\n');
    fig1 = figure('Color', 'w', 'Units', 'centimeters', 'Position', [2, 1, 16.5, 26]); 
    t1 = tiledlayout(fig1, num_sats, 2, 'TileSpacing', 'tight', 'Padding', 'compact');

    for i = 1:num_sats
        name = sat_config{i, 1};
        fprintf('   [Map] Processing: %s...\n', name);
        
        [LON, LAT, B_real] = synthesize_sh_field_safe(fullfile(dir_results, sat_config{i, 2}), alt_km);
        [Map_Error, ~]     = calculate_error_map_fixed(fullfile(dir_error, sat_config{i, 4}), alt_km);
        
        % MSS 截断
        if strcmp(name, 'MSS')
            mask = abs(LAT) > 50;
            B_real(mask) = NaN; Map_Error(mask) = NaN;
        end
        
        % --- 左图：磁场 (移除 ROI 绘制) ---
        ax1 = nexttile(t1);
        plot_map_fast(ax1, LON, LAT, B_real);
        clim(ax1, [-2, 2]);
        
        colormap(ax1, nclCM('CBR_coldhot'));
        % draw_roi_on_map... (DELETED)
        ylabel(ax1, name, 'FontWeight', 'bold', 'FontSize', 11);
        % if i == 1, title(ax1, 'Tidal Magnetic Signal B_r (nT)', 'FontSize', 12, 'FontWeight','bold'); end
        
        % --- 右图：误差 ---
        ax2 = nexttile(t1);
        plot_map_fast(ax2, LON, LAT, Map_Error);
        colormap(ax2, nclCM('CBR_wet'));
        
        vals = Map_Error(~isnan(Map_Error) & Map_Error > 0);
        if isempty(vals), c_min=0; c_max=1; else, c_min=prctile(vals, 5); c_max=prctile(vals, 98); end
        if c_min>=c_max, c_max=c_min+0.1; end
        clim(ax2, [c_min, c_max]);
        
        % if i == 1, title(ax2, 'Error Std. Dev. \sigma (nT)', 'FontSize', 12, 'FontWeight','bold'); end
        
        cb = colorbar(ax2);
        cb.Label.String = 'nT'; cb.FontSize = 8;
        cb.Ticks = [c_min, (c_min+c_max)/2, c_max];
        cb.TickLabels = { sprintf('%.2f', c_min), sprintf('%.2f', (c_min+c_max)/2), sprintf('%.2f', c_max) };
    end
    
    % 底部共享 Colorbar (磁场)
    cax1 = axes(fig1, 'Position', [0.14, 0.03, 0.21, 0.018], 'Visible', 'off');
    clim(cax1, [-2, 2]); colormap(cax1, nclCM('CBR_coldhot'));
    cb1 = colorbar(cax1, 'Location', 'south', 'AxisLocation', 'out');
    cb1.Label.String = 'Re B_r (nT)'; 
    cb1.Label.FontSize = 8; cb1.Label.FontWeight = 'bold';
    
    exportgraphics(fig1, 'Thesis_Fig1_Maps_Clean.png', 'Resolution', 600);
    exportgraphics(fig1, 'Thesis_Fig1_Maps_Clean.pdf', 'Resolution', 600); 
    % =========================== Figure 2: 频谱分析 ===========================
    fprintf('>>> Generating Figure 2 (Spectra + ROI Map)...\n');
    fig2 = figure('Color', 'w', 'Units', 'centimeters', 'Position', [5, 2, 16.5, 18]); 
    t2 = tiledlayout(fig2, 4, 2, 'TileSpacing', 'tight', 'Padding', 'compact');
    
    % --- Tile 1: 绘制 ROI 示意图 (左上角) ---
    ax_roi = nexttile(t2, 1);
    draw_roi_legend_map(ax_roi, roi_narrow, roi_broad);
    
    % --- Tile 2-8: 绘制 7 颗卫星频谱 ---
    freqs = linspace(1/12.8, 1/12.1, 8000); 
    periods = 1./freqs;
    T_M2 = 12.4206;
    
    for i = 1:num_sats
        name = sat_config{i, 1};
        mat_file = fullfile(dir_data, sat_config{i, 3});
        base_col = sat_config{i, 5};
        
        % 放在第 i+1 个格子里 (因为第1个是地图)
        ax = nexttile(t2, i + 1);
        hold(ax, 'on'); box(ax, 'on'); grid(ax, 'on');
        
        % ROI & Type 判断
        if ismember(name, {'MSS', 'SAC-C'})
            cur_roi = roi_broad; roi_tag = 'Broad';
        else
            cur_roi = roi_narrow; roi_tag = 'Narrow';
        end
             
        has_data = false;
        
        if exist(mat_file, 'file')
            S = load(mat_file);
            
            % Swarm 分星
            if strcmp(name, 'Swarm')
                subs = {'Alpha', 'Bravo', 'Charlie'};
                lins = {'-', '--', ':'};
                cols = [0.0, 0.2, 0.6; 0.2, 0.5, 0.8; 0.0, 0.7, 0.9];
                count = 0;
                for sid = 1:3
                    [t_vec, v_vec] = extract_data_strategy(S, cur_roi, name, sid);
                    if length(v_vec)>30
                        [pxx, ~] = plomb(v_vec, t_vec, freqs);
                        plot(periods, pxx, 'Color', cols(sid,:), 'LineStyle', lins{sid}, ...
                             'LineWidth', 1.3, 'DisplayName', ['Swarm-', subs{sid}]);
                        count = count + 1;
                    end
                end
                if count>0, legend(ax, 'Location', 'northeast', 'FontSize', 7, 'Box', 'off'); has_data=true; end
            else
                % 单星
                [t_vec, v_vec] = extract_data_strategy(S, cur_roi, name, []);
                if length(v_vec)>30
                    [pxx, ~] = plomb(v_vec, t_vec, freqs);
                    lw = 1.6; if ismember(name, {'MSS','SAC-C'}), lw=2.0; end
                    plot(periods, pxx, 'Color', base_col, 'LineWidth', lw);
                    has_data=true;
                end
            end
        end
        
        if ~has_data
            text(12.42, 0.5, 'Insufficient Data', 'HorizontalAlignment','center');
        end
        
        xline(ax, T_M2, '-.k', 'M2', 'LabelVerticalAlignment', 'top', 'Alpha', 0.6, 'FontSize', 8,'HandleVisibility', 'off');
        title(ax, sprintf('%s (%s)', name, roi_tag), 'FontSize', 10, 'FontWeight', 'bold');
        xlim(ax, [12.30, 12.55]); 
        % set(ax, 'YTickLabel'); % 仅展示相对幅度，去除刻度
        if i == 1 ||i == 2 || i == 4 || i == 6
           ylabel (ax, 'Magnetic intensity (nT^2)', 'FontSize', 10);
        end
        % 坐标轴标签 (倒数第一行：第4行 -> 对应 Tile 7, 8)
        % i=6 (MSS) -> tile 7; i=7 (Swarm) -> tile 8
        if i >= 6
            xlabel(ax, 'Period (hours)', 'FontSize', 10);
        end
    end
    
    exportgraphics(fig2, 'Thesis_Fig2_Spectra_LayoutOpt.png', 'Resolution', 600);
    exportgraphics(fig2, 'Thesis_Fig2_Spectra_LayoutOpt.pdf', 'Resolution', 600);
    fprintf('Done.\n');
end

% =========================================================================
%                    新增：在 Tile 1 绘制 ROI 示意图
% =========================================================================
function draw_roi_legend_map(ax, roi_narrow, roi_broad)
    axes(ax);
    
    % 使用 Robinson 投影展示全球，突出印度洋
    m_proj('robinson', 'lon', [0 180], 'lat', [-60 20]); % 聚焦印度洋区域
    % 如果想看全球： m_proj('robinson', 'lon', [0 360]);
    
    % 绘制背景
    m_coast('patch', [0.9 0.9 0.9], 'edgecolor', [0.5 0.5 0.5]);
    m_grid('tickdir', 'out', 'linewidth', 0.5, 'linestyle', ':', 'fontsize', 8);
    
    % 绘制 Broad ROI (洋红色)
    draw_roi_box_m(roi_broad, [1, 0, 1], 2.0, '-');
    
    % 绘制 Narrow ROI (青色/深蓝，为了区分)
    draw_roi_box_m(roi_narrow, [0, 0.6, 1], 2.0, '-');
    
    title('Region of Interest (ROI)', 'FontSize', 11, 'FontWeight', 'bold');
    
    % 手动添加图例 (假线)
    hold on;
    h1 = plot(nan, nan, 'Color', [1, 0, 1], 'LineWidth', 2, 'DisplayName', 'Broad (MSS/SAC-C)');
    h2 = plot(nan, nan, 'Color', [0, 0.6, 1], 'LineWidth', 2, 'DisplayName', 'Narrow (Others)');
    
    legend([h1, h2], 'Location', 'southoutside', 'FontSize', 8, 'Box', 'off');
end

function draw_roi_box_m(roi, col, lw, ls)
    % roi: [minLon, maxLon, minLat, maxLat]
    lons = [roi(1), roi(2), roi(2), roi(1), roi(1)];
    lats = [roi(3), roi(3), roi(4), roi(4), roi(3)];
    m_line(lons, lats, 'Color', col, 'LineWidth', lw, 'LineStyle', ls);
end

% =========================================================================
%                    数据提取策略 (保持不变)
% =========================================================================
function [t_hr, v_out] = extract_data_strategy(S, roi, sat_name, target_sat_id)
    t_hr=[]; v_out=[]; D=[];
    
    if contains(sat_name, 'GRACE-FO')
        if isfield(S, 'Data_Scalar_Cross'), D = S.Data_Scalar_Cross; end
        target_field = 'd_grad';
    elseif strcmp(sat_name, 'MSS')
        if isfield(S, 'Data_Scalar_Orig'), D = S.Data_Scalar_Orig; end
        target_field = 'dF';
    elseif ismember(sat_name, {'Ørsted', 'SAC-C'})
        if isfield(S, 'Data_Scalar_Orig'), D = S.Data_Scalar_Orig; end
        target_field = 'dF';
    else
        if isfield(S, 'Data_Vector_Orig'), D = S.Data_Vector_Orig;
        elseif isfield(S, 'Data_Modeling_Abs'), D = S.Data_Modeling_Abs; end
        target_field = 'vector_norm';
    end
    if isempty(D), return; end
    
    if isfield(D, 'Pos'), lt=90-D.Pos(:,2); ln=D.Pos(:,3);
    elseif isfield(D, 'Pos1'), lt=90-D.Pos1(:,2); ln=D.Pos1(:,3); else, return; end
    ln = mod(ln, 360);
    
    mask = (ln>=roi(1) & ln<=roi(2) & lt>=roi(3) & lt<=roi(4));
    if ~isempty(target_sat_id) && isfield(D, 'SatID'), mask = mask & (D.SatID==target_sat_id); end
    if sum(mask)<10, return; end
    
    if isfield(D, 'Time'), t_raw=D.Time(mask); else, t_raw=D.Time1(mask); end
    
    if strcmp(target_field, 'd_grad') && isfield(D, 'd_grad')
        val = D.d_grad(mask);
    elseif strcmp(target_field, 'dF') && isfield(D, 'dF')
        val = D.dF(mask);
    elseif strcmp(target_field, 'vector_norm') && isfield(D, 'B_res')
        val = vecnorm(D.B_res(mask,:), 2, 2);
    else
        if isfield(D, 'dF'), val=D.dF(mask);
        elseif isfield(D, 'd_grad'), val=D.d_grad(mask);
        elseif isfield(D, 'B_res'), val=vecnorm(D.B_res(mask,:), 2, 2);
        else, return; end
    end
    
    [t_uni, ~, idx] = unique(t_raw);
    v_uni = accumarray(idx, val, [], @mean);
    t_hr = (t_uni - min(t_uni)) * 24; v_out = v_uni - mean(v_uni);
end

% =========================================================================
%                             辅助函数
% =========================================================================
function plot_map_fast(ax, LON, LAT, Data)
    axes(ax); m_proj('robinson', 'lon', [0 360]);
    if all(isnan(Data(:))), m_grid('box','on','xtick',[],'ytick',[]); return; end
    m_pcolor(LON, LAT, Data); shading interp;
    m_coast('color', [0.3 0.3 0.3], 'LineWidth', 0.5);
    m_grid('xtick', [], 'ytick', [], 'linestyle', '-', 'color', 'none', 'box', 'on');
end
function [Map_Error, N_max] = calculate_error_map_fixed(mat_path, alt_km)
    [LON, LAT] = meshgrid(0:2:360, -89:2:89);
    Map_Error = nan(size(LON)); N_max = 0;
    if ~exist(mat_path, 'file'), return; end
    try
        D = load(mat_path);
        if ~isfield(D, 'C_tau'), return; end
        C_tau = double(D.C_tau);
        dim = size(C_tau, 1);
        if isfield(D, 'N_max'), N_max = double(D.N_max);
        else, N_try = sqrt(dim+1)-1; 
             if abs(N_try-round(N_try))<1e-4, N_max=round(N_try); else, N_max=round(sqrt(dim)-1); end
        end
        res = 4;
        [LON_E, LAT_E] = meshgrid(0:res:360, -89:res:89);
        r_plot = (6371.2+alt_km)*ones(size(LON_E));
        if exist('build_K_matrix_paper', 'file')
            N_val = double(round(N_max));
            [Kr,~,~] = build_K_matrix_paper([r_plot(:), 90-LAT_E(:), LON_E(:)], ones(numel(LON_E),1), zeros(numel(LON_E),1), N_val, 6371.2);
            num_pts = size(Kr,1); Field_Var = zeros(num_pts,1);
            for b = 1:2000:num_pts
                idx = b:min(b+2000-1, num_pts);
                Field_Var(idx) = real(sum((Kr(idx,:)*C_tau).*Kr(idx,:), 2));
            end
            Map_Low = reshape(sqrt(abs(Field_Var)), size(LON_E));
            Map_Error = interp2(LON_E, LAT_E, Map_Low, LON, LAT, 'spline');
        end
    catch, end
end
function [LON, LAT, B_real] = synthesize_sh_field_safe(csv_path, alt_km)
    [LON, LAT] = meshgrid(0:2:360, -89:2:89); B_real = nan(size(LON));
    if ~exist(csv_path, 'file'), return; end
    try
        T = readtable(csv_path);
        if width(T) >= 4
            if ismember('Real_Part', T.Properties.VariableNames), coeffs = T.Real_Part + 1i*T.Imag_Part; deg = T.Degree_n;
            else, coeffs = T{:,3} + 1i*T{:,4}; deg = T{:,1}; end
            if exist('build_K_matrix_paper', 'file')
                r_plot = (6371.2+alt_km)*ones(size(LON));
                [K_space,~,~] = build_K_matrix_paper([r_plot(:), 90-LAT(:), LON(:)], ones(numel(LON),1), zeros(numel(LON),1), double(round(max(deg))), 6371.2);
                B_real = real(reshape(K_space(:,1:2:end)*coeffs, size(LON)));
            end
        end
    catch, end
end
% --- Fallback Colormaps ---
function cmap = custom_WhiteBlue()
    n = 256;
    cmap = [linspace(1, 0.05, n)', linspace(1, 0.2, n)', linspace(1, 0.6, n)'];
end
function cmap = custom_PuOr()
    c1 = [0.5 0.25 0]; c_mid = [0.98 0.98 0.98]; c2 = [0.3 0 0.5];
    n = 128;
    part1 = [linspace(c1(1),c_mid(1),n)', linspace(c1(2),c_mid(2),n)', linspace(c1(3),c_mid(3),n)'];
    part2 = [linspace(c_mid(1),c2(1),n)', linspace(c_mid(2),c2(2),n)', linspace(c_mid(3),c2(3),n)'];
    cmap = flipud([part1; part2]);
end

function cmap_out = get_interpolated_ncl_cmap(n_levels)
    % 基于您提供的图片 (drought_severity) 进行扩展
    % 原图逻辑：深绿 -> 浅绿 -> 奶油黄 -> 橙 -> 深红
    % 新增逻辑：在深绿之前，加入 深蓝 -> 青蓝 进行过渡
    
    cmap_raw = [
        % --- 新增的蓝色系 (极低值) ---
        % 0.10 0.25 0.70; % 1. 湛蓝 (Deep Blue)
        0.0 0.55 0.75; % 2. 湖蓝/青色 (Cerulean/Cyan) - 蓝绿完美过渡
        
        % --- 原图的绿色系 ---
        % 0.18 0.57 0.30; % 3. 深绿 (Dark Green - 原图左1)
        0.45 0.76 0.45; % 4. 中绿 (Medium Green - 原图左2)
        0.72 0.85 0.60; % 5. 浅绿 (Light Green - 原图左3)
        
        % --- 原图的中间色 ---
        1.00 0.98 0.75; % 6. 奶油色 (Cream - 原图中间)
        
        % --- 原图的红色系 (高值) ---
        0.96 0.73 0.40; % 7. 沙色 (Sand/Light Orange - 原图右3)
        0.93 0.45 0.20; % 8. 橙色 (Orange - 原图右2)
        0.86 0.08 0.15  % 9. 深红 (Deep Red - 原图右1)
    ];
    
    % --- 插值处理 ---
    n_old = size(cmap_raw, 1);
    x = 1:n_old;       
    xq = linspace(1, n_old, n_levels);   
    
    % 使用 pchip 插值保证色彩过渡的鲜艳度
    r_new = interp1(x, cmap_raw(:,1), xq, 'pchip');
    g_new = interp1(x, cmap_raw(:,2), xq, 'pchip');
    b_new = interp1(x, cmap_raw(:,3), xq, 'pchip');
    
    cmap_out = [r_new', g_new', b_new'];
    cmap_out(cmap_out < 0) = 0;
    cmap_out(cmap_out > 1) = 1;
end