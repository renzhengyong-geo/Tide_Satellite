function Plot_N2_Coefficient_Differences_Thesis()
% -------------------------------------------------------------------------
% Purpose: 比较 Ours (MAT), HRM2, CM6, Kalman 与 正演模型 (DAT) 的系数差异 (N2)
% 公式参考：式(12) S(n,m) = 100 * (Coeff_e - Coeff_r) / RMS_n(Ref)
% -------------------------------------------------------------------------
clc; close all;

%% ========= 1. 参数与文件配置 =========
const.a_radius = 6371.2; 
const.N_max    = 15;      % 统一对比阶数

% 文件路径
file_Ours   = '潮汐磁场结果/Joint_SwarmA_MSS1_EP_Result_N2.mat';
file_HRM2   = 'Grayver_result/HRN2.txt';
file_CM6    = 'CM6/N2.txt';
file_Kalman = 'Kalman_result/N2/Model/TIDALN2_MEAN_Radius_6371.2.txt';
file_Fwd    = '正演模拟结果/n2/B_surface.dat'; 

% 绘图风格
cfg.bg_color = 'w';
cfg.txt_color = 'k';
cfg.cmap_limit = [-5 5]; % 差异百分比范围，设为对称以配合发散色标

%% ========= 2. 数据读取 =========
fprintf('1. 正在读取各模型系数 (N2)...\n');
Fwd_Coeffs    = load_dat_forward_model(file_Fwd, const);
Ours_Coeffs   = load_ours_mat_result(file_Ours, const.N_max);
HRM2_Coeffs   = load_coeffs_robust(file_HRM2,   'HRM2',   10);
CM6_Coeffs    = load_coeffs_robust(file_CM6,    'CM6',    7);
Kalman_Coeffs = load_coeffs_robust(file_Kalman, 'Kalman', 0);

%% ========= 3. 计算差异矩阵 (有正负) =========
fprintf('2. 正在计算归一化差异矩阵(有正负)...\n');

S_Ours   = compute_diff_matrix_signed(Ours_Coeffs,   Fwd_Coeffs, const.N_max);
S_HRM2   = compute_diff_matrix_signed(HRM2_Coeffs,   Fwd_Coeffs, const.N_max);
S_CM6    = compute_diff_matrix_signed(CM6_Coeffs,    Fwd_Coeffs, const.N_max);
S_Kalman = compute_diff_matrix_signed(Kalman_Coeffs, Fwd_Coeffs, const.N_max);

%% ========= 4. 绘图 (2x2) =========
fig = figure('Color', cfg.bg_color, 'Unit', 'Centimeters', 'Position', [2 2 18 18]);
t = tiledlayout(2, 2, 'TileSpacing', 'compact', 'Padding', 'loose');

data_list = {S_Ours, S_HRM2, S_CM6, S_Kalman};
titles    = {'(a) Ours - Model', '(b) HRM2 - Model', '(c) CM6 - Model', '(d) Kalman - Model'};

% 创建发散色标 (蓝-白-红)
cmap = nclCM('BlueDarkRed18');

for i = 1:4
    ax = nexttile(t);
    
    % 判断是否在最左侧列 (i=1, 3)
    is_left = (mod(i, 2) == 1);
    % 判断是否在最下侧行 (i=3, 4)
    is_bottom = (i > 2);
    
    plot_triangle_signed(ax, data_list{i}, const.N_max, cfg, cmap, is_left, is_bottom);
    title(ax, titles{i}, 'Color', cfg.txt_color, 'FontWeight', 'bold', 'FontSize', 11);
end

% --- 统一色条 ---
cb = colorbar;
cb.Layout.Tile = 'south';
cb.Label.String = 'Normalized Coefficient Difference (%)';
cb.Label.FontWeight = 'bold';
cb.Label.FontSize = 10;
clim(cfg.cmap_limit);

exportgraphics(fig, 'N2_Signed_Differences.pdf', 'Resolution', 600);
fprintf('3. 绘图完成: N2_Signed_Differences.pdf\n');

end

%% ========================================================================
%                      核心计算函数 (更新公式 12)
%% ========================================================================

function S = compute_diff_matrix_signed(Eval_Mod, Ref_Mod, nmax)
    % 按照公式 12 计算差异百分比
    S = nan(nmax+1, 2*nmax+1);
    center = nmax + 1;
    
    for n = 1:nmax
        % 1. 计算分母 Dn (参考模型第 n 阶的均方根能量 - 基于实部)
        sum_sq = 0;
        for m = -n:n
            val_R = get_complex_val(Ref_Mod, n, m);
            sum_sq = sum_sq + (real(val_R)^2); 
        end
        Dn = sqrt(sum_sq / (2*n + 1));
        if Dn < 1e-18, Dn = 1e-18; end 

        % 2. 计算每个 m 的差异 
        for m = -n:n
            val_E = get_complex_val(Eval_Mod, n, m);
            val_R = get_complex_val(Ref_Mod,  n, m);
            
            % 统一相减实部数值（修复后的 get_complex_val 已能正确返回对应的实数值）
            diff_val = (real(val_E) - real(val_R)) / Dn;
            
            S(n+1, center + m) = diff_val;
        end
    end
end

%% ========================================================================
%                      配色与辅助绘图
%% ========================================================================

function cmap = custom_div_cmap(m)
    % 创建发散色标：深蓝 - 白 - 深红
    b = [0.0, 0.0, 0.5]; % 深蓝
    w = [1.0, 1.0, 1.0]; % 白
    r = [0.5, 0.0, 0.0]; % 深红
    
    half = floor(m/2);
    r_map = [linspace(b(1), w(1), half)'; linspace(w(1), r(1), m-half)'];
    g_map = [linspace(b(2), w(2), half)'; linspace(w(2), r(2), m-half)'];
    b_map = [linspace(b(3), w(3), half)'; linspace(w(3), r(3), m-half)'];
    cmap = [r_map, g_map, b_map];
end

function plot_triangle_signed(ax, S, nmax, cfg, cmap, is_left, is_bottom)
    % 绘图逻辑优化：彻底去除方框
    x_axis = -nmax : nmax;
    y_axis = 0 : nmax;
    
    % 在 axes 上绘图
    h = imagesc(ax, x_axis, y_axis, S);
    set(h, 'AlphaData', ~isnan(S));
    
    % 1. 彻底关闭方框和坐标轴显示
    set(ax, 'Box', 'off', 'Color', 'none');
    set(ax, 'XColor', 'none', 'YColor', 'none'); % 隐藏坐标轴线
    
    % 2. 绘制三角形外框
    hold(ax, 'on');
    plot(ax, [-nmax 0 nmax -nmax], [nmax 0 nmax nmax], 'k-', 'LineWidth', 1.2);
    plot(ax, [0 0], [0 nmax], 'k:', 'LineWidth', 0.5); 
    
    % 3. 手动设置需要的刻度
    % 重新打开坐标轴显示用于刻度 (只显示刻度，不显示边框)
    if is_left
        set(ax, 'YColor', 'k', 'YTick', 0:5:nmax);
        ylabel(ax, 'degree {\itn}', 'FontWeight', 'bold', 'Color', 'k');
    end
    
    if is_bottom
        set(ax, 'XColor', 'k', 'XTick', -nmax:5:nmax);
        xlabel(ax, '{h_n^m}, order({\itm}), {g_n^m}', 'FontSize', 10, 'FontWeight', 'bold');
    end
    
    % 4. 设置范围和颜色
    colormap(ax, cmap);
    clim(ax, cfg.cmap_limit);
    xlim(ax, [-nmax-0.5, nmax+0.5]);
    ylim(ax, [0.5, nmax+0.5]);
    set(ax, 'TickDir', 'out');
end

%% ========================================================================
%                      数据读取与解析函数 (重点修复区)
%% ========================================================================

function val = get_complex_val(Data, n, m)
    % 修复版：智能兼容只存正 m，用第 4 列存虚部 h 的格式
    if isempty(Data)
        val = 0; 
        return; 
    end
    
    if m >= 0
        % m >= 0: 在 Data 中寻找 n, m 对应的 g_n^m (通常存放在第三列)
        idx = find(Data(:,1) == n & Data(:,2) == m, 1);
        if ~isempty(idx)
            val = Data(idx, 3);
        else
            val = 0;
        end
    else
        % m < 0: 寻找 h_n^{|m|}
        abs_m = abs(m);
        
        % 尝试 1: 直接寻找 Data 中是否有记录负 m (适用于 Ours 或 Kalman 格式)
        idx_neg = find(Data(:,1) == n & Data(:,2) == m, 1);
        if ~isempty(idx_neg)
            val = Data(idx_neg, 3);
            return;
        end
        
        % 尝试 2: 找不到负 m, 说明文件可能是标准 (g, h) 格式 (如 CM6, HRM2)
        % 此时寻找对应的正 m, 并提取其第 4 列作为 h_n^m
        idx_pos = find(Data(:,1) == n & Data(:,2) == abs_m, 1);
        if ~isempty(idx_pos) && size(Data, 2) >= 4
            val = Data(idx_pos, 4);
        else
            val = 0;
        end
    end
end

function D = load_ours_mat_result(fname, max_n)
    if ~isfile(fname), error('找不到: %s', fname); end
    data = load(fname);
    f = fieldnames(data); % 动态获取结构体名称增强鲁棒性
    coeffs_vec = data.(f{1}).Coeffs;
    
    D = []; ptr = 1;
    for n = 1:max_n
        m_list = [0, reshape([1:n; -(1:n)], 1, [])];
        for m = m_list
            D = [D; n, m, coeffs_vec(ptr), coeffs_vec(ptr+1)];
            ptr = ptr + 2;
        end
    end
end

function D = load_dat_forward_model(filepath, const)
    raw = readmatrix(filepath);
    lon = raw(:,1); lat = raw(:,2);
    field = double(raw(:,3)) + 1i * double(raw(:,4));
    coeffs = sha_solver_vectorized(90-lat, lon, field, const.a_radius, const);
    D = coeffs_to_standard_format(coeffs, const.N_max);
end

function D = load_coeffs_robust(fname, label, nskip)
    if ~isfile(fname), warning('跳过 %s: 未找到文件', label); D = []; return; end
    try
        if contains(label, 'Kalman')
            % 修复：防止由于存在表头引起的 Kalman 读取失败
            try
                raw = readmatrix(fname);
                if any(isnan(raw(:,1)))
                    raw = readmatrix(fname, 'NumHeaderLines', 1);
                end
            catch
                T = readtable(fname);
                raw = T{:, :};
            end
            D = reconstruct_kalman_structure(raw);
        else
            raw = readmatrix(fname, 'NumHeaderLines', nskip);
            D = raw(:, 1:4);
        end
    catch ME
        warning('%s 读取失败: %s', label, ME.message); D = [];
    end
end

function D = reconstruct_kalman_structure(raw)
    n_rows = size(raw, 1);
    re_vals = raw(:, 1); 
    im_vals = raw(:, 2);
    D = []; ptr = 1; n = 1;
    
    while ptr <= n_rows
        num = 2*n + 1;
        if ptr + num - 1 > n_rows, break; end
        
        % 生成 m 列表: [0, 1, -1, 2, -2...]
        m_list = zeros(num, 1);
        m_list(1) = 0;
        k = 2;
        for v = 1:n
            m_list(k) = v; m_list(k+1) = -v; k = k + 2;
        end
        
        D = [D; [repmat(n, num, 1), m_list, re_vals(ptr:ptr+num-1), im_vals(ptr:ptr+num-1)]];
        ptr = ptr + num; n = n + 1;
    end
end

function coeffs = sha_solver_vectorized(colat, lon, data, r_data, const)
    N_max = const.N_max; a = const.a_radius;
    n_pts = length(colat); n_coeffs = N_max * (N_max + 2);
    A = zeros(n_pts, n_coeffs); col_idx = 1;
    rad_ratio = a / r_data; cos_colat = cosd(colat);
    
    for n = 1:N_max
        radial_term = (n + 1) * (rad_ratio)^(n + 2);
        P = legendre(n, cos_colat', 'sch');
        for m = 0:n
            P_nm = P(m+1, :)';
            if m == 0
                A(:, col_idx) = radial_term * P_nm; col_idx = col_idx + 1;
            else
                A(:, col_idx) = radial_term * P_nm .* cosd(m * lon); col_idx = col_idx + 1;
                A(:, col_idx) = radial_term * P_nm .* sind(m * lon); col_idx = col_idx + 1;
            end
        end
    end
    coeffs = A \ data;
end

function D = coeffs_to_standard_format(coeffs, N_max)
    D = []; idx = 1;
    for n = 1:N_max
        num_m = 2*n + 1;
        c_n = coeffs(idx : idx + num_m - 1);
        D = [D; n, 0, real(c_n(1)), imag(c_n(1))];
        for m = 1:n
            D = [D; n, m, real(c_n(2*m)), imag(c_n(2*m))];
            D = [D; n, -m, real(c_n(2*m+1)), imag(c_n(2*m+1))];
        end
        idx = idx + num_m;
    end
end