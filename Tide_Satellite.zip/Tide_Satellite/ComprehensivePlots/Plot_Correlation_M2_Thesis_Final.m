function Plot_Correlation_M2_Thesis_Final()
    % -------------------------------------------------------------------------
    % Purpose: M2 相关系数热力图 (单图模式)
    % Fix: 1. 恢复 M2 文件配置; 2. 修复 Kalman 加载; 3. 修复 Ørsted 显示
    % -------------------------------------------------------------------------
    clc; clear; close all;

    % ================= 1. M2 参数与模型配置 =================
    const.a_radius = 6371.2;  
    const.N_max    = 30; 
    
    % M2 模型配置表 (请确认路径与文件名正确)
    full_config = {
        'CSV',    'Ørsted',     '潮汐磁场结果/Orsted_SH_Coefficients_With_Errors.csv',   0;
        'CSV',    'SAC-C',      '潮汐磁场结果/SACC_SH_Coefficients_With_Errors.csv',     0;
        'CSV',    'CHAMP',      '潮汐磁场结果/CHAMP_SH_Coefficients_With_Errors.csv',    0;
        'CSV',    'Swarm',      '潮汐磁场结果/Swarm_SH_Coefficients_With_Errors.csv',    0;
        'CSV',    'CryoSat-2',  '潮汐磁场结果/CryoSat_SH_Coefficients_With_Errors.csv',  0;
        'CSV',    'GRACE-FO',   '潮汐磁场结果/GraceFO_SH_Coefficients_base_ssg_csg.csv', 0;
        'CSV',    'MSS-1A',     '潮汐磁场结果/MSS_SH_Coefficients_With_Errors.csv',      0;
        'TXT_D',  'CM6',        'CM6/M2.txt',                                            7;
        'Kalman', 'Kalman',     'Kalman_result/M2/Model/TIDALM2_MEAN_Radius_6371.2.txt', 0;
        'TXT_D',  'GO19',       'GO19/M2.txt',                                           10;
        'TXT_D',  'HRM2',       'Grayver_result/HRM2.txt',                               10;
        'CSV',    'Ours',       '潮汐磁场结果/MultiSat_Result_HighVol_Strict.csv',       0;
        'H5',     'Model',      '正演模拟结果/KUV_RES_0001.h5',                          0;
    };

    % ================= 2. 用户自定义区域 (切换分组) =================
    
    % --- [分组 A] 单星结果 ---
    current_group = {'Ørsted', 'SAC-C', 'CHAMP', 'Swarm', 'CryoSat-2', 'GRACE-FO', 'MSS-1A', 'Model'};
    out_name = 'Correlation_M2_SingleSats.pdf';
    sub_title = '(a) Single Satellite Correlation (M2)';
    my_colormap = 'MPL_Greens';
    
    % --- [分组 B] 综合结果 (对比时取消下面注释，注释上面) ---
    % current_group = {'CM6', 'Kalman', 'GO19', 'HRM2', 'Ours', 'Model'};
    % out_name = 'Correlation_M2_ResearchModels.pdf';
    % sub_title = '(b) Research Models Correlation (M2)';
    % my_colormap = 'MPL_Greens';

    my_clim = [0.36, 1.28];   % 色标显示范围
    text_threshold = 0.85;   % 大于该值文字显示为白色

    % ================= 3. 数据加载逻辑 =================
    final_labels = {};
    final_vectors = {};

    fprintf('正在加载 M2 模型数据...\n');
    for i = 1:length(current_group)
        target = current_group{i};
        found_idx = -1;
        for k = 1:size(full_config, 1)
            if strcmp(full_config{k,2}, target), found_idx = k; break; end
        end
        if found_idx == -1, continue; end
        
        fmt = full_config{found_idx,1}; path = full_config{found_idx,3}; nskip = full_config{found_idx,4};
        try
            c = [];
            if strcmp(fmt,'H5'), c = get_forward_coeffs_h5(path, const);
            elseif strcmp(fmt,'CSV'), c = get_csv_coeffs_real(path);
            elseif strcmp(fmt,'TXT_D'), raw = readmatrix(path, 'NumHeaderLines', nskip); c = extract_1d_from_D(raw(:,1:4));
            elseif strcmp(fmt,'Kalman'), c = get_kalman_coeffs_robust(path); 
            end
            
            if ~isempty(c)
                final_labels{end+1} = target; %#ok<AGROW>
                final_vectors{end+1} = c(:); %#ok<AGROW>
                fprintf('  [成功] %s (长度: %d)\n', target, length(c));
            end
        catch ME
            fprintf('  [失败] %s: %s\n', target, ME.message);
        end
    end

    % ================= 4. 计算与绘图 =================
    num = length(final_labels);
    mat = eye(num);
    for i = 1:num
        for j = i+1:num
            v1 = final_vectors{i}; v2 = final_vectors{j};
            L = min(length(v1), length(v2));
            if L > 1, r = corrcoef(v1(1:L), v2(1:L)); mat(i,j) = r(1,2); mat(j,i) = r(1,2); end
        end
    end

    fig = figure('Color', 'w', 'Units', 'centimeters', 'Position', [5, 5, 16.5, 15]);
    ax = axes(fig, 'Position', [0.18, 0.2, 0.65, 0.65]);
    imagesc(ax, mat); hold(ax, 'on');
    try colormap(ax, nclCM(my_colormap)); catch, colormap(ax, 'summer'); end
    clim(ax, my_clim); axis(ax, 'image');

    % 手动书写数值标签 (控制颜色)
    for i = 1:num
        for j = 1:num
            val = mat(i, j);
            if val > text_threshold, tColor = 'w'; else, tColor = 'k'; end
            text(ax, j, i, sprintf('%.2f', val), 'HorizontalAlignment', 'center', ...
                'Color', tColor, 'FontSize', 12, 'FontWeight', 'bold');
        end
    end

    set(ax, 'XTick', 1:num, 'XTickLabel', final_labels, 'YTick', 1:num, 'YTickLabel', final_labels, ...
            'FontSize', 10, 'FontWeight', 'bold', 'TickLength', [0 0]);
    xtickangle(ax, 45); title(ax, sub_title, 'FontSize', 12, 'FontWeight', 'bold');
    
    % 白色格线
    for k = 0.5 : 1 : num+0.5
        line(ax, [0.5 num+0.5], [k k], 'Color', 'w', 'LineWidth', 0.8);
        line(ax, [k k], [0.5 num+0.5], 'Color', 'w', 'LineWidth', 0.8);
    end

    
    exportgraphics(fig, out_name, 'Resolution', 600);
end

% =========================================================================
%                         Kalman 鲁棒读取函数 (M2)
% =========================================================================
function c = get_kalman_coeffs_robust(path)
    if ~isfile(path), c=[]; return; end
    try
        raw = readmatrix(path);
        if any(isnan(raw(1,:))), raw = readmatrix(path, 'NumHeaderLines', 1); end
    catch
        T = readtable(path); raw = T{:, :};
    end
    
    n_rows = size(raw, 1);
    re_vals = raw(:, 1); im_vals = raw(:, 2);
    D = []; ptr = 1; n = 1;
    while ptr <= n_rows
        num = 2*n + 1;
        if ptr + num - 1 > n_rows, break; end
        m_list = zeros(num, 1); m_list(1) = 0; k = 2;
        for v = 1:n
            m_list(k) = v; m_list(k+1) = -v; k = k + 2;
        end
        D = [D; [repmat(n, num, 1), m_list, re_vals(ptr:ptr+num-1), im_vals(ptr:ptr+num-1)]];
        ptr = ptr + num; n = n + 1;
    end
    c = extract_1d_from_D(D);
end

% =========================================================================
%                               数据处理辅助
% =========================================================================
function c = get_forward_coeffs_h5(filepath, const)
    Re_Ht_r = h5read(filepath, '/Re_Ht_r');
    Im_Ht_r = h5read(filepath, '/Im_Ht_r');
    Theta   = h5read(filepath, '/Theta');
    Phi     = h5read(filepath, '/Phi');
    field_nT = (double(Re_Ht_r) + 1i * double(Im_Ht_r)) * (4 * pi * 100);
    r_data = const.a_radius; 
    if contains(filepath, '450Km'), r_data = r_data + 450; end
    coeffs = sha_solver_vectorized(double(Theta(:)), double(Phi(:)), field_nT(:), r_data, const);
    D = coeffs_to_standard_format(coeffs, const.N_max);
    c = extract_1d_from_D(D);
end

function coeffs = sha_solver_vectorized(colat, lon, data, r_data, const)
    N_max = const.N_max; a = const.a_radius;
    A = zeros(length(colat), N_max * (N_max + 2));
    col_idx = 1; rad_ratio = a / r_data; cos_colat = cosd(colat);
    for n = 1:N_max
        radial_term = (n + 1) * (rad_ratio)^(n + 2);
        P = legendre(n, cos_colat', 'sch');
        for m = 0:n
            P_nm = P(m+1, :)'; term_common = radial_term * P_nm;
            if m == 0
                A(:, col_idx) = term_common; col_idx = col_idx + 1;
            else
                A(:, col_idx) = term_common .* cosd(m * lon); col_idx = col_idx + 1;
                A(:, col_idx) = term_common .* sind(m * lon); col_idx = col_idx + 1;
            end
        end
    end
    coeffs = A \ data;
end

function D = coeffs_to_standard_format(coeffs, N_max)
    D = []; idx = 1;
    for n = 1:N_max
        num_m = 2*n + 1;
        c_n = coeffs(idx : idx + num_m - 1);
        D = [D; n, 0, real(c_n(1)), imag(c_n(1))];
        for m = 1:n
            D = [D; n, m, real(c_n(2*m)), imag(c_n(2*m))];
            D = [D; n, -m, real(c_n(2*m+1)), imag(c_n(2*m+1))];
        end
        idx = idx + num_m;
    end
end

function c = get_csv_coeffs_real(f)
    if ~isfile(f), c=[]; return; end
    T = readtable(f); v = T.Properties.VariableNames;
    if ismember('Real',v), c=T.Real; elseif ismember('Real_Part',v), c=T.Real_Part;
    elseif width(T)>=4, c=T{:,3}; else, c=[]; end
    if ~isempty(c), c(isnan(c))=0; end
end

function vec = extract_1d_from_D(D)
    if isempty(D), vec =[]; return; end
    max_n = max(D(:,1)); vec =[];
    for n = 1:max_n
        idx0 = find(D(:,1)==n & D(:,2)==0, 1);
        if ~isempty(idx0), vec(end+1, 1) = D(idx0, 3); else, vec(end+1, 1) = 0; end
        for m = 1:n
            idx_pos = find(D(:,1)==n & D(:,2)==m, 1);
            if ~isempty(idx_pos), vec(end+1, 1) = D(idx_pos, 3); else, vec(end+1, 1) = 0; end
            idx_neg = find(D(:,1)==n & D(:,2)==-m, 1);
            if ~isempty(idx_neg), vec(end+1, 1) = D(idx_neg, 3); 
            elseif ~isempty(idx_pos) && size(D, 2) >= 4, vec(end+1, 1) = D(idx_pos, 4);
            else, vec(end+1, 1) = 0; end
        end
    end
end