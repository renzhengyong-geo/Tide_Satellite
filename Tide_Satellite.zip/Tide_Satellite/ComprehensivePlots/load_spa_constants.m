function spa_const_data = load_spa_constants()
    % Load SPA constants into a structure
    spa_const;
    spa_const_data.elevation = 0;
    spa_const_data.pressure = 1013;
    spa_const_data.temperature = 15;
    spa_const_data.slope = 30;
    spa_const_data.azm_rotation = -10;
    spa_const_data.atmos_refract = 0.5677;
    spa_const_data.delta_ut1 = 0;
    spa_const_data.delta_t = 67;
    spa_const_data.SPA_ZA_INC = 1;
end