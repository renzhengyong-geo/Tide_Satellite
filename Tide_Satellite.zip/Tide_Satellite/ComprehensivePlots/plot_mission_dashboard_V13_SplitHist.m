function plot_mission_dashboard_V13_SplitHist()
% -------------------------------------------------------------------------
% Purpose: 学位论文级多源卫星综合展示 (V13 分栏直方图版)
% Changes:
%   1. [布局] Panel C 分为左右两栏：左侧展示绝对数据(Abs)，右侧展示梯度数据(Grad)。
%   2. [逻辑] 用于对比不同数据类型的分布形态，说明反演中的截断策略。
% -------------------------------------------------------------------------

clc; close all;

% ================= [路径设置] =================
data_dir = '卫星残差数据';
% =============================================

fprintf('正在生成 V13 分栏直方图版图件...\n');

% --- 1. 配色与配置 ---
cols.CHAMP   = [68, 93, 107]/255;
cols.GraceFO = [207, 109, 102]/255;
cols.MSS     = [235, 185, 10]/255;
cols.Orsted  = [100, 190, 175]/255;
cols.SACC    = [165, 120, 185]/255;
cols.Swarm   = [52, 138, 189]/255;
cols.CryoSat = [114, 158, 206]/255;

sat_list = {'SAC-C', 'Orsted', 'CHAMP', 'CryoSat', 'GraceFO', 'Swarm', 'MSS'};
sat_map = containers.Map(sat_list, {cols.SACC, cols.Orsted, cols.CHAMP, cols.CryoSat, cols.GraceFO, cols.Swarm, cols.MSS});
marker_map = containers.Map(sat_list, {'^', 'v', 's', 'o', 'd', 'p', 'h'});

% 文件映射表 (Col 3: Type)
files = {
    'CHAMP_Modeling_Input_Abs.mat', 'CHAMP', 'Abs';
    'CHAMP_Modeling_Input_Grad.mat', 'CHAMP', 'Grad';
    'GraceFO_ACC_Input_Gradient_Weighted.mat', 'GraceFO', 'Grad';
    'GraceFO_ACC_Input_Original_Weighted.mat', 'GraceFO', 'Abs';
    'GraceFO_CrossSat_Gradient_Weighted.mat', 'GraceFO', 'Cross';
    'MSS_Input_Gradient_Weighted.mat', 'MSS', 'Grad';
    'MSS_Input_Original_Weighted.mat', 'MSS', 'Abs';
    'Orsted_ACC_Input_Gradient_Scalar.mat', 'Orsted', 'Grad';
    'Orsted_ACC_Input_Original_Scalar.mat', 'Orsted', 'Abs';
    'SACC_ACC_Input_Gradient_Scalar.mat', 'SAC-C', 'Grad';
    'SACC_ACC_Input_Original_Scalar.mat', 'SAC-C', 'Abs';
    'Swarm_ACC_Input_Gradient_Weighted.mat', 'Swarm', 'Grad';
    'Swarm_ACC_Input_Original_Weighted.mat', 'Swarm', 'Abs';
    'Swarm_CrossSat_Gradient_Weighted.mat', 'Swarm', 'Cross';
    'CryoSat_Input_Original_Weighted.mat', 'CryoSat', 'Abs';
    'CryoSat_Input_Gradient_Weighted.mat', 'CryoSat', 'Grad';
    };

% 数据容器
TimelineData = struct('Sat', {}, 'Type', {}, 'Start', {}, 'End', {}, 'Count', {});
LatProfileData = struct('Sat', {}, 'Lat', {}, 'SumSq', {}, 'Count', {});

% [修改] 直方图数据池：分开存储 Abs 和 Grad
HistDataPool = struct('Sat', {}, 'AbsValues', {}, 'GradValues', {});

% --- 2. 数据读取 ---
files_found = 0;
for i = 1:size(files, 1)
    fname = files{i,1}; sat_name = files{i,2}; type_name = files{i,3};
    full_path = fullfile(data_dir, fname);
    if ~isfile(full_path), continue; end
    files_found = files_found + 1;

    try
        D = load(full_path); vars = fieldnames(D);
        raw_res = []; raw_lat = []; raw_time = [];
        for v = 1:length(vars)
            S = D.(vars{v}); if ~isstruct(S), continue; end
            t_vec=[]; if isfield(S,'Time'),t_vec=S.Time; elseif isfield(S,'Time1'),t_vec=S.Time1; end
            res_vec=[]; if isfield(S,'dF'),res_vec=S.dF(:); elseif isfield(S,'B_res'),res_vec=S.B_res(:); elseif isfield(S,'d_grad'),res_vec=S.d_grad(:); end
            lat_vec=[]; if isfield(S,'QD_Lat'),lat_vec=S.QD_Lat(:); end

            if numel(res_vec)>0 && numel(t_vec)>0
                len = min([numel(res_vec), numel(t_vec)*3, numel(lat_vec)*3]);
                raw_res=[raw_res; res_vec(1:min(len,numel(res_vec)))];
                if numel(lat_vec)>0, ratio=ceil(numel(res_vec)/numel(lat_vec)); l_exp=repmat(lat_vec,ratio,1); raw_lat=[raw_lat; l_exp(1:min(len,numel(l_exp)))]; end
                if numel(t_vec)>0, ratio=ceil(numel(res_vec)/numel(t_vec)); t_exp=repmat(t_vec,ratio,1); raw_time=[raw_time; t_exp(1:min(len,numel(t_exp)))]; end
            end
        end
        if isempty(raw_res), continue; end

        % 1. Timeline (保持不变)
        base_date = datetime(2000,1,1); t_dates = base_date + days(raw_time);
        valid_t = (t_dates > datetime(1998,1,1)) & (t_dates < datetime(2030,1,1));
        if sum(valid_t) > 0
            TimelineData(end+1) = struct('Sat', sat_name, 'Type', type_name, 'Start', min(t_dates(valid_t)), 'End', max(t_dates(valid_t)), 'Count', length(raw_res));
        end

        % 2. Lat Profile (保持不变)
        edges = -90:2.5:90; [~, bins] = histc(raw_lat, edges);
        sum_sq = zeros(length(edges)-1, 1); count = zeros(length(edges)-1, 1);
        for b = 1:length(edges)-1
            idx = (bins == b); if any(idx), sum_sq(b) = sum(raw_res(idx).^2, 'omitnan'); count(b) = sum(idx); end
        end
        found = false;
        for k = 1:length(LatProfileData)
            if strcmp(LatProfileData(k).Sat, sat_name)
                LatProfileData(k).SumSq = LatProfileData(k).SumSq + sum_sq;
                LatProfileData(k).Count = LatProfileData(k).Count + count;
                found = true; break;
            end
        end
        if ~found, LatProfileData(end+1) = struct('Sat', sat_name, 'Lat', edges(1:end-1)+1.25, 'SumSq', sum_sq, 'Count', count); end

        % 3. [修改] 分类存储直方图数据
        sample_size = 50000;
        if length(raw_res) > sample_size, sample_res = randsample(raw_res, sample_size); else, sample_res = raw_res; end

        found_stat = false;
        for k = 1:length(HistDataPool)
            if strcmp(HistDataPool(k).Sat, sat_name)
                % 根据类型分别存储
                if strcmp(type_name, 'Abs')
                    HistDataPool(k).AbsValues = [HistDataPool(k).AbsValues; sample_res];
                else % Grad or Cross
                    HistDataPool(k).GradValues = [HistDataPool(k).GradValues; sample_res];
                end
                found_stat = true; break;
            end
        end
        if ~found_stat
            new_entry = struct('Sat', sat_name, 'AbsValues', [], 'GradValues', []);
            if strcmp(type_name, 'Abs')
                new_entry.AbsValues = sample_res;
            else
                new_entry.GradValues = sample_res;
            end
            HistDataPool(end+1) = new_entry;
        end

    catch
    end
end
if files_found == 0, error('未找到数据文件'); end

% --- 3. 绘图 (Layout) ---
fig = figure('Name', 'Thesis Dashboard V13 Split', 'Color', 'w', 'Units','centimeters','Position', [2, 2, 16.5, 15]);

% [修改] 使用 3行2列 布局，前两行跨列
t = tiledlayout(3, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

% ================= Panel A: Timeline (Row 1, Span 2 Cols) =================
ax1 = nexttile(1, [1, 2]); hold(ax1, 'on');
plot(ax1, datetime(2000,1,1), 0, 'LineStyle', 'none');
sat_total_counts = containers.Map();
for i=1:length(sat_list), sat_total_counts(sat_list{i}) = 0; end

for i = 1:length(sat_list)
    s_name = sat_list{i}; y_pos = i; col = sat_map(s_name);
    if mod(i,2)==1, fill(ax1, [datetime(1995,1,1), datetime(2030,1,1), datetime(2030,1,1), datetime(1995,1,1)], ...
            [i-0.5, i-0.5, i+0.5, i+0.5], [0.98 0.98 0.99], 'EdgeColor', 'none'); end
    for j = 1:length(TimelineData)
        if strcmp(TimelineData(j).Sat, s_name)
            lw = 7; alpha_val = 0.9; if contains(TimelineData(j).Type, 'Grad'), lw=4; alpha_val=0.7; end
            plot([TimelineData(j).Start, TimelineData(j).End], [y_pos, y_pos], '-', 'Color', [col, alpha_val], 'LineWidth', lw);
            sat_total_counts(s_name) = sat_total_counts(s_name) + TimelineData(j).Count;
        end
    end
    count_str = sprintf('N\\approx%.1fM', sat_total_counts(s_name)/1e6);
    if sat_total_counts(s_name) < 1e5, count_str = sprintf('N\\approx%.0fk', sat_total_counts(s_name)/1e3); end
    text(ax1, datetime(2026,1,1), i, count_str, 'FontSize', 9, 'Color', [0.3 0.3 0.3], 'VerticalAlignment', 'middle');
end
set(ax1, 'YTick', 1:length(sat_list), 'YTickLabel', sat_list, 'TickDir', 'out',  'FontSize', 10, 'XGrid', 'on', 'YGrid', 'off');
xlim(ax1, [datetime(1998,1,1), datetime(2028,1,1)]);
xtickformat('yyyy')
title(ax1, 'a) Temporal Availability & Data Volume', 'FontWeight', 'bold', 'Units', 'normalized', 'Position', [0.005, 1.02], 'HorizontalAlignment', 'left');

% ================= Panel B: RMS vs Latitude (Row 2, Span 2 Cols) =================
ax2 = nexttile(3, [1, 2]); hold(ax2, 'on');
max_rms_all = 0;
for k = 1:length(LatProfileData)
    if isempty(LatProfileData(k).Lat), continue; end
    rms_vals = sqrt(LatProfileData(k).SumSq ./ LatProfileData(k).Count);
    max_rms_all = max(max_rms_all, max(rms_vals));
end
y_upper_limit = max(ceil(max_rms_all), 12);

% 背景带
for lat_i = 1:20
    lat_start = -10 + (lat_i-1); lat_center = lat_start + 0.5;
    alpha_val = max(0.15, 0.45 * (1 - abs(lat_center)/10));
    fill(ax2, [lat_start, lat_start+1, lat_start+1, lat_start], [0, 0, y_upper_limit, y_upper_limit], [1, 0.85, 0.4], 'EdgeColor', 'none', 'FaceAlpha', alpha_val, 'HandleVisibility', 'off');
end
for lat_i = 1:20
    lat_start = -75 + (lat_i-1); lat_center = lat_start + 0.5;
    alpha_val = max(0.05, 0.35 * (1 - abs(lat_center + 65)/10));
    fill(ax2, [lat_start, lat_start+1, lat_start+1, lat_start], [0, 0, y_upper_limit, y_upper_limit], [0.6, 0.5, 0.7], 'EdgeColor', 'none', 'FaceAlpha', alpha_val, 'HandleVisibility', 'off');
end
for lat_i = 1:20
    lat_start = 55 + (lat_i-1); lat_center = lat_start + 0.5;
    alpha_val = max(0.05, 0.35 * (1 - abs(lat_center - 65)/10));
    fill(ax2, [lat_start, lat_start+1, lat_start+1, lat_start], [0, 0, y_upper_limit, y_upper_limit], [0.6, 0.5, 0.7], 'EdgeColor', 'none', 'FaceAlpha', alpha_val, 'HandleVisibility', 'off');
end
text(ax2, 0, y_upper_limit*0.65, 'EEJ', 'Color', [0.6 0.4 0.1], 'FontSize', 9, 'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'BackgroundColor', [1 1 1 0.6], 'EdgeColor', 'none', 'Margin', 2);
text(ax2, -65, y_upper_limit*0.65, 'Auroral', 'Color', [0.4 0.3 0.5], 'FontSize', 9, 'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'BackgroundColor', [1 1 1 0.6], 'EdgeColor', 'none', 'Margin', 2);
text(ax2, 65, y_upper_limit*0.65, 'Auroral', 'Color', [0.4 0.3 0.5], 'FontSize', 9, 'HorizontalAlignment', 'center',  'FontWeight', 'bold', 'BackgroundColor', [1 1 1 0.6], 'EdgeColor', 'none', 'Margin', 2);

legend_handles = [];
for i = 1:length(sat_list)
    s_name = sat_list{i}; found_idx = -1;
    for k = 1:length(LatProfileData), if strcmp(LatProfileData(k).Sat, s_name), found_idx = k; break; end, end
    if found_idx > 0
        lat_x = LatProfileData(found_idx).Lat(:)'; rms_y = sqrt(LatProfileData(found_idx).SumSq ./ LatProfileData(found_idx).Count); rms_y=rms_y(:)';
        rms_y_smooth = smoothdata(rms_y, 2, 'gaussian', 7);
        fill(ax2, [lat_x, fliplr(lat_x)], [smoothdata(rms_y*1.05,2,'gaussian',7), fliplr(smoothdata(rms_y*0.95,2,'gaussian',7))], sat_map(s_name), 'EdgeColor', 'none', 'FaceAlpha', 0.15, 'HandleVisibility', 'off');
        ln = plot(ax2, lat_x, rms_y_smooth, 'Color', sat_map(s_name), 'LineWidth', 2.2, 'DisplayName', s_name);
        legend_handles = [legend_handles, ln];
        mk_idx = 4:8:length(lat_x); plot(ax2, lat_x(mk_idx), rms_y_smooth(mk_idx), marker_map(s_name), 'Color', sat_map(s_name), 'MarkerFaceColor', 'w', 'MarkerSize', 5, 'LineWidth', 1.5, 'HandleVisibility', 'off');
    end
end
set(ax2, 'TickDir', 'out',  'FontSize', 10, 'Layer', 'top', 'Box', 'on');
ylabel(ax2, 'Residual (nT)', 'FontWeight', 'bold'); xlabel(ax2, 'QD Lat (°)', 'FontWeight', 'bold');
xlim(ax2, [-90 90]); ylim(ax2, [0, y_upper_limit]); grid(ax2, 'on'); ax2.GridAlpha = 0.25; ax2.GridLineStyle = ':';
title(ax2, 'b) Latitudinal Variation of Residuals', 'FontWeight', 'bold', 'Units', 'normalized', 'Position', [0.005, 1.02], 'HorizontalAlignment', 'left');
if ~isempty(legend_handles), legend(ax2, legend_handles, 'Location', 'north', 'Orientation', 'horizontal', 'Box', 'off', 'NumColumns', 4, 'FontSize', 9); end

% ================= Panel C: Split Ridge Plot (分栏脊线图) =================

% --- 通用设置 ---
num_sats = length(sat_list);
ridge_spacing = 1.0;          % 脊线之间的垂直间距 (改为1更直观)
scale_height = 0.85;          % 归一化后的最大高度 (占间距的85%，留空隙)
y_ticks_pos = [];             % 用于存储Y轴刻度位置
y_tick_labels = {};           % 用于存储卫星名称

% --- Left Subplot: Absolute Data Ridge Plot ---
ax3_left = nexttile(5); hold(ax3_left, 'on');

has_abs_data = false;

% 绘制绝对数据脊线
for i = 1:num_sats
    s_name = sat_list{i}; 
    % 获取颜色 (兼容你的 map 或 lines)
    if exist('sat_map', 'var') && isKey(sat_map, s_name)
        col = sat_map(s_name);
    else
        cols = lines(num_sats); col = cols(i,:);
    end
    
    % 获取数据
    vals = [];
    for j = 1:length(HistDataPool)
        if strcmp(HistDataPool(j).Sat, s_name)
            vals = HistDataPool(j).AbsValues; break;
        end
    end
    if isempty(vals), continue; end
    
    % 1. 数据清洗
    vals = vals(abs(vals) < 50); % 即使过滤了，如果方差大PDF依然会很低
    if isempty(vals), continue; end
    
    % 2. 计算直方图 (使用较细的粒度)
    bin_edges_abs = -10:0.1:10; 
    [counts, edges] = histcounts(vals, bin_edges_abs); % 这里直接用counts即可
    centers = (edges(1:end-1) + edges(2:end)) / 2;
    
    % 3. 平滑处理 (让锯齿状的直方图变平滑)
    pdf_smooth = smoothdata(counts, 'gaussian', 10); 
    
    % 4. 【核心修改】高度归一化
    % 无论数据分布多宽，强制将峰值拉伸到 scale_height
    if max(pdf_smooth) > 0
        pdf_norm = (pdf_smooth / max(pdf_smooth)) * scale_height;
    else
        pdf_norm = pdf_smooth;
    end
    
    % 5. 计算垂直偏移
    y_offset = (num_sats - i) * ridge_spacing;
    
    % 记录Y轴标签信息
    y_ticks_pos(end+1) = y_offset;
    y_tick_labels{end+1} = s_name;
    
    % 6. 绘制填充
    fill_x = [centers, fliplr(centers)];
    % 底部基线是 y_offset，顶部曲线是 pdf_norm + y_offset
    fill_y = [pdf_norm + y_offset, repmat(y_offset, 1, length(pdf_norm))];
    
    % 绘制
    fill(ax3_left, fill_x, fill_y, col, 'FaceAlpha', 0.5, 'EdgeColor', 'w', 'LineWidth', 0.5);
    % 加一条加粗的边缘线增强轮廓
    plot(ax3_left, centers, pdf_norm + y_offset, 'Color', col, 'LineWidth', 1.2);
    % 加一条底线
    yline(ax3_left, y_offset, 'Color', [0.5 0.5 0.5], 'LineWidth', 0.5, 'Alpha', 0.3);
    
    has_abs_data = true;
end

% 设置左侧图属性
if has_abs_data
    set(ax3_left, 'FontSize', 10, 'TickDir', 'out', 'Box', 'on');
    
    % 限制X轴范围
    xlim(ax3_left, [-8, 8]); 
    ylim(ax3_left, [-0.5, num_sats * ridge_spacing + 0.5]); % 稍微留点余量
    
    % --- 【修复报错的关键步骤】 ---
    % MATLAB要求YTick必须从小到大排序
    [y_ticks_sorted, sort_idx] = sort(y_ticks_pos);       % 对位置进行升序排序
    y_labels_sorted = y_tick_labels(sort_idx);            % 让标签也同步排序
    
    % 应用排序后的刻度和标签
    set(ax3_left, 'YTick', y_ticks_sorted, 'YTickLabel', y_labels_sorted);
    % ---------------------------
    
    % 添加竖直参考线
    xline(ax3_left, 0, 'k--', 'LineWidth', 0.8, 'Alpha', 0.4);
    
    % ylabel(ax3_left, 'Satellite', 'FontWeight', 'bold');
    xlabel(ax3_left, 'Absolute Residual (nT)', 'FontWeight', 'bold');
    title(ax3_left, 'c-1) Original Data', 'FontWeight', 'bold', ...
        'Units', 'normalized', 'Position', [0.02, 1.02], 'HorizontalAlignment', 'left');
    
    grid(ax3_left, 'on'); 
    ax3_left.YGrid = 'off'; % 仅显示垂直网格
end

% --- Right Subplot: Gradient Data Ridge Plot ---
ax3_right = nexttile(6); hold(ax3_right, 'on');

% 绘制梯度数据脊线
for i = 1:num_sats
    s_name = sat_list{i}; 
    if exist('sat_map', 'var') && isKey(sat_map, s_name)
        col = sat_map(s_name);
    else
        cols = lines(num_sats); col = cols(i,:);
    end
    
    vals = [];
    for j = 1:length(HistDataPool)
        if strcmp(HistDataPool(j).Sat, s_name)
            vals = HistDataPool(j).GradValues; break;
        end
    end
    if isempty(vals), continue; end
    
    vals = vals(abs(vals) < 30);
    if isempty(vals), continue; end
    
    % 直方图与平滑
    bin_edges_grad = -5:0.05:5;
    [counts, edges] = histcounts(vals, bin_edges_grad);
    centers = (edges(1:end-1) + edges(2:end)) / 2;
    pdf_smooth = smoothdata(counts, 'gaussian', 10);
    
    % 【核心修改】高度归一化
    if max(pdf_smooth) > 0
        pdf_norm = (pdf_smooth / max(pdf_smooth)) * scale_height;
    else
        pdf_norm = pdf_smooth;
    end
    
    y_offset = (num_sats - i) * ridge_spacing;
    
    % 绘制
    fill_x = [centers, fliplr(centers)];
    fill_y = [pdf_norm + y_offset, repmat(y_offset, 1, length(pdf_norm))];
    
    fill(ax3_right, fill_x, fill_y, col, 'FaceAlpha', 0.5, 'EdgeColor', 'w', 'LineWidth', 0.5);
    plot(ax3_right, centers, pdf_norm + y_offset, 'Color', col, 'LineWidth', 1.2);
    yline(ax3_right, y_offset, 'Color', [0.5 0.5 0.5], 'LineWidth', 0.5, 'Alpha', 0.3);
end

% 设置右侧图属性
set(ax3_right, 'FontSize', 10, 'TickDir', 'out', 'Box', 'on');
xlim(ax3_right, [-3, 3]); 
ylim(ax3_right, [-0.5, num_sats * ridge_spacing + 0.5]);

% 使用刚才在左侧排序好的刻度，但标签设为空
if exist('y_ticks_sorted', 'var')
    set(ax3_right, 'YTick', y_ticks_sorted, 'YTickLabel', []);
else
    % 如果左侧没数据，防止报错
    set(ax3_right, 'YTick', [], 'YTickLabel', []);
end

xline(ax3_right, 0, 'k--', 'LineWidth', 0.8, 'Alpha', 0.4);

xlabel(ax3_right, 'Gradient Residual (nT)', 'FontWeight', 'bold');
title(ax3_right, 'c-2) Gradient Data', 'FontWeight', 'bold', ...
    'Units', 'normalized', 'Position', [0.02, 1.02], 'HorizontalAlignment', 'left');

grid(ax3_right, 'on'); ax3_right.YGrid = 'off';

% 确保Y轴对其
linkaxes([ax3_left, ax3_right], 'y');

exportgraphics(fig, '时间演化.pdf', 'Resolution', 600);