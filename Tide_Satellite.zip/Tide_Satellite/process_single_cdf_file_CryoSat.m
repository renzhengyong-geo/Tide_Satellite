function processed_data = process_single_cdf_file_CryoSat(file_info, curr_folder, ~, data_step)
% process_single_cdf_file_CryoSat (鲁棒增强版)
% 自动检测 B_NEC vs B_NEC1，自动检测 F

processed_data = [];
if contains(file_info.name, 'empty', 'IgnoreCase', true), return; end

full_path = fullfile(curr_folder, file_info.name);
orig_warn_state = warning; 

try
    warning('off', 'all');
    
    % 1. 获取文件信息，检查存在哪些变量
    info = cdfinfo(full_path);
    var_list = info.Variables(:,1);
    
    % 2. 动态确定磁场变量名
    if any(strcmp(var_list, 'B_NEC'))
        name_B = 'B_NEC';
    elseif any(strcmp(var_list, 'B_NEC1'))
        name_B = 'B_NEC1';
    elseif any(strcmp(var_list, 'M1_B_NEC'))
        name_B = 'M1_B_NEC';
    else
        % 实在找不到，报错并跳过
        fprintf('Skip %s: No valid B_NEC variable found.\n', file_info.name);
        return;
    end
    
    % 3. 动态确定标量 F
    if any(strcmp(var_list, 'F'))
        name_F = 'F';
        calc_F_manually = false;
    else
        name_F = name_B; % 占位，后面只读 B，手动算 F
        calc_F_manually = true;
    end
    
    % 4. 动态确定姿态 q_error
    if any(strcmp(var_list, 'q_error'))
        name_Q = 'q_error';
    else
        name_Q = ''; % 如果没有，暂时设为空，后续全置为 Good 或尝试其他
    end
    
    % 5. 构建读取列表
    target_vars = {'Timestamp', 'Latitude', 'Longitude', 'Radius', name_B};
    if ~calc_F_manually, target_vars{end+1} = name_F; end
    if ~isempty(name_Q), target_vars{end+1} = name_Q; end
    
    % 6. 读取数据
    cdf_data = cdfread(full_path, 'Variables', target_vars, ...
        'CombineRecords', true, 'ConvertEpochToDatenum', true);
    
    if isempty(cdf_data), warning(orig_warn_state); return; end
    
    % 7. 分配变量 (根据 target_vars 的顺序)
    raw_t   = double(cdf_data{1});
    raw_lat = double(cdf_data{2});
    raw_lon = double(cdf_data{3});
    raw_r   = double(cdf_data{4});
    raw_B   = double(cdf_data{5});
    
    idx_curr = 6;
    if ~calc_F_manually
        raw_F = double(cdf_data{idx_curr});
        idx_curr = idx_curr + 1;
    else
        raw_F = sqrt(sum(raw_B.^2, 2)); % 手动计算
    end
    
    if ~isempty(name_Q)
        raw_q_err = double(cdf_data{idx_curr});
    else
        raw_q_err = zeros(size(raw_F)); % 如果没有 q_error，默认设为0 (Good)
    end
    
    % 维度修正
    if size(raw_B, 1) == 3 && size(raw_B, 2) ~= 3, raw_B = raw_B'; end
    if size(raw_F, 2) > 1, raw_F = raw_F(:); end
    
    % 单位修正 (m -> km)
    if mean(raw_r, 'omitnan') > 1000000, raw_r = raw_r / 1000; end
    
    % ---------------- 质量控制 ----------------
    ATTITUDE_THRESHOLD = 40; 
    mask_q_good = (raw_q_err < ATTITUDE_THRESHOLD);
    
    mask_geo_valid = (raw_r > 6500) & (raw_r < 7500) & (abs(raw_lat) <= 90);
    mask_val_valid = (raw_F > 10000) & (raw_F < 75000) & ~isnan(raw_F);
    
    valid_mask = mask_q_good & mask_geo_valid & mask_val_valid & ...
                 ~isnan(raw_lat) & ~isnan(raw_lon) & ~isnan(raw_t);
             
    if sum(valid_mask) < 10, warning(orig_warn_state); return; end
    
    t_clean = raw_t(valid_mask);
    lat_clean = raw_lat(valid_mask);
    lon_clean = raw_lon(valid_mask);
    r_clean = raw_r(valid_mask);
    F_clean = raw_F(valid_mask);
    B_clean = raw_B(valid_mask, :);
    
    % ---------------- 分箱平均 (Binning) ----------------
    dt_grid_days = data_step / 86400; 
    t_start = floor(min(t_clean) * 86400 / data_step) * data_step / 86400;
    t_end   = ceil(max(t_clean) * 86400 / data_step) * data_step / 86400;
    edges = t_start : dt_grid_days : t_end;
    
    if length(edges) < 2, warning(orig_warn_state); return; end
    
    [Y, ~] = discretize(t_clean, edges);
    bin_valid = ~isnan(Y);
    Y = Y(bin_valid);
    counts = accumarray(Y, 1);
    has_enough_data = (counts >= 1);
    
    calc_mean = @(data) accumarray(Y, data) ./ max(1, counts);
    
    val_lat = calc_mean(lat_clean(bin_valid));
    val_r   = calc_mean(r_clean(bin_valid));
    val_F   = calc_mean(F_clean(bin_valid));
    val_B   = [calc_mean(B_clean(bin_valid, 1)), ...
               calc_mean(B_clean(bin_valid, 2)), ...
               calc_mean(B_clean(bin_valid, 3))];
           
    lon_rad = deg2rad(lon_clean(bin_valid));
    val_lon = rad2deg(atan2(accumarray(Y, sin(lon_rad)), ...
                            accumarray(Y, cos(lon_rad))));
    val_std_F = accumarray(Y, F_clean(bin_valid), [], @std);
    val_t_num = (edges(1:end-1) + edges(2:end))' / 2;
    
    final_mask = false(size(counts));
    final_mask(1:length(has_enough_data)) = has_enough_data;
    
    if any(final_mask)
        processed_data = [val_lat(final_mask), val_lon(final_mask), val_r(final_mask), ...
                          val_B(final_mask, :), val_t_num(final_mask), ...
                          val_F(final_mask), val_std_F(final_mask)];
    end
    
    warning(orig_warn_state);
    
catch ME
    fprintf('Error reading %s: %s\n', file_info.name, ME.message);
    warning(orig_warn_state);
    processed_data = [];
end
end