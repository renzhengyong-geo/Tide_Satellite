import requests
import os
import re
import argparse
from datetime import datetime, timedelta
import logging
import shutil
from tqdm import tqdm
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed

# 配置日志记录
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('swarm_download.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('SwarmDownloader')

class SwarmDownloader:
    def __init__(self):
        # ESA Swarm数据中心URL
        self.base_url = "https://swarm-diss.eo.esa.int/"
        self.main_save_path = "E:\\A_graduate\\code_and_program\\Satellite_data_processing\\Satellite_Data\\Swarm\\2025latest"
        
        # 卫星列表
        self.satellites = ["A", "B", "C"]
        
        # 创建主存储路径和各卫星子文件夹
        os.makedirs(self.main_save_path, exist_ok=True)
        self.sat_save_paths = {}
        for sat in self.satellites:
            sat_path = os.path.join(self.main_save_path, sat)
            os.makedirs(sat_path, exist_ok=True)
            self.sat_save_paths[sat] = sat_path
        
        # 数据文件正则表达式
        # 匹配格式：SW_OPER_MAGA_LR_1B_YYYYMMDDTHHMMSS_YYYYMMDDTHHMMSS_XXXX.CDF.ZIP
        self.file_pattern = re.compile(r"SW_OPER_MAG([ABC])_LR_1B_(\d{8}T\d{6})_(\d{8}T\d{6})_\d{4}\.CDF\.ZIP")
        
        # 添加用户代理，模拟浏览器访问
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
    
    def generate_file_list(self, satellite, start_date, end_date):
        """
        根据日期范围和卫星标识生成预期的文件名列表
        注意：这种方法基于文件命名规则，适用于已知文件命名模式的情况
        """
        files = []
        
        # 计算日期范围
        current_date = start_date.date()
        end_date = end_date.date()
        
        # 只尝试最可能的URL路径格式 - 基于ESA Swarm数据中心的实际结构
        base_path = "swarm/Level1b/Entire_mission_data/MAGx_LR/Sat_{satellite}/"
        
        while current_date <= end_date:
            # 为每一天生成预期的文件名
            date_str = current_date.strftime("%Y%m%d")
            
            # 构建日期前缀，用于检查该日期的文件是否已存在
            date_prefix = f"SW_OPER_MAG{satellite}_LR_1B_{date_str}"
            
            # 检查该日期的文件是否已存在任何版本
            date_file_exists = False
            for existing_file in os.listdir(self.sat_save_paths[satellite]):
                if existing_file.startswith(date_prefix):
                    date_file_exists = True
                    logger.info(f"File already exists for {date_str}: {existing_file}")
                    break
            
            if date_file_exists:
                # 如果该日期的文件已存在，跳过当前日期
                current_date += timedelta(days=1)
                continue
            
            # 只尝试下载0701版本，如果下载失败再尝试0702版本
            # 但在生成文件列表时，我们只需要添加其中一个版本
            # 这里选择先尝试0701版本
            version = "0701"
            filename = f"SW_OPER_MAG{satellite}_LR_1B_{date_str}T000000_{date_str}T235959_{version}.CDF.ZIP"
            
            # 构建下载URL
            url = f"{self.base_url}{base_path.format(satellite=satellite)}{filename}"
            
            # 解析文件名获取时间信息
            file_match = self.file_pattern.match(filename)
            if file_match:
                start_time = datetime.strptime(file_match.group(2), "%Y%m%dT%H%M%S")
                end_time = datetime.strptime(file_match.group(3), "%Y%m%dT%H%M%S")
                files.append((satellite, filename, url, start_time, end_time))
            
            # 移动到下一天
            current_date += timedelta(days=1)
        
        return files
    
    def download_file(self, url, save_path):
        """
        下载文件，支持断点续传和进度显示
        """
        try:
            # 初始请求，获取文件大小
            response = requests.get(url, headers=self.headers, stream=True, timeout=60)
            response.raise_for_status()
            
            file_size = int(response.headers.get('content-length', 0))
            
            # 检查文件是否已存在且大小相同
            if os.path.exists(save_path):
                existing_size = os.path.getsize(save_path)
                if existing_size == file_size:
                    logger.info(f"File already exists and is complete: {save_path}")
                    return True
                else:
                    logger.info(f"Resuming download for: {save_path}")
                    # 添加Range头和User-Agent头
                    headers = self.headers.copy()
                    headers['Range'] = f'bytes={existing_size}-'
                    response = requests.get(url, headers=headers, stream=True, timeout=60)
            
            with open(save_path, 'ab') as f, tqdm(
                desc=os.path.basename(save_path),
                total=file_size,
                unit='B',
                unit_scale=True,
                unit_divisor=1024,
            ) as bar:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        bar.update(len(chunk))
            
            # 文件完整性校验
            if os.path.getsize(save_path) != file_size:
                logger.error(f"File download incomplete: {save_path}")
                os.remove(save_path)
                return False
            
            logger.info(f"Successfully downloaded: {save_path}")
            return True
        except requests.exceptions.HTTPError as e:
            logger.error(f"HTTP Error {e.response.status_code} for {url}: {e.response.reason}")
            return False
        except requests.exceptions.RequestException as e:
            logger.error(f"Network error for {url}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error during download of {url}: {e}")
            return False
    
    def download_single_date(self, satellite, date_str, base_path):
        """
        下载指定卫星和日期的数据文件
        用于并行执行
        """
        # 构建日期前缀，用于检查该日期的文件是否已存在
        date_prefix = f"SW_OPER_MAG{satellite}_LR_1B_{date_str}"
        
        # 检查该日期的文件是否已存在任何版本
        date_file_exists = False
        for existing_file in os.listdir(self.sat_save_paths[satellite]):
            if existing_file.startswith(date_prefix):
                date_file_exists = True
                logger.info(f"File already exists for {date_str}: {existing_file}")
                return True
        
        # 尝试下载，先尝试0701版本，如果失败再尝试0702版本
        downloaded = False
        for version in ["0701", "0702"]:
            if downloaded:
                break
            
            # 生成文件名
            filename = f"SW_OPER_MAG{satellite}_LR_1B_{date_str}T000000_{date_str}T235959_{version}.CDF.ZIP"
            
            # 构建下载URL
            url = f"{self.base_url}{base_path.format(satellite=satellite)}{filename}"
            
            # 构建保存路径
            save_path = os.path.join(self.sat_save_paths[satellite], filename)
            
            # 下载文件
            logger.info(f"Attempting to download: {filename}")
            if self.download_file(url, save_path):
                downloaded = True
            else:
                logger.info(f"Failed to download {version} version, trying next version if available")
        
        if not downloaded:
            logger.error(f"Failed to download any version for {date_str} on satellite {satellite}")
            return False
        
        return True
    
    def download_data(self, start_date, end_date):
        """
        下载指定时间范围内的数据
        """
        logger.info(f"Starting download for period: {start_date} to {end_date}")
        
        # 转换为datetime对象
        if isinstance(start_date, str):
            start_date = datetime.strptime(start_date, "%Y-%m-%d")
        if isinstance(end_date, str):
            end_date = datetime.strptime(end_date, "%Y-%m-%d")
        
        # 只尝试最可能的URL路径格式
        base_path = "swarm/Level1b/Entire_mission_data/MAGx_LR/Sat_{satellite}/"
        
        # 收集所有需要下载的任务
        download_tasks = []
        
        # 保存原始的datetime对象，避免在循环中修改
        original_start_date = start_date
        original_end_date = end_date
        
        for satellite in self.satellites:
            logger.info(f"Preparing tasks for satellite {satellite}")
            
            # 计算日期范围 - 每次循环都使用原始的datetime对象
            current_date = original_start_date.date()
            end_date_obj = original_end_date.date()
            
            while current_date <= end_date_obj:
                date_str = current_date.strftime("%Y%m%d")
                download_tasks.append((satellite, date_str, base_path))
                
                # 移动到下一天
                current_date += timedelta(days=1)
        
        logger.info(f"Generated {len(download_tasks)} download tasks")
        
        # 使用线程池并行下载
        success_count = 0
        fail_count = 0
        
        # 设置线程池大小，根据网络带宽和系统资源调整
        max_workers = 5
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # 提交所有下载任务
            future_to_task = {
                executor.submit(self.download_single_date, satellite, date_str, base_path): 
                (satellite, date_str) 
                for satellite, date_str, base_path in download_tasks
            }
            
            # 处理完成的任务
            for future in as_completed(future_to_task):
                satellite, date_str = future_to_task[future]
                try:
                    result = future.result()
                    if result:
                        success_count += 1
                    else:
                        fail_count += 1
                except Exception as e:
                    logger.error(f"Unexpected error during download of {date_str} for satellite {satellite}: {e}")
                    fail_count += 1
        
        logger.info(f"Download completed. Success: {success_count}, Failed: {fail_count}")
        return success_count, fail_count

# 注意：由于swarm-diss网站的特殊性，上述代码可能无法直接使用
# 实际使用时需要根据网站的真实API或文件列表获取方式进行调整
# 以下是一个简化的实现，用于演示基本功能

# 替代方案：使用ESA的Swarm数据访问API
def get_swarm_files_from_api(satellite, start_date, end_date):
    """
    使用ESA API获取Swarm数据文件列表
    """
    # 这里需要替换为真实的ESA API调用
    # 例如：https://earth.esa.int/eogateway/api/swarm/files
    pass

def main():
    """
    主函数
    """
    parser = argparse.ArgumentParser(description='Swarm Satellite Magnetic Field Data Downloader')
    parser.add_argument('--start-date', type=str, default='2025-03-01', 
                        help='Start date for data download (YYYY-MM-DD), default: 2025-03-01')
    parser.add_argument('--end-date', type=str, default=datetime.now().strftime('%Y-%m-%d'),
                        help='End date for data download (YYYY-MM-DD), default: today')
    args = parser.parse_args()
    
    downloader = SwarmDownloader()
    
    print("Swarm Satellite Magnetic Field Data Downloader")
    print("=" * 50)
    print(f"Download period: {args.start_date} to {args.end_date}")
    print("=" * 50)
    
    try:
        # 验证日期格式
        start_date = datetime.strptime(args.start_date, "%Y-%m-%d")
        end_date = datetime.strptime(args.end_date, "%Y-%m-%d")
        
        if start_date > end_date:
            print("Error: Start date must be earlier than end date")
            return
        
        # 开始下载
        downloader.download_data(start_date, end_date)
        
    except ValueError as e:
        print(f"Error: Invalid date format. Please use YYYY-MM-DD. {e}")
        logger.error(f"Invalid date input: {e}")
    except KeyboardInterrupt:
        print("\nDownload interrupted by user")
        logger.info("Download interrupted by user")
    except Exception as e:
        print(f"Unexpected error: {e}")
        logger.error(f"Unexpected error: {e}")

if __name__ == "__main__":
    main()