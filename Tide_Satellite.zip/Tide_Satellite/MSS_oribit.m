%% ========================================================================
%  图 1：卫星原始轨道分布图 (使用原始 CDF 数据读取)
% =========================================================================
disp('=== 正在读取少量原始 CDF 数据绘制连续轨道... ===');

fig1 = figure('Color', 'w', 'Position',[100, 100, 1000, 500], 'Name', 'Raw Orbit Distribution');

% 初始化 m_map Robinson 投影 (-180 ~ 180)
m_proj('Robinson', 'lon',[-179.5 179.5]);
hold on;

% 1. 提取原始轨道数据 (读取前 5 个文件，约等于 5 天的数据)
dir_swarm = 'E:\A_graduate\code_and_program\Satellite_data_processing\Satellite_Data\Swarm\2023A'; 
dir_mss   = 'E:\A_graduate\code_and_program\Satellite_data_processing\Satellite_Data\MSS_v07xx';   
[raw_lon_S, raw_lat_S] = get_raw_orbits_sample(dir_swarm, '*MAGA*.cdf', 5);[raw_lon_M, raw_lat_M] = get_raw_orbits_sample(dir_mss, 'MSS1A_OPER_VFM_L2_MAG_SCI-LR_*.cdf', 5);

% 2. 绘制真实轨道
if ~isempty(raw_lon_S)
    m_plot(raw_lon_S, raw_lat_S, '.', 'Color', 'b', 'MarkerSize', 2);
else
    warning('未找到 Swarm 原始 CDF 数据，图1将无 Swarm 轨道。');
end

if ~isempty(raw_lon_M)
    m_plot(raw_lon_M, raw_lat_M, '.', 'Color', 'r', 'MarkerSize', 2);
else
    warning('未找到 MSS-1 原始 CDF 数据，图1将无 MSS 轨道。');
end

% 3. 绘制海岸线与网格美化
m_coast('linewidth', 0.8, 'color',[0.3 0.3 0.3]);
m_grid('tickdir', 'in', 'linestyle', 'none', 'xticklabels', [], 'yticklabels',[], 'fontsize', 10);

% 4. 标题与图例
title('Raw Orbit (Swarm-A vs MSS-1)', 'FontSize', 15, 'FontWeight', 'bold');
h_leg_S = plot(NaN, NaN, '.', 'Color', 'b', 'MarkerSize', 15);
h_leg_M = plot(NaN, NaN, '.', 'Color', 'r', 'MarkerSize', 15);
legend([h_leg_S, h_leg_M], {'Swarm-A', 'MSS-1'}, ... 
       'Location', 'best', 'FontSize', 12, 'Box', 'on');

exportgraphics(fig1, 'Raw_Orbit_Distribution.png', 'Resolution', 600);

function[lon_out, lat_out] = get_raw_orbits_sample(folder_path, file_pattern, num_files_to_read)
    lon_out =[]; lat_out =[];
    files = dir(fullfile(folder_path, '**', file_pattern));
    files = files(~[files.isdir]);
    
    if isempty(files), return; end
    
    n_read = min(num_files_to_read, length(files));
    for k = 1:n_read
        cdf_path = fullfile(files(k).folder, files(k).name);
        try
            dat = cdfread(cdf_path, 'Variables', {'Latitude', 'Longitude'}, 'CombineRecords', true);
            lat = dat{1}(:);
            lon = dat{2}(:);
            lon(lon > 180) = lon(lon > 180) - 360;
            lat_out =[lat_out; lat];
            lon_out = [lon_out; lon];
        catch
            continue; 
        end
    end
    
    if ~isempty(lat_out)
        lat_out = lat_out(1:10:end);
        lon_out = lon_out(1:10:end);
    end
end