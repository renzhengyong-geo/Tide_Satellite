% =========================================================================
% SAC-C 标量数据提取与预处理程序 (修正版: 1Hz -> 15s 降采样 + 梯度)
% 核心功能:
% 1. [单星处理] 读取 SAC-C CDF (1Hz)，执行 15s 降采样
% 2. [仅标量] 输出标量残差 (dF) 和 沿轨标量梯度 (dF_grad)
% 3. [全纬度] 覆盖全纬度
% 4. [筛选] 包含 Night-side, RC, Hp30, OMNI(By/Bz) 筛选
% =========================================================================
clc; clear; close all;
tic;

% 初始化并行池
max_workers = min(6, feature('numcores'));
p = gcp('nocreate');
if isempty(p), parpool('local', max_workers); end

%% ------------------- 1. 参数设定 -------------------
disp('1. 设定参数...');

data_folder = 'E:\A_graduate\code_and_program\Satellite_data_processing\Satellite_Data\SAC-C\';

% [功能] 随机读取控制
ENABLE_RANDOM_SAMPLING = false;   
RANDOM_SAMPLE_RATIO    = 0.01; 

% [重要修改] 恢复 15秒 降采样
% SAC-C 原始采样率为 1Hz，这里将其降采样为 15s 用于梯度计算
BINNING_WINDOW_SEC  = 15;  

ref_dn_2000 = datenum(2000, 1, 1, 0, 0, 0);
SAT_ID_VAL = 2; % SAC-C 编号

%% ------------------- 2. 加载辅助数据 -------------------
disp('2. 加载环境参数 (Em, Hp30, RC)...');
AUX_DATA_PATH = ''; % 请填写您的辅助数据路径

% 2.1 Em/Bz
file_em = fullfile(AUX_DATA_PATH, 'omni_min_em_bz_2h_avg.csv');
if ~isfile(file_em), error('文件缺失: %s', file_em); end
em_table = readtable(file_em);
em_table.datetime = datetime(em_table.year, 1, 1, 0, 0, 0) + ...
    days(em_table.day - 1) + hours(em_table.hour) + minutes(em_table.minute);
em_table.datetime.TimeZone = 'UTC'; 

% 2.2 Hp30
file_hp30 = fullfile(AUX_DATA_PATH, 'hp30_data_19970101_20250930.csv');
hp30_table = readtable(file_hp30);
if isdatetime(hp30_table.Timestamp_UTC)
    if isempty(hp30_table.Timestamp_UTC.TimeZone), hp30_table.Timestamp_UTC.TimeZone = 'UTC'; end
else
    hp30_table.Timestamp_UTC = datetime(hp30_table.Timestamp_UTC, 'TimeZone', 'UTC');
end

% 2.3 RC Index
file_rc = fullfile(AUX_DATA_PATH, 'RC_1997-2025_Sept25_v3_allLT.dat');
rc_data = readmatrix(file_rc, 'FileType', 'text', 'NumHeaderLines', 7);
[t_rc_sort, idx] = sort(rc_data(:,1));
drc_dt = gradient(rc_data(idx,2), t_rc_sort * 24.0);
rc_deriv = [t_rc_sort, drc_dt];

fprintf('   辅助数据加载完成。\n');

%% ------------------- 3. 统一流读取 (1Hz -> 15s) -------------------
disp('3. 数据读取：SAC-C (1Hz -> 15s 降采样)...');

files_struct = dir(fullfile(data_folder, '*.cdf'));
files_struct = files_struct(~contains({files_struct.name}, 'empty', 'IgnoreCase', true));
if isempty(files_struct), error('未找到有效的CDF文件'); end

[~, sort_idx] = sort({files_struct.name});
files_to_process = files_struct(sort_idx);

% --- 采样控制 ---
num_files = length(files_to_process);
if ENABLE_RANDOM_SAMPLING
    rng(42); 
    n_samp = max(1, round(num_files * RANDOM_SAMPLE_RATIO));
    rand_idx = sort(randperm(num_files, n_samp));
    files_to_process = files_to_process(rand_idx);
    fprintf('   [随机模式] 选中 %d 个文件\n', n_samp);
else
    fprintf('   [全量模式] 选中 %d 个文件\n', num_files);
end

sat_data_cell = cell(length(files_to_process), 1);
q = parallel.pool.DataQueue;
afterEach(q, @(~) fprintf('.')); 
fprintf('      进度: ');

parfor k = 1:length(files_to_process)
    % [修改] 传入 BINNING_WINDOW_SEC = 15，激活降采样逻辑
    raw = process_single_cdf_file_SAC_C(files_to_process(k), data_folder, ref_dn_2000, BINNING_WINDOW_SEC);
    
    if isempty(raw), continue; end
    
    % raw 格式: 1:Lat, 2:Lon, 3:Rad, 4-6:NaN, 7:Time, 8:F
    % 补全 SatID 列
    data_chunk = [raw, ones(size(raw,1),1) * SAT_ID_VAL];
    sat_data_cell{k} = data_chunk;
    send(q, k);
end
fprintf('\n');

global_data_container = vertcat(sat_data_cell{:});
clear sat_data_cell;

if isempty(global_data_container), error('没有读取到有效数据。'); end

% --- 变量提取 ---
[~, sort_t_idx] = sort(global_data_container(:,7)); 
all_data = global_data_container(sort_t_idx, :);

lat_obs = all_data(:,1); lon_obs = all_data(:,2); r_obs = all_data(:,3);
% bnec_obs 全为 NaN，忽略
t_dn = all_data(:,7); 
F_obs = all_data(:,8);
sat_id_obs = all_data(:,9);

t_mjd = t_dn - ref_dn_2000;
total_points = length(lat_obs);
fprintf('   SAC-C 15s 降采样数据准备完毕。总点数: %d\n', total_points);

%% ------------------- 4. 前置筛选 (Night, RC, Hp30, Em/Bz) -------------------
disp('4. 执行前置筛选...');

% 4.1 太阳位置
t_mjd2000 = t_dn - datenum(2000, 1, 1);
[sun_vec_GEI, ~] = sunGEI(t_mjd2000); 

theta_rad = deg2rad(90 - lat_obs);
phi_rad = deg2rad(lon_obs);
sat_x = sin(theta_rad) .* cos(phi_rad);
sat_y = sin(theta_rad) .* sin(phi_rad);
sat_z = cos(theta_rad);

jd = t_dn + 1721058.5;
T_century = (jd - 2451545.0) / 36525.0;
GST = 280.46061837 + 360.98564736629 * (jd - 2451545.0) + T_century.^2 * 0.000387933 - T_century.^3 / 38710000;
GST = mod(GST, 360) * pi / 180;
cos_gst = cos(GST); sin_gst = sin(GST);
sat_vec_GEI_x = sat_x .* cos_gst - sat_y .* sin_gst;
sat_vec_GEI_y = sat_x .* sin_gst + sat_y .* cos_gst;
sat_vec_GEI_z = sat_z;

cos_theta = sun_vec_GEI(:,1) .* sat_vec_GEI_x + sun_vec_GEI(:,2) .* sat_vec_GEI_y + sun_vec_GEI(:,3) .* sat_vec_GEI_z;
mask_night = rad2deg(acos(max(min(cos_theta, 1), -1))) > 100;

% 4.2 RC
if mean(rc_data(:,1)) > 40000, t_q = t_dn - 678942; else, t_q = t_dn - datenum(2000,1,1); end
[u_rc_t, idx_u] = unique(rc_data(:,1));
drc_val = interp1(u_rc_t, rc_deriv(idx_u, 2), t_q, 'linear', 'extrap');
mask_rc = abs(drc_val) <= 2;

% 4.3 Hp30
t_hp_dn = datenum(hp30_table.Timestamp_UTC);
mask_hp = interp1(t_hp_dn, hp30_table.Hp30_Value, t_dn, 'nearest', 'extrap') <= 2;

% 4.4 Delta-F Check (因无 Vector，此步通过)
mask_df = true(size(F_obs)); 

% 4.5 OMNI
t_omni_dn = datenum(em_table.datetime);
em_val = interp1(t_omni_dn, em_table.avg_em_2h, t_dn, 'nearest', 'extrap');
bz_val = interp1(t_omni_dn, em_table.avg_bz_2h, t_dn, 'nearest', 'extrap');
mask_em = (em_val <= 0.8) | isnan(em_val);
mask_bz = (bz_val > 0) | isnan(bz_val);

mask_pre_calc = mask_night & mask_rc & mask_hp & mask_df & mask_em & mask_bz;
count_pass = sum(mask_pre_calc);
fprintf('   前置筛选结果: %d / %d (%.1f%%)\n', count_pass, total_points, count_pass/total_points*100);

if count_pass == 0, error('无数据通过筛选。'); end

%% ------------------- 5. CHAOS 计算 (标量残差) -------------------
disp('5. 计算 CHAOS 背景场...');

idx_calc = find(mask_pre_calc);
t_sub = t_mjd(idx_calc); r_sub = r_obs(idx_calc);
lat_sub = lat_obs(idx_calc); lon_sub = lon_obs(idx_calc);

addpath('CHAOS-8.4_FWD\'); 
try load('CHAOS-8.4.mat'); catch, error('CHAOS mat missing'); end

N_core=20; pp_core=pp; pp_core.dim=N_core*(N_core+2); 
coefs_tmp=reshape(pp.coefs,[],pp.pieces,pp.order);
pp_core.coefs=reshape(coefs_tmp(1:N_core*(N_core+2),:,:),[],pp.order);
g_crust=g(1:(110*(110+2))); mod_ext=model_ext; dip=[-29442.0, -1501.0, 4797.1];
RC_interp = interp1(rc_data(:,1), rc_data(:,3:4), t_sub, 'linear');

% 并行计算
n_sub = length(t_sub);
chunk_size = 50000;
num_chunks = ceil(n_sub / chunk_size);
out_B = cell(num_chunks, 1);

parfor i = 1:num_chunks
    c_idx = (i-1)*chunk_size+1 : min(i*chunk_size, n_sub);
    th_d = 90 - lat_sub(c_idx);
    B_c = synth_values(r_sub(c_idx), th_d, lon_sub(c_idx), pp_core, t_sub(c_idx));
    B_k = synth_values(r_sub(c_idx), th_d, lon_sub(c_idx), g_crust);
    B_e = synth_values_CHAOS_ext(t_sub(c_idx), r_sub(c_idx), th_d, lon_sub(c_idx), ...
        RC_interp(c_idx,:), mod_ext, dip, 'GSM_SM_SHA_3D_IGRF12_2015.mat');
    out_B{i} = B_c + B_k + B_e;
end
B_model_sub = vertcat(out_B{:});

% 计算标量残差
F_mod_sub = vecnorm(B_model_sub, 2, 2);
dF_res_sub = F_obs(idx_calc) - F_mod_sub;

% 辅助参数 (QDLat, Direction based on Model)
fprintf('   计算 QD 纬度...\n');
QD_lat_sub = calculate_QD_Lat(B_model_sub, r_sub);
Dir_sub = B_model_sub ./ F_mod_sub; 

%% ------------------- 6. 后置筛选 (By, 粗差) -------------------
disp('6. 执行后置筛选...');

t_sub_dn = t_sub + datenum(2000, 1, 1); 
if ~exist('t_omni_dn', 'var'), t_omni_dn = datenum(em_table.datetime); end
by_vals_sub = interp1(t_omni_dn, em_table.avg_by_2h, t_sub_dn, 'nearest', 'extrap');

mask_by_sub = false(size(QD_lat_sub));
is_north = QD_lat_sub > 0;
mask_by_sub(is_north)  = by_vals_sub(is_north) < 3;
mask_by_sub(~is_north) = by_vals_sub(~is_north) > -3;
mask_by_sub(isnan(by_vals_sub)) = false;

mask_gross_sub = abs(dF_res_sub) < 20; 

mask_final_sub = mask_by_sub & mask_gross_sub;
idx_final_rel = find(mask_final_sub);

% 提取最终变量
t_fin = t_sub(idx_final_rel);
r_fin = r_sub(idx_final_rel); 
lat_fin = lat_sub(idx_final_rel); 
lon_fin = lon_sub(idx_final_rel);
qd_fin = QD_lat_sub(idx_final_rel);
dF_res_fin = dF_res_sub(idx_final_rel);
Dir_fin = Dir_sub(idx_final_rel, :);
sat_fin = ones(length(t_fin), 1) * SAT_ID_VAL;

fprintf('   最终保留: %d (%.1f%%)\n', length(t_fin), length(t_fin)/length(t_sub)*100);

%% ------------------- 7. 保存绝对数据 (Scalar) -------------------
disp('7. 保存 SAC-C 标量数据...');

if ~isempty(t_fin)
    Data_Scalar_Orig = struct('Time', t_fin, ...
        'Pos', [r_fin, 90-lat_fin, lon_fin], ... 
        'dF', dF_res_fin, ...
        'Dir', Dir_fin, ...
        'QD_Lat', qd_fin, ...
        'SatID', sat_fin, ...
        'Weight', ones(length(t_fin),1));
    save('SACC_ACC_Input_Original_Scalar.mat', 'Data_Scalar_Orig');
end

%% ------------------- 8. [恢复] 沿轨标量梯度计算 -------------------
disp('8. 计算沿轨标量梯度 (15s 间隔)...');

% 1. 全局有效性掩膜 (必须通过 Step 4 和 Step 6)
mask_global_valid = false(total_points, 1);
idx_final_global = idx_calc(mask_final_sub);
mask_global_valid(idx_final_global) = true;

% 2. 映射残差回全局 (未通过筛选的点为 NaN)
dF_global = nan(total_points, 1);
dF_global(idx_calc) = dF_res_sub; 

Dir_global = nan(total_points, 3);
Dir_global(idx_calc, :) = Dir_sub;

QD_global = nan(total_points, 1);
QD_global(idx_calc) = QD_lat_sub;

% 3. 寻找时间间隔为 15s 的点对 (容差 0.5s)
dt_global = diff(t_dn) * 86400; 
raw_pair_idx = find(abs(dt_global - BINNING_WINDOW_SEC) <= 0.5);

fprintf('   - 原始 15s 物理点对数: %d\n', length(raw_pair_idx));

if isempty(raw_pair_idx)
    warning('没有找到 15s 间隔的点对。请检查降采样步长是否正确 (应为15)。');
    Data_Scalar_Grad = [];
else
    i1 = raw_pair_idx;
    i2 = raw_pair_idx + 1;
    
    % 4. 只有双端都有效的点才计算梯度
    mask_pair_valid = mask_global_valid(i1) & mask_global_valid(i2);
    
    fin_i1 = i1(mask_pair_valid);
    fin_i2 = i2(mask_pair_valid);
    
    if isempty(fin_i1)
        warning('没有梯度点对通过筛选 (数据破碎)。');
        Data_Scalar_Grad = [];
    else
        % 5. 计算梯度
        dF1 = dF_global(fin_i1);
        dF2 = dF_global(fin_i2);
        
        g_s = dF2 - dF1;
        
        % 6. 梯度粗差剔除 (< 20 nT/15s)
        mask_grad_val = abs(g_s) < 20;
        
        valid_g_idx = find(mask_grad_val);
        fin_i1 = fin_i1(valid_g_idx);
        fin_i2 = fin_i2(valid_g_idx);
        g_s_final = g_s(valid_g_idx);
        
        % 提取信息
        t_final = t_dn(fin_i1);
        t2_final = t_dn(fin_i2);
        pos1 = [r_obs(fin_i1), 90-lat_obs(fin_i1), lon_obs(fin_i1)];
        pos2 = [r_obs(fin_i2), 90-lat_obs(fin_i2), lon_obs(fin_i2)];
        Dir_final = Dir_global(fin_i1, :);
        QD_final  = QD_global(fin_i1);
        
        Data_Scalar_Grad = struct(...
            'Time1', t_final, ...
            'Time2', t2_final, ...
            'Pos1', pos1, ...
            'Pos2', pos2, ...
            'd_grad', g_s_final, ...
            'Dir', Dir_final, ...
            'QD_Lat', QD_final, ...
            'SatID', ones(length(t_final), 1) * SAT_ID_VAL, ...
            'Weight', ones(length(t_final), 1));
        
        fprintf('   - 最终梯度点数: %d\n', length(g_s_final));
        save('SACC_ACC_Input_Gradient_Scalar.mat', 'Data_Scalar_Grad');
    end
end

toc;