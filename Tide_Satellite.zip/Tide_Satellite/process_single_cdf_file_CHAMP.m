function processed_data = process_single_cdf_file_CHAMP(file_name, curr_folder, ~, data_step)
% process_single_cdf_file_CHAMP
% 专门针对CHAMP卫星数据手册优化的读取与分箱平均程序
% 
% 输出格式: [Lat, Lon, Rad, B_N, B_E, B_C, Time_dn, F_scal, F_std]

processed_data = [];
full_path = fullfile(curr_folder, file_name);
orig_warn_state = warning; 

try
    % =========================================================================
    % 1. 读取原始数据 (基于CHAMP手册变量名)
    % =========================================================================
    target_vars = {'EPOCH', 'GEO_LAT', 'GEO_LON', 'GEO_ALT', ...
                   'GEO_STAT', 'FGM_SCAL', 'NEC_VEC', 'FGM_FLAGS', 'ASC_STAT'};
    
    warning('off', 'all');
    try
        % 注意: CHAMP CDF 文件变量名通常是大写的
        cdf_data = cdfread(full_path, 'Variables', target_vars, ...
            'CombineRecords', true, 'ConvertEpochToDatenum', true);
    catch
        warning(orig_warn_state); return;
    end
    if isempty(cdf_data), warning(orig_warn_state); return; end
    
    raw_t        = double(cdf_data{1}); % EPOCH
    raw_lat      = double(cdf_data{2}); % GEO_LAT
    raw_lon      = double(cdf_data{3}); % GEO_LON
    raw_alt      = double(cdf_data{4}); % GEO_ALT
    raw_geo_stat = double(cdf_data{5}); % GEO_STAT (Nx3)
    raw_F        = double(cdf_data{6}); % FGM_SCAL
    raw_B        = double(cdf_data{7}); % NEC_VEC (Nx3)
    raw_fgm_flg  = double(cdf_data{8}); % FGM_FLAGS (Nx2 bytes)
    raw_asc_stat = double(cdf_data{9}); % ASC_STAT (int4)
    
    % 转换高度到半径
    raw_r = raw_alt + 6371.2;
    
    % =========================================================================
    % 2. 严格质量控制 (根据手册 3.3.1)
    % =========================================================================
    
    % (1) GEO_STAT: 必须为 [0, 20, 0]
    mask_geo = (raw_geo_stat(:,1) == 0) & (raw_geo_stat(:,2) == 20) & (raw_geo_stat(:,3) == 0);
    
    % (2) FGM_FLAGS: 
    % Byte 1: bit 2-3 (freq 50Hz) == 0, bit 4 (no torquer) == 0
    % 位掩码说明：bit2-3 对应数值 4+8=12; bit4 对应数值 16
    byte1 = raw_fgm_flg(:,1);
    byte2 = raw_fgm_flg(:,2);
    mask_fgm = (bitand(byte1, 12) == 0) & (bitand(byte1, 16) == 0) & (bitand(byte2, 16) == 0);
    
    % (3) ASC_STAT: 第一位数字必须为 7
    % 它是5位数，例如 70110，万位是 floor(x/10000)
    mask_asc = (floor(raw_asc_stat / 10000) == 7);
    
    % (4) 基础范围与缺失值检查
    mask_basic = ~isnan(raw_lat) & ~isnan(raw_F) & (raw_F > 0) & (raw_r > 6000);

    valid_mask = mask_geo & mask_fgm & mask_asc & mask_basic;
    
    if sum(valid_mask) < 10, warning(orig_warn_state); return; end
             
    t_clean   = raw_t(valid_mask);
    lat_clean = raw_lat(valid_mask);
    lon_clean = raw_lon(valid_mask);
    r_clean   = raw_r(valid_mask);
    F_clean   = raw_F(valid_mask);
    B_clean   = raw_B(valid_mask, :);

    % =========================================================================
    % 3. 分箱平均 (Bin Averaging) - 15s 窗口
    % =========================================================================
    dt_grid_days = data_step / 86400; 
    t_start = floor(min(t_clean) * 86400 / data_step) * data_step / 86400;
    t_end   = ceil(max(t_clean) * 86400 / data_step) * data_step / 86400;
    edges = t_start : dt_grid_days : t_end;
    
    if length(edges) < 2, warning(orig_warn_state); return; end
    
    [Y, ~] = discretize(t_clean, edges);
    bin_valid = ~isnan(Y);
    Y = Y(bin_valid);
    
    counts = accumarray(Y, 1);
    has_enough_data = (counts >= 10); % 保证窗口内有足够采样点
    
    calc_mean = @(data) accumarray(Y, data) ./ max(1, counts);
    
    % 平均各个分量
    val_lat = calc_mean(lat_clean(bin_valid));
    val_r   = calc_mean(r_clean(bin_valid));
    val_F   = calc_mean(F_clean(bin_valid));
    val_B   = [calc_mean(B_clean(bin_valid, 1)), ...
               calc_mean(B_clean(bin_valid, 2)), ...
               calc_mean(B_clean(bin_valid, 3))];
    
    % 经度三角函数平均 (修复跨越+/-180)
    lon_rad = deg2rad(lon_clean(bin_valid));
    val_lon = rad2deg(atan2(accumarray(Y, sin(lon_rad)), ...
                            accumarray(Y, cos(lon_rad))));
    
    % 计算标量标准差，用于权重分配
    val_std_F = accumarray(Y, F_clean(bin_valid), [], @std);
    
    % 时间取中值
    val_t_num = (edges(1:end-1) + edges(2:end))' / 2;
    
    % =========================================================================
    % 4. 结果整合
    % =========================================================================
    final_mask = false(size(counts));
    final_mask(1:length(has_enough_data)) = has_enough_data;
    
    if any(final_mask)
        % 最终输出格式匹配主程序
        processed_data = [val_lat(final_mask), ...
                          val_lon(final_mask), ...
                          val_r(final_mask), ...
                          val_B(final_mask, :), ...
                          val_t_num(final_mask), ...
                          val_F(final_mask), ...
                          val_std_F(final_mask)];
    end
    
    warning(orig_warn_state);
catch ME
    fprintf('Error processing CHAMP file %s: %s\n', file_name, ME.message);
    warning(orig_warn_state);
    processed_data = [];
end
end