import os
import math
import csv
import glob
from datetime import datetime, timedelta

# ================= 配置区域 =================
# 输入文件夹路径 (请确认包含 .dat 或 .txt 文件)
INPUT_FOLDER = r'e:\A_graduate\code_and_program\Satellite_data_processing\20251202_new_satellite_process\Omni_raw_Data_HR'
# 输出文件路径
OUTPUT_FILE = r'e:\A_graduate\code_and_program\Satellite_data_processing\20251202_new_satellite_process\omni_min_em_bz_2h_avg.csv'
# ===========================================

def calculate_em(v, by, bz):
    """
    计算Newell电场耦合项 Em
    """
    # 计算Bt (nT)
    bt = math.sqrt(by**2 + bz**2)
    
    # 计算时钟角 θ
    if bz == 0:
        theta = math.pi / 2
    else:
        theta = math.atan(by / bz)
    
    # 计算sin(|θ|/2)
    sin_theta_half = math.sin(abs(theta) / 2)
    
    # 计算Em值 (mV/m)
    # 假设输入 V(km/s), B(nT)
    em = 0.33 * (v ** (4/3)) * (bt ** (2/3)) * (sin_theta_half ** (8/3)) * 1e-3
    return em

def process_single_file(file_path):
    """
    读取单个OMNI文件 (1-min/5-min 格式)
    计算每小时的Em值 (2小时平均)
    """
    results = []
    filename = os.path.basename(file_path)
    
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            
            # 分割数据
            data = line.split()
            
            # 基础长度检查 (确保有足够列)
            if len(data) < 25: 
                continue
            
            try:
                # --- 1. 解析时间 (1-4列) ---
                year = int(data[0])
                day = int(data[1])
                hour = int(data[2])
                minute = int(data[3]) # 分钟数据新增
                
                # --- 2. 解析物理量 (根据图片格式) ---
                # Word 18: By (GSM), nT -> Index 17
                by_str = data[17]
                # Word 19: Bz (GSM), nT -> Index 18
                bz_str = data[18]
                # Word 22: Flow speed, km/s -> Index 21
                v_str = data[21]
                
                # --- 3. 检查缺失值 (Fill Values) ---
                # OMNI标准: B场缺失为 9999.99, 速度缺失为 9999.9
                # 转换为float并检查
                by_gsm = float(by_str)
                bz_gsm = float(bz_str)
                v = float(v_str)
                
                if by_gsm >= 9999.0 or bz_gsm >= 9999.0 or v >= 9999.0:
                    continue # 跳过无效数据行

                # --- 4. 计算 Em ---
                em = calculate_em(v, by_gsm, bz_gsm)
                
                # --- 5. 构建时间对象 ---
                # 注意: datetime(year, 1, 1) 是第1天，所以要 + (day-1)
                record_datetime = datetime(year, 1, 1) + timedelta(days=day-1, hours=hour, minutes=minute)
                
                results.append({
                    'datetime': record_datetime,
                    'year': year,
                    'day': day,
                    'hour': hour,
                    'minute': minute,
                    'em': em,
                    'by_gsm': by_gsm,
                    'bz_gsm': bz_gsm
                })

            except (ValueError, IndexError):
                continue
                
    return results

def calculate_moving_averages(all_records, window_minutes=120):
    """
    使用滑动窗口算法计算过去2小时的均值 (高效版)
    """
    n = len(all_records)
    if n == 0:
        return []
    
    print(f"Calculating 2-hour moving averages for {n} records...")
    
    # 结果容器
    final_records = []
    
    # 滑动窗口的双指针
    left_ptr = 0
    
    # 用于维护窗口内的累加和与计数
    window_sum_em = 0.0
    window_sum_bz = 0.0
    window_count = 0
    
    # 为了处理时间不连续的情况，我们不能简单地用索引减法
    # 必须使用真实的 datetime 比较
    
    # 这里我们使用一种"惰性删除"的策略，或者每次循环重新调整左指针
    # 对于每一行(右指针)，移动左指针直到时间差 <= 2小时
    
    # 注意：为了精度，我们通常需要重新计算窗口内的和，或者小心维护
    # 鉴于数据可能存在间隙(gap)，最稳妥且较快的方法是：
    # 维护一个 deque 或者利用指针范围切片求和 (Python sum切片很快)
    
    # 优化策略：
    # 既然已经按时间排序，对于每一个 right_ptr，left_ptr 只能向右移动 (单调性)
    
    for right_ptr in range(n):
        current_record = all_records[right_ptr]
        current_time = current_record['datetime']
        threshold_time = current_time - timedelta(minutes=window_minutes)
        
        # 1. 移动左指针：移除超出2小时范围的数据
        # 只要 left 指向的数据时间 早于 (当前时间 - 2小时)，就剔除
        while left_ptr <= right_ptr:
            if all_records[left_ptr]['datetime'] < threshold_time:
                left_ptr += 1
            else:
                break
        
        # 2. 此时 [left_ptr, right_ptr] 区间内的数据即为过去2小时的数据(含当前时刻)
        # 提取该切片的数据
        window_slice = all_records[left_ptr : right_ptr + 1]
        
        count = len(window_slice)
        
        if count > 0:
            # 计算切片均值
            # 针对分钟级数据，sum()循环几十次(最多120次)非常快
            avg_em = sum(r['em'] for r in window_slice) / count
            avg_by = sum(r['by_gsm'] for r in window_slice) / count
            avg_bz = sum(r['bz_gsm'] for r in window_slice) / count
            
            # 将均值写入当前记录
            # 使用 copy 防止修改原始引用
            new_record = current_record.copy()
            new_record['avg_em_2h'] = avg_em
            new_record['avg_by_2h'] = avg_by
            new_record['avg_bz_2h'] = avg_bz
            new_record['window_count'] = count # 可选：记录有多少个点参与了计算
            
            final_records.append(new_record)
            
        if right_ptr % 50000 == 0:
            print(f"Processed {right_ptr}/{n} records...")

    return final_records

def main():
    # 获取所有txt/dat文件
    # 假设文件名格式类似 omni_min_xxx.dat 或 txt
    data_files = glob.glob(os.path.join(INPUT_FOLDER, '*.dat')) 
    if not data_files:
        # 尝试 .txt
        data_files = glob.glob(os.path.join(INPUT_FOLDER, '*.txt'))
    
    print(f"Found {len(data_files)} files.")
    
    all_raw_data = []
    
    # 1. 读取并计算瞬时值
    for f in data_files:
        print(f"Reading: {os.path.basename(f)}")
        file_data = process_single_file(f)
        all_raw_data.extend(file_data)
        
    print(f"Total raw records loaded: {len(all_raw_data)}")
    
    if not all_raw_data:
        print("No valid data found. Check file paths and format.")
        return

    # 2. 按时间排序 (必须步骤)
    print("Sorting data by time...")
    all_raw_data.sort(key=lambda x: x['datetime'])
    
    # 3. 计算滑动平均
    processed_data = calculate_moving_averages(all_raw_data, window_minutes=120)
    
    # 4. 保存结果
    print(f"Saving {len(processed_data)} records to CSV...")
    
    fieldnames = ['datetime', 'year', 'day', 'hour', 'minute', 'em', 'by_gsm', 'bz_gsm', 'avg_em_2h', 'avg_by_2h', 'avg_bz_2h']
    
    with open(OUTPUT_FILE, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        
        for record in processed_data:
            # 格式化 datetime 为字符串以便阅读
            row = {k: v for k, v in record.items() if k in fieldnames}
            # row['datetime'] 默认会转为 str, 也可以自定义格式: record['datetime'].strftime('%Y-%m-%d %H:%M:%S')
            writer.writerow(row)
            
    print("Done!")
    print(f"File saved to: {OUTPUT_FILE}")

if __name__ == "__main__":
    main()