function processed_data = process_single_cdf_file(file_info, curr_folder, ~, data_step)
% 处理单个CDF文件的核心函数 (修改版：支持 GraceFO 和 Orsted)
% 输入：
%   file_info - 文件信息结构体
%   curr_folder - 文件夹路径
%   ref_datenum_2000 - (未使用，函数内自行处理)
%   data_step - 降采样步长 (例如 15)
% 输出：
%   processed_data - [Lat, Lon, R, B_NEC(3), Time, F]

processed_data = [];

try
    % 1. 获取全路径
    full_path = fullfile(curr_folder, file_info.name);
    
    % =========================================================================
    % 分支 A: GraceFO 处理逻辑
    % =========================================================================
    if contains(curr_folder, 'GraceFO', 'IgnoreCase', true)
        variables = {'Timestamp', 'Latitude', 'Longitude', 'Radius', 'B_NEC', 'B_FGM', 'B_FLAG'};
        
        data = cdfread(full_path, ...
            'Variables', variables, ...
            'CombineRecords', true, 'ConvertEpochToDatenum', true);
        
        temp_time_datenum = data{1};
        temp_lat  = data{2}; 
        temp_lon  = data{3}; 
        temp_r    = data{4} / 1000;  % m -> km (Grace通常单位是m)
        temp_bnec = data{5};
        temp_flag = data{7}; % B_FLAG
        
        % GraceFO 计算标量 F
        temp_F = sqrt(sum(temp_bnec.^2, 2));

    % =========================================================================
    % 分支 B: Orsted (奥斯特) / CHAMP / Swarm Legacy 处理逻辑
    % =========================================================================
    elseif contains(curr_folder, 'Orsted', 'IgnoreCase', true) || ...
           contains(curr_folder, 'Oersted', 'IgnoreCase', true)
       
        % 1. 定义变量名 (根据你的截图)
        % 注意：'B' 是矢量(3维), 'Qf'/'Qb' 是质量标记
        variables = {'Theta', 'Phi', 'R', 'B', 'T', 'F', 'Day', 'Qf', 'Qb'};
        
        % 2. 读取数据
        data = cdfread(full_path, ...
            'Variables', variables, ...
            'CombineRecords', true, 'ConvertEpochToDatenum', true);
        
        % 3. 提取变量 (一一对应上面的 variables 列表)
        raw_theta = data{1}; % Co-latitude
        raw_phi   = data{2}; % Longitude
        raw_r     = data{3}; % Radius
        raw_b     = data{4}; % Vector B
        raw_t     = data{5}; % Time (Seconds of day)
        raw_f     = data{6}; % Scalar F
        raw_day   = data{7}; % Day (Scalar, Epoch day)
        raw_qf    = data{8}; % Quality F
        raw_qb    = data{9}; % Quality B
        
        % --- 坐标转换 ---
        % Theta 是余纬度 [0, 180] -> 纬度 Latitude [-90, 90]
        temp_lat = 90 - double(raw_theta);
        temp_lon = double(raw_phi);
        
        % --- 半径单位处理 ---
        % 自动判断单位是 m 还是 km
        temp_r = double(raw_r);
        if mean(temp_r, 'omitnan') > 1000000
            temp_r = temp_r / 1000; % m -> km
        end
        
        % --- 时间转换 (关键修改) ---
        % 奥斯特基准时间通常是 2000-01-01
        base_date = datenum(2000, 1, 1); 
        
        % 处理 Day：因为整个文件是同一天，强制转换为标量
        if isempty(raw_day)
            error('文件中的 Day 变量为空');
        end
        day_offset = double(raw_day(1)); % 强制取第一个元素，确保是标量
        
        %合成时间: 基准 + 天数偏移 + 秒数/一天的秒数
        % MATLAB会自动将标量 day_offset 加到向量 raw_t 的每一个元素上
        temp_time_datenum = base_date + day_offset + double(raw_t) / 86400;
        
        % --- 磁场赋值 ---
        temp_bnec = double(raw_b);
        temp_F    = double(raw_f);
        
        % --- 质量标记处理 ---
        % 注意：截图中 Qf/Qb 长度可能与 T 不一致 (如数据有缺失)
        % 逻辑：只在长度匹配时进行过滤，否则仅依赖数值范围检查
        N_samples = length(temp_lat);
        temp_flag = zeros(N_samples, 1); % 默认为 0 (好数据)
        
        % 尝试合并 Qf
        if length(raw_qf) == N_samples
            temp_flag = temp_flag + double(raw_qf);
        end
        % 尝试合并 Qb
        if length(raw_qb) == N_samples
            temp_flag = temp_flag + double(raw_qb);
        end
        % 如果长度都不匹配，temp_flag 保持全0，依靠后续 NaN 检查过滤

    % =========================================================================
    % 分支 C: 其他默认逻辑
    % =========================================================================
    else
        % 默认旧逻辑
        variables = {'Latitude', 'Longitude', 'Radius', 'B_NEC', 'Timestamp', 'F'};
        data = cdfread(full_path, ...
            'Variables', variables, ...
            'CombineRecords', true, 'ConvertEpochToDatenum', true);
        
        temp_lat  = data{1}; 
        temp_lon  = data{2}; 
        temp_r    = data{3} / 1000;
        temp_bnec = data{4};
        temp_time_datenum = data{5};
        temp_F    = data{6};
        temp_flag = zeros(size(temp_lat)); 
    end
    
    % ------------------------------------------------------
    % 2. [核心修改] 立即进行降采样
    % ------------------------------------------------------
    N_total = length(temp_lat);
    
    % 确保索引不越界
    sample_idx = 1:data_step:N_total;
    
    % 应用降采样
    temp_lat  = temp_lat(sample_idx);
    temp_lon  = temp_lon(sample_idx);
    temp_r    = temp_r(sample_idx);
    temp_bnec = temp_bnec(sample_idx, :);
    temp_time_datenum = temp_time_datenum(sample_idx);
    temp_F    = temp_F(sample_idx);
    temp_flag = temp_flag(sample_idx);
    
    % ------------------------------------------------------
    % 3. 基础有效性检查
    % ------------------------------------------------------
    % 检查 Flag (要求 flag == 0 才是好数据)
    is_good_flag = (double(temp_flag) == 0);
    
    % 检查 NaN 和数值范围 (防止异常大数或零值)
    valid_basic = all(~isnan([temp_lat, temp_lon, temp_r, temp_bnec]), 2) & ...
                  ~isnan(temp_F) & ...
                  (temp_F > 1000) & ... % 物理合理性：磁场不可能小于 1000 nT
                  all(abs(temp_bnec) < 100000, 2); % 物理合理性：也不可能超过 100,000 nT
    
    % 最终基础掩码
    valid_combined = valid_basic & is_good_flag;
    
    % 如果降采样后没有有效数据，直接返回
    if ~any(valid_combined)
        return;
    end
    
    % 提取有效数据
    val_lat = temp_lat(valid_combined);
    val_lon = temp_lon(valid_combined);
    val_r   = temp_r(valid_combined);
    val_b   = temp_bnec(valid_combined, :);
    val_t_num = temp_time_datenum(valid_combined);
    val_F   = temp_F(valid_combined);
    
    % ------------------------------------------------------
    % 4. 打包输出
    % ------------------------------------------------------
    processed_data = [val_lat, val_lon, val_r, val_b, val_t_num, val_F];
    
catch ME
    warning(['处理文件出错: ', file_info.name, '. 错误信息: ', ME.message]);
    processed_data = [];
end
end