function processed_data = process_single_cdf_file(file_info, curr_folder, ~, data_step)
% 处理单个CDF文件的核心函数 (适配纯标量CDF版 + 分箱重采样)
% 适配变量: Day, T, R, Theta, Phi, F, Qf, Qpos

processed_data = [];

% 1. 快速过滤 empty 文件
if contains(file_info.name, 'empty', 'IgnoreCase', true)
    return; 
end

full_path = fullfile(curr_folder, file_info.name);
orig_warn_state = warning; 

try
    % =========================================================================
    % 1. 读取原始数据 (Core Variables)
    % =========================================================================
    % 修改：移除了 'B'，只读存在的变量
    core_vars = {'Theta', 'Phi', 'R', 'T', 'F', 'Day'};
    
    warning('off', 'MATLAB:cdfread:read_data_by_hyperslab:noRecords');
    warning('off', 'MATLAB:cdfread:noRecords');
    
    try
        core_data = cdfread(full_path, ...
            'Variables', core_vars, ...
            'CombineRecords', true, ...
            'ConvertEpochToDatenum', true);
    catch
        warning(orig_warn_state);
        return;
    end
    
    if isempty(core_data)
        warning(orig_warn_state);
        return;
    end
    
    % 提取并转为 double
    raw_theta = double(core_data{1});
    raw_phi   = double(core_data{2});
    raw_r     = double(core_data{3});
    raw_t     = double(core_data{4});
    raw_f     = double(core_data{5});
    raw_day   = double(core_data{6});
    
    if isempty(raw_t) || isempty(raw_f)
        warning(orig_warn_state);
        return; 
    end
    
    % 读取 Flag (适配 Qf 和 Qpos)
    N_samples = length(raw_theta);
    raw_flag = zeros(N_samples, 1);
    
    % 读取标量质量标记 Qf
    raw_flag = raw_flag + read_flag_safe(full_path, 'Qf', N_samples);
    % 读取位置质量标记 Qpos (如果有的话)
    raw_flag = raw_flag + read_flag_safe(full_path, 'Qpos', N_samples);
    
    % 恢复警告
    warning(orig_warn_state);
    
    % =========================================================================
    % 2. 预处理原始数据
    % =========================================================================
    % 坐标转换
    raw_lat = 90 - raw_theta;
    raw_lon = raw_phi;
    
    % 半径修正
    if mean(raw_r, 'omitnan') > 1000000
        raw_r = raw_r / 1000;
    end
    
    % 时间计算 (智能判断逻辑)
    if isempty(raw_day), d_val = 0; else, d_val = raw_day(1); end
    
    if d_val > 700000
        day_base = d_val; % 已经是完整 datenum
    elseif d_val > 40000
        day_base = d_val + datenum(1858, 11, 17); % MJD
    else
        day_base = d_val + datenum(2000, 1, 1); % Epoch 2000
    end
    
    raw_time_dn = day_base + raw_t / 86400;
    
    % =========================================================================
    % 3. 分箱重采样 (Binning)
    % =========================================================================
    
    % 定义时间网格
    dt_grid_days = data_step / 86400; 
    t_start = floor(min(raw_time_dn) * 86400 / data_step) * data_step / 86400;
    t_end   = ceil(max(raw_time_dn) * 86400 / data_step) * data_step / 86400;
    edges = t_start : dt_grid_days : t_end;
    
    if length(edges) < 2
        processed_data = []; return;
    end
    
    % 归类到箱子
    [Y] = discretize(raw_time_dn, edges);
    valid_mask = ~isnan(Y);
    Y = Y(valid_mask);
    
    if isempty(Y), processed_data = []; return; end
    
    % 计算平均值
    counts = accumarray(Y, 1);
    has_data = counts > 0;
    calc_mean = @(data) accumarray(Y, data(valid_mask)) ./ max(1, counts);
    
    val_lat = calc_mean(raw_lat);
    val_lon = calc_mean(raw_lon);
    val_r   = calc_mean(raw_r);
    val_F   = calc_mean(raw_f);
    val_flag = calc_mean(raw_flag);
    
    % [修改] 矢量 B 不存在，用 NaN 填充 (保持输出列数一致：Lat,Lon,R,Bx,By,Bz,T,F)
    % 这样主程序读取时不会因为列数变少而报错
    val_b = nan(length(counts), 3);
    
    % 重构时间轴 (箱子中心)
    edge_centers = (edges(1:end-1) + edges(2:end))' / 2;
    val_t_num = edge_centers;
    
    % 提取有效箱子
    val_lat = val_lat(has_data);
    val_lon = val_lon(has_data);
    val_r   = val_r(has_data);
    val_b   = val_b(has_data, :); % 全是 NaN
    val_F   = val_F(has_data);
    val_t_num = val_t_num(has_data);
    val_flag  = val_flag(has_data);
    
    % =========================================================================
    % 4. 有效性检查
    % =========================================================================
    % Flag > 0 视为坏
    is_good = (val_flag == 0);
    
    % [关键修改] 这里不再检查 val_b 是否为 NaN，因为现在 B 全是 NaN
    % 只要位置、时间和标量 F 是有效的即可
    valid_basic = all(~isnan([val_lat, val_lon, val_r]), 2) & ...
                  ~isnan(val_F) & (val_F > 1000);
              
    mask = valid_basic & is_good;
    
    if any(mask)
        % 输出格式: [Lat, Lon, R, B(3列NaN), Time, F]
        processed_data = [val_lat(mask), val_lon(mask), val_r(mask), ...
                          val_b(mask, :), val_t_num(mask), val_F(mask)];
    end
    
    warning(orig_warn_state);

catch
    warning(orig_warn_state);
    processed_data = [];
end
end

% =========================================================================
% 子函数: 强力静音读取 Flag
% =========================================================================
function flag_out = read_flag_safe(cdf_path, var_name, expected_len)
    flag_out = zeros(expected_len, 1);
    w_state = warning('off', 'all'); 
    try
        tmp = cdfread(cdf_path, 'Variables', {var_name}, 'CombineRecords', true);
        if ~isempty(tmp) && ~isempty(tmp{1})
            val = double(tmp{1});
            if length(val) == expected_len
                flag_out = val;
            end
        end
    catch
    end
    warning(w_state);
end